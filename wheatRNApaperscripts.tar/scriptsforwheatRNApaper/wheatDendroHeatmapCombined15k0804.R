suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network_15k.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

nSamples <- nrow(datExpr)
stopifnot(identical(rownames(MEs), rownames(coldata)))

# ---- Module-trait correlations (same as wheatModuleTraitHeatmapOnePage15k0804.R, full trait set) ----
traitCols <- coldata[, c("biotype", "virus", "day", "replicate")]
traitCols[] <- lapply(traitCols, as.factor)

datTraits <- binarizeCategoricalColumns(traitCols,
                                         considerColumns = colnames(traitCols),
                                         includePairwise = FALSE,
                                         includeLevelVsAll = TRUE,
                                         dropFirstLevelVsAll = FALSE)
rownames(datTraits) <- rownames(coldata)

moduleTraitCor <- cor(MEs, datTraits, use = "p")
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nSamples)
moduleTraitQvalue <- matrix(p.adjust(moduleTraitPvalue, method = "BH"),
                            nrow = nrow(moduleTraitPvalue),
                            dimnames = dimnames(moduleTraitPvalue))
textMatrix <- paste0(signif(moduleTraitCor, 2), " (", signif(moduleTraitQvalue, 2), ")")
dim(textMatrix) <- dim(moduleTraitCor)

# Map each ME## row label to its module's actual color (same colors as the
# "Module colors" band in the dendrogram panel), keyed by the numeric label
# WGCNA assigns 1:1 to each color.
labelNum <- as.numeric(sub("^ME", "", rownames(moduleTraitCor)))
rowColors <- sapply(labelNum, function(lbl) unique(moduleColors[moduleLabels == lbl]))

# Pick black or white label text so it stays legible against light vs. dark
# module colors.
rowLuminance <- apply(col2rgb(rowColors), 2, function(rgb) sum(rgb * c(0.299, 0.587, 0.114)))
rowTextCol <- ifelse(rowLuminance > 140, "black", "white")

# ---- One landscape page: gene dendrogram + module colors on top, module-trait heatmap below ----
outfile <- "wheat_geneDendro_heatmap_15k_combined.pdf"
pdf(outfile, width = 17, height = 11)

layout(matrix(c(1, 2, 3), ncol = 1), heights = c(5, 0.7, 4.6))

plotDendroAndColors(net$dendrograms[[1]], moduleColors,
                     groupLabels = "Module colors",
                     setLayout = FALSE,
                     dendroLabels = FALSE, hang = 0.03,
                     addGuide = TRUE, guideHang = 0.05,
                     marAll = c(0.5, 5, 3, 2),
                     main = sprintf("Gene dendrogram (%d genes)", length(moduleColors)))

par(mar = c(9, 9, 3, 3))
labeledHeatmap(Matrix = moduleTraitCor,
               xLabels = colnames(datTraits),
               yLabels = rownames(moduleTraitCor),
               ySymbols = rownames(moduleTraitCor),
               colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = textMatrix,
               setStdMargins = FALSE,
               cex.text = 0.75,
               cex.lab.x = 0.85,
               cex.lab.y = 0.85,
               bg.lab.y = rowColors,
               colors.lab.y = rowTextCol,
               zlim = c(-1, 1),
               main = "Module-trait relationships (BH q-value in parentheses)")
dev.off()
cat("wrote", outfile, "\n")
