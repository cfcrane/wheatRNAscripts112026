suppressPackageStartupMessages({
  library(ComplexHeatmap)
  library(circlize)
})
options(stringsAsFactors = FALSE)

# ============================================================
# Counterparts to wheat_module8_coexpression_heatmap.pdf for every other
# module (1-7, 9-14; module 8 already done in wheatModule8Heatmap0818.R).
# Loads the big shared inputs (network RData + TOM) once, then loops over
# modules, reproducing each wheatModule{N}Network0805.R's deterministic
# hub-gene (top kME) / target-gene (top TOM weight) selection logic to get
# the identical node set shown in that module's _network.pdf.
# ============================================================
padj_cut     <- 0.05
lfc_cut      <- 2
nHub         <- 4
nTargetMax   <- 20
nchar        <- 65   # max row-label length (chars) guaranteed not to be truncated

# Fixed per-gene row ("bar") height and fixed vertical overhead (title +
# annotation bars + legends), measured from wheat_module8_coexpression_heatmap.pdf
# (125.5066mm body / 24 genes = 5.2294mm/gene; 6.3in total - 4.9412in body =
# 1.3588in overhead). Every module's PDF height = overhead + nGenes * rowHeight,
# so gene rows are the same physical size across all modules.
ROW_H_MM    <- 5.2294
OVERHEAD_IN <- 1.3588

modulesToDo <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)

load("wheat_wgcna_network_15k.RData")   # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata
load("wheatTOM_15k-block.1.RData")      # TOM
TOMall <- as.matrix(TOM)
rm(TOM); gc()

geneIDs <- colnames(datExpr)

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[!duplicated(ann$gene_id), ]

load_sig <- function(f, lfcCut = lfc_cut) {
  r <- read.delim(f, stringsAsFactors = FALSE)
  r <- r[!is.na(r$padj) & r$padj <= padj_cut & abs(r$log2FoldChange) >= lfcCut, ]
  unique(r$gene_id)
}

regulatory_kw <- c("transcription factor", "zinc.finger", "ethylene.responsive",
                    "\\bERF\\b", "WRKY", "\\bMYB\\b", "bZIP", "bHLH", "NAC domain",
                    "BTB", "POZ", "homeobox", "MADS.box", "\\bAP2\\b", "response regulator")
is_regulatory <- function(desc) {
  if (is.na(desc)) return(FALSE)
  any(vapply(regulatory_kw, function(k) grepl(k, desc, ignore.case = TRUE), logical(1)))
}

dayLevels <- c("0", "1", "2", "3", "5", "10", "15", "20")
coldata$day <- factor(coldata$day, levels = dayLevels, ordered = TRUE)
sampleOrder <- order(coldata$day, coldata$biotype, coldata$virus, coldata$replicate)
samplesOrdered <- rownames(datExpr)[sampleOrder]

roleColors <- c(Hub = "#E34948", Regulatory = "#1baf7a", Structural = "#2a78d6")
dayCol     <- setNames(viridisLite::turbo(length(dayLevels)), dayLevels)
biotypeCol <- c(B = "#1b9e77", H = "#d95f02", not_infested = "#999999")
virusCol   <- c(virus_free = "#7570b3", carrier = "#e7298a")
col_fun    <- colorRamp2(c(-2, 0, 2), c("#2166ac", "white", "#b2182b"))

for (moduleNum in modulesToDo) {
  res <- tryCatch({
    modGenes <- geneIDs[moduleLabels == moduleNum]
    modColor <- unique(moduleColors[moduleLabels == moduleNum])

    meCol <- paste0("ME", moduleNum)
    kME <- sapply(modGenes, function(g) cor(datExpr[, g], MEs[, meCol], use = "p"))
    kME <- sort(kME, decreasing = TRUE)
    hubGenes <- names(head(kME, nHub))

    idx <- match(modGenes, geneIDs)
    TOMmat <- TOMall[idx, idx]
    dimnames(TOMmat) <- list(modGenes, modGenes)

    # Modules 11 and 12 have too few genes meeting the usual padj<=0.05 &
    # |log2FC|>=2 bar (0 and 1, respectively) -- their _network.pdf scripts
    # relax the target pool to padj-only for these two modules specifically.
    lfc_cut_targets <- if (moduleNum %in% c(11, 12)) 0 else lfc_cut
    sigLOCmod <- unique(c(load_sig("biotype_results.txt", lfc_cut_targets),
                           load_sig("virus_results.txt", lfc_cut_targets),
                           load_sig("time_results.txt", lfc_cut_targets)))

    annMod <- ann[ann$gene_id %in% modGenes, c("gene_id", "gene_name", "description")]
    annMod$is_sig_DEG <- annMod$gene_name %in% sigLOCmod
    targetCandidates <- setdiff(annMod$gene_id[annMod$is_sig_DEG], hubGenes)

    wMat <- sapply(hubGenes, function(h) TOMmat[h, targetCandidates])
    if (is.null(dim(wMat))) wMat <- matrix(wMat, ncol = length(hubGenes), dimnames = list(targetCandidates, hubGenes))
    targetMax <- apply(wMat, 1, max)
    keepTargets <- names(sort(targetMax, decreasing = TRUE))[seq_len(min(nTargetMax, length(targetMax)))]

    nodeIDs <- unique(c(hubGenes, keepTargets))
    nodeAnn <- annMod[match(nodeIDs, annMod$gene_id), ]
    nodeAnn$role <- ifelse(nodeAnn$gene_id %in% hubGenes, "Hub",
                            ifelse(vapply(nodeAnn$description, is_regulatory, logical(1)),
                                   "Regulatory", "Structural"))
    nodeAnn$label <- ifelse(!is.na(nodeAnn$gene_name) & nzchar(nodeAnn$gene_name),
                             nodeAnn$gene_name, nodeAnn$gene_id)
    # "uncharacterized" descriptions are just "uncharacterized <gene_id>", which
    # repeats the locus name already shown in the row label -- drop the repeat.
    isUnchar <- !is.na(nodeAnn$description) & grepl("^uncharacterized\\b", nodeAnn$description, ignore.case = TRUE)
    nodeAnn$descShort <- ifelse(isUnchar, "uncharacterized",
                          ifelse(!is.na(nodeAnn$description) & nzchar(nodeAnn$description),
                                 substr(nodeAnn$description, 1, 40), "unannotated"))

    mat <- t(datExpr[samplesOrdered, nodeAnn$gene_id, drop = FALSE])
    matZ <- t(scale(t(mat)))
    rowLabel <- paste0(nodeAnn$label, " (", nodeAnn$descShort, ")")
    # Labels shorter than `nchar` are guaranteed to display in full (see width
    # calculation below); longer ones are truncated to exactly `nchar` characters.
    rowLabel <- ifelse(base::nchar(rowLabel) > nchar,
                        paste0(substr(rowLabel, 1, nchar - 3), "..."),
                        rowLabel)
    rownames(matZ) <- rowLabel
    rowTextCol <- roleColors[nodeAnn$role]

    topAnn <- HeatmapAnnotation(
      day     = coldata[samplesOrdered, "day"],
      biotype = coldata[samplesOrdered, "biotype"],
      virus   = coldata[samplesOrdered, "virus"],
      col = list(day = dayCol, biotype = biotypeCol, virus = virusCol),
      annotation_name_side = "left",
      simple_anno_size = unit(3, "mm"),
      annotation_legend_param = list(
        day     = list(direction = "horizontal", nrow = 1),
        biotype = list(direction = "horizontal", nrow = 1),
        virus   = list(direction = "horizontal", nrow = 1)
      )
    )

    nGenes <- nrow(matZ)

    # Everything to the left of the row-name column (heatmap body + annotation +
    # legends) previously got whatever was left of the fixed 11in page width
    # after ComplexHeatmap's default 6cm row-name column -- keep that same
    # left-hand width, and instead size the row-name column to fit the longest
    # label (up to `nchar` characters) so labels under `nchar` are never clipped.
    BODY_AND_REST_IN <- 11 - 2.362205  # 11in page - default 6cm row_names_max_width
    ROW_NAME_PAD_IN  <- 0.15           # margin so text isn't flush with the page edge
    pdf(NULL)
    rowNameWidthIn <- max(sapply(rowLabel, function(s)
      grid::convertWidth(grid::grobWidth(grid::textGrob(s, gp = gpar(fontsize = 8))),
                          "inches", valueOnly = TRUE)))
    dev.off()
    rowNameWidthIn <- rowNameWidthIn + ROW_NAME_PAD_IN

    ht <- Heatmap(
      matZ,
      name = "z-score",
      col = col_fun,
      top_annotation = topAnn,
      height = unit(nGenes * ROW_H_MM, "mm"),
      cluster_columns = FALSE,
      cluster_rows = TRUE,
      clustering_distance_rows = "euclidean",
      clustering_method_rows = "complete",
      show_column_names = FALSE,
      row_names_side = "right",
      row_names_gp = gpar(col = rowTextCol, fontsize = 8),
      row_names_max_width = unit(rowNameWidthIn, "inches"),
      column_title = sprintf("Module %d (%s module) co-expression network genes: expression by day", moduleNum, modColor),
      column_title_gp = gpar(fontsize = 12, fontface = "bold"),
      heatmap_legend_param = list(title = "row z-score", direction = "horizontal")
    )

    outFile <- sprintf("wheat_module%d_coexpression_heatmap.pdf", moduleNum)
    pdfWidth <- BODY_AND_REST_IN + rowNameWidthIn
    pdf(outFile, width = pdfWidth, height = OVERHEAD_IN + nGenes * ROW_H_MM / 25.4)
    draw(ht, heatmap_legend_side = "bottom", annotation_legend_side = "bottom", merge_legends = TRUE)
    dev.off()

    cat(sprintf("Module %2d (%s): %d genes (%d hub, %d target) -> %s\n",
                moduleNum, modColor, nrow(nodeAnn), length(hubGenes), length(keepTargets), outFile))
    TRUE
  }, error = function(e) {
    cat(sprintf("Module %2d: FAILED - %s\n", moduleNum, conditionMessage(e)))
    FALSE
  })
}
cat("done\n")
