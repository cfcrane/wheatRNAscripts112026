#!/usr/bin/env perl
use warnings;
#This script compares two lists for common elements.
open (INP, "< $ARGV[0]");
open (OUT, "> $ARGV[1]");
$line = <INP>;
chomp $line;
@vars = split(/\//, $line);
for ($i = 0; $i < scalar(@vars); $i++) {$hasha{$vars[$i]} = 1;}
$line = <INP>;
chomp $line;
@tars = split(/\//, $line);
for ($i = 0; $i < scalar(@tars); $i++) {$hashb{$tars[$i]} = 1;}
$ncomm = 0;
for $key (sort(keys(%hasha))) {
  if (exists($hashb{$key})) {$ncomm++; print OUT "$key is in common.\n";}
}
print OUT "There were $ncomm keys in common between the two lines.\n";
