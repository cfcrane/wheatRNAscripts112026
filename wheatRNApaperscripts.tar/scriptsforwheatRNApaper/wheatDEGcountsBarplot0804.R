suppressPackageStartupMessages(library(ggplot2))

padj_cut <- 0.05
lfc_cut  <- 2

count_sig <- function(file) {
  d <- read.delim(file, stringsAsFactors = FALSE)
  d <- d[!is.na(d$padj), ]
  sig <- d[d$padj <= padj_cut & abs(d$log2FoldChange) >= lfc_cut, ]
  c(up = sum(sig$log2FoldChange >= lfc_cut),
    down = sum(sig$log2FoldChange <= -lfc_cut))
}

# Main-effect DESeq2 results.
mainFiles <- c(Biotype = "biotype_results.txt",
               Virus   = "virus_results.txt",
               Time    = "time_results.txt")

# Pairwise time comparisons, in chronological order (later day vs earlier day,
# grouped the way Chen et al. Figure 1a groups "0h vs Xh" comparisons).
pairOrder <- c("1_vs_0",
               "2_vs_0", "2_vs_1",
               "3_vs_0", "3_vs_1", "3_vs_2",
               "5_vs_0", "5_vs_1", "5_vs_2", "5_vs_3",
               "10_vs_0", "10_vs_1", "10_vs_2", "10_vs_3", "10_vs_5",
               "15_vs_0", "15_vs_1", "15_vs_2", "15_vs_3", "15_vs_5", "15_vs_10",
               "20_vs_0", "20_vs_1", "20_vs_2", "20_vs_3", "20_vs_5", "20_vs_10", "20_vs_15")
pairFiles <- setNames(file.path("time_pairwise_results", paste0(pairOrder, ".txt")),
                      sub("_vs_", " vs ", pairOrder))

allFiles <- c(mainFiles, pairFiles)

counts <- t(sapply(allFiles, count_sig))
df <- data.frame(comparison = names(allFiles),
                  up = counts[, "up"],
                  down = counts[, "down"])
df$total <- df$up + df$down
df$comparison <- factor(df$comparison, levels = rev(df$comparison))

plotDF <- data.frame(comparison = rep(df$comparison, 2),
                      direction  = rep(c("Upregulated", "Downregulated"), each = nrow(df)),
                      count      = c(df$up, df$down))
# Upregulated segment plotted first (left), downregulated second (right),
# matching the red-then-blue layout of Chen et al. Figure 1a.
plotDF$direction <- factor(plotDF$direction, levels = c("Downregulated", "Upregulated"))

# In-bar count labels only fit cleanly when a segment is wide enough relative
# to the full axis range; below that, an outside-the-bar total is clearer
# than overlapping white-on-color text, so small segments are left unlabeled.
minLabelWidth <- max(df$total) * 0.035
labelDF <- df
labelDF$label_up   <- ifelse(df$up   >= minLabelWidth, df$up,   "")
labelDF$label_down <- ifelse(df$down >= minLabelWidth, df$down, "")

p <- ggplot(plotDF, aes(x = comparison, y = count, fill = direction)) +
  geom_col(width = 0.7) +
  geom_text(data = labelDF, aes(x = comparison, y = up / 2, label = label_up),
            inherit.aes = FALSE, size = 2.6, color = "white") +
  geom_text(data = labelDF, aes(x = comparison, y = up + down / 2, label = label_down),
            inherit.aes = FALSE, size = 2.6, color = "white") +
  geom_text(data = labelDF, aes(x = comparison, y = total, label = total),
            inherit.aes = FALSE, size = 2.6, hjust = -0.15) +
  scale_fill_manual(values = c(Downregulated = "#3B8FC4", Upregulated = "#E85B5B"),
                     breaks = c("Upregulated", "Downregulated")) +
  coord_flip(clip = "off") +
  expand_limits(y = max(df$total) * 1.08) +
  labs(x = NULL,
       y = "Number of DEGs (padj <= 0.05, |log2FC| >= 2)\nUpregulated = higher expression in the first-named group/timepoint (e.g. \"1 vs 0\" up = higher at day 1 than day 0)",
       fill = NULL,
       title = "Differentially expressed genes by comparison") +
  theme_minimal(base_size = 10) +
  theme(panel.grid.major.y = element_blank(),
        panel.grid.minor = element_blank(),
        legend.position = "top",
        axis.title.x = element_text(size = 7.5),
        plot.margin = margin(5, 30, 8, 5))

ggsave("wheat_DEG_counts_barplot.pdf", p, width = 7, height = 10)
cat("wrote wheat_DEG_counts_barplot.pdf -", nrow(df), "comparisons\n")
