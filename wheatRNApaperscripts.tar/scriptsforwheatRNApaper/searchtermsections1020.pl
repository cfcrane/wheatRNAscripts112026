#!/usr/bin/env perl
use warnings;
#This script takes a list of files and two lists of search terms (one term per line in each
#list file). For each listed file, it writes a separate output file with two sections: the
#first section has every line from that file containing any term from the first term list,
#the second section has every line containing any term from the second term list. The listed
#file's own header line (its first line) is copied to the start of both sections. Matching is
#a case-sensitive substring match, and a line is only reported once per section even if it
#matches more than one term in that list.
#Usage: perl searchtermsections1020.pl <file_list> <term_list_1> <term_list_2>
#e.g.:  perl searchtermsections1020.pl filestosearch.txt upterms.txt downterms.txt
die "Usage: perl $0 <file_list> <term_list_1> <term_list_2>\n" unless scalar(@ARGV) == 3;
$filelistfile = $ARGV[0];
$termlist1file = $ARGV[1];
$termlist2file = $ARGV[2];

sub readlist {
  my ($f) = @_;
  my @list = ();
  open(LIST, "<", $f) or die "Could not open $f: $!\n";
  while ($l = <LIST>) {
    chomp $l;
    $l =~ s/^\s+|\s+$//g;
    $l =~ s/^"(.*)"$/$1/; #so a filename or term quoted in the list file (e.g. "my file.txt") is read without the quote marks
    push @list, $l if length($l);
  }
  close(LIST);
  return @list;
}

@files = readlist($filelistfile);
@terms1 = readlist($termlist1file);
@terms2 = readlist($termlist2file);

foreach $file (@files) {
  open(IN, "<", $file) or die "Could not open $file: $!\n";
  @lines = <IN>;
  close(IN);
  $headerline = shift(@lines);

  $outfile = "$file.sections.txt";
  open(OUT, ">", $outfile) or die "Could not open $outfile: $!\n";

  print OUT "Section 1: lines from $file matching a term in $termlist1file\n";
  print OUT $headerline if defined($headerline);
  foreach $line (@lines) {
    foreach $term (@terms1) {
      if (index($line, $term) >= 0) {
        print OUT $line;
        last;
      }
    }
  }

  print OUT "\nSection 2: lines from $file matching a term in $termlist2file\n";
  print OUT $headerline if defined($headerline);
  foreach $line (@lines) {
    foreach $term (@terms2) {
      if (index($line, $term) >= 0) {
        print OUT $line;
        last;
      }
    }
  }

  close(OUT);
  print "Wrote $outfile\n";
}
