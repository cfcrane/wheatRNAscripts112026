#!/usr/bin/env perl
use warnings;
#This script compares two DESeq2 output files for shared significantly differentially expressed genes.
open (INA, "< $ARGV[0]"); #WheatRNA/result_files/virus_results.txt
open (INB, "< $ARGV[1]"); #WheatRNA/result_files/time_results.txt
open (OUT, "> $ARGV[2]");
$keyword = $ARGV[3]; #dehydrin, aquaporin
$cutoff = $ARGV[4]; #0.05
$line = <INA>; #tx_id   gene_id NCBI.GeneID     Description     baseMean        log2FoldChange  lfcSE   stat    pvalue  padj
while ($line = <INA>) {
  if ($line =~ m/$keyword/) {
    chomp $line;
    @vars = split(/\t/, $line);
    if ($vars[9] ne "NA" && $vars[9] <= $cutoff) {
      $sigsa{$vars[0]} = $vars[9];
      $descsa{$vars[0]} = $vars[3];
      $foldsa{$vars[0]} = $vars[5];
      $basesa{$vars[0]} = $vars[4];
    }
  }
}
$line = <INB>; #tx_id   gene_id NCBI.GeneID     Description     baseMean        log2FoldChange  lfcSE   stat    pvalue  padj
while ($line = <INB>) {
  if ($line =~ m/$keyword/) {
    chomp $line;
    @vars = split(/\t/, $line);
    if ($vars[9] ne "NA" && $vars[9] <= $cutoff) {
      $sigsb{$vars[0]} = $vars[9];
      $descsb{$vars[0]} = $vars[3];
      $foldsb{$vars[0]} = $vars[5];
      $basesb{$vars[0]} = $vars[4];
    }
  }
}
$incommons = 0;
for $key (keys(%sigsa)) {
  if (exists($sigsb{$key})) {
    $incommons++;
    print OUT "$key\t$descsa{$key}\t$basesa{$key}\t$foldsa{$key}\t$sigsa{$key}\t$basesb{$key}\t$foldsb{$key}\t$sigsb{$key}\n";
  }
}
print OUT "$incommons genes were shared.\n";
