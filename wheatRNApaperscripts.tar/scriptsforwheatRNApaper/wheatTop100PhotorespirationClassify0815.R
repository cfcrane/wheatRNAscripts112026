x <- read.delim("wheat_wgcna_top100_expressed_genes.txt", stringsAsFactors = FALSE)
desc <- x$description
desc[is.na(desc)] <- ""

# Photorespiratory glycolate pathway (glycolate oxidase) and the mitochondrial
# glycine decarboxylase complex / SHMT step, plus the chloroplastic GS2/Fd-GOGAT
# pair that reassimilates the ammonia photorespiration releases.
is_photoresp <- grepl(
  "peroxisomal \\(S\\)-2-hydroxy-acid oxidase|glycine cleavage system|serine hydroxymethyltransferase 1, mitochondrial|glutamine synthetase leaf isozyme, chloroplastic|ferredoxin-dependent glutamate synthase, chloroplastic",
  desc, ignore.case = TRUE)

photoresp <- x[is_photoresp, ]
photoresp <- photoresp[order(-photoresp$total_count), ]

cols <- c("gene_id", "gene_name", "description", "total_count", "mean_count",
          "module", "module_color", "accession", "start", "end")
write.table(photoresp[, cols], "wheat_top100_photorespiration.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("photorespiration: %d genes\n", nrow(photoresp)))
