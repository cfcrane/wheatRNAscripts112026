suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

# blockwiseModules split the 15,000 genes across 4 blocks (TOM is computed
# per block, not genome-wide), so there is one dendrogram per block rather
# than a single unified tree like Chen et al. Figure 2a. net$blockGenes[[i]]
# gives the column indices (into datExpr/moduleColors, in the order used by
# net$dendrograms[[i]]) of the genes clustered in block i.
nBlocks <- length(net$dendrograms)

for (i in seq_len(nBlocks)) {
  blockIdx <- net$blockGenes[[i]]
  blockColors <- moduleColors[blockIdx]

  outfile <- sprintf("wheat_geneDendro_block%d.pdf", i)
  pdf(outfile, width = 10, height = 6)
  plotDendroAndColors(net$dendrograms[[i]], blockColors,
                       groupLabels = "Module colors",
                       dendroLabels = FALSE, hang = 0.03,
                       addGuide = TRUE, guideHang = 0.05,
                       main = sprintf("Block %d gene dendrogram (%d genes)",
                                       i, length(blockIdx)))
  dev.off()
  cat("wrote", outfile, "-", length(blockIdx), "genes\n")
}
