suppressPackageStartupMessages(library(ggplot2))

padj_cut <- 0.05
lfc_cut  <- 2

# ---- Significant biotype DEGs ----
res <- read.delim("biotype_results.txt", stringsAsFactors = FALSE)
res <- res[!is.na(res$padj), ]
sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
sig$direction <- ifelse(sig$log2FoldChange >= lfc_cut, "Upregulated", "Downregulated")
sig <- unique(sig[, c("gene_id", "log2FoldChange", "direction")])

# ---- Gene -> accession/start/end. mstrg_annotated.tsv's gene_id column is a
# mix of LOC ids (when StringTie's own locus already matched a single ref
# gene) and MSTRG ids (when it didn't); either way the reference LOC id is
# always carried in gene_name, so join DESeq2's LOC gene_id against gene_name
# instead of gene_id. A handful of ref genes got split across two adjacent
# MSTRG loci (same gene_name, nearby coordinates) -- collapse those to one
# span (min start / max end) per gene_name. ----
names(sig)[names(sig) == "gene_id"] <- "gene_name"

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[ann$gene_name %in% sig$gene_name, ]  # shrink before grouping -- ann has 456k rows total
ann <- do.call(rbind, by(ann, ann$gene_name, function(d) {
  data.frame(gene_name = d$gene_name[1], accession = d$accession[1],
             start = min(d$start), end = max(d$end))
}))

# ---- accession -> chromosome name, true assembled chromosomes only ----
chrLen <- read.delim("wheatgenecounts/chromosome_lengths.tsv", stringsAsFactors = FALSE)

# Split each chromosome into its subgenome (A/B/D) and homoeologous group
# number (1-7), so A/B/D can be laid out as separate rows, each with its own
# 1-7 abutted axis.
chrLen$subgenome <- substr(chrLen$chr_name, nchar(chrLen$chr_name), nchar(chrLen$chr_name))
chrLen$chrNum <- as.integer(substr(chrLen$chr_name, 1, nchar(chrLen$chr_name) - 1))
chrLen$subgenome <- factor(chrLen$subgenome, levels = c("A", "B", "D"))
chrLen <- chrLen[order(chrLen$subgenome, chrLen$chrNum), ]

m <- merge(sig, ann, by = "gene_name")
m <- merge(m, chrLen, by = "accession")
cat(nrow(sig), "significant biotype DEGs;", nrow(m), "map to a true chromosome (",
    nrow(sig) - length(unique(m$gene_name)), "unmapped/on scaffolds or missing annotation )\n")

m$pos <- (m$start + m$end) / 2

# ---- Cumulative offset within each subgenome row, so 1-7 abut each other on
# that row's own linear axis (each row restarts at 0). ----
gapBp <- 3e6  # small fixed gap between chromosomes, purely to show the boundary
chrLen$cumStart <- unlist(lapply(split(chrLen, chrLen$subgenome), function(d) {
  cumsum(c(0, d$length[-nrow(d)])) + seq_len(nrow(d)) * gapBp
}))
m <- merge(m, chrLen[, c("chr_name", "cumStart")], by = "chr_name")
m$genomePos <- m$cumStart + m$pos

chrLen$chrMid <- chrLen$cumStart + chrLen$length / 2
chrLen$chrEnd <- chrLen$cumStart + chrLen$length

# Gray background box height cut 80% (1.0 -> 0.2, i.e. ymin/ymax pulled in
# from 0.5/1.5 to 0.9/1.1) while gene tick marks stay centered on y = 1.
boxHalfHeight <- 0.1

p <- ggplot() +
  geom_rect(data = chrLen, aes(xmin = cumStart, xmax = chrEnd,
                                ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
            fill = "grey92", color = "grey60", linewidth = 0.2) +
  geom_point(data = m, aes(x = genomePos, y = 1, color = direction),
             shape = 108, size = 4, alpha = 0.8) +
  geom_text(data = chrLen, aes(x = chrMid, y = 1 - boxHalfHeight - 0.15,
                                label = paste0(chrNum, subgenome)),
            size = 3, color = "grey30") +
  scale_color_manual(values = c(Upregulated = "#E85B5B", Downregulated = "#3B8FC4")) +
  scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
  facet_wrap(~ subgenome, ncol = 1, scales = "free_x") +
  labs(x = "Chromosome", y = NULL, color = NULL,
       title = sprintf("Biotype     padj <= %.2f, |log2FC| >= %d; n = %d genes",
                        padj_cut, lfc_cut, nrow(m))) +
  theme_minimal(base_size = 11) +
  theme(panel.grid = element_blank(),
        axis.text.x = element_blank(),
        legend.position = "top",
        strip.text = element_blank(),
        panel.spacing = unit(0.6, "lines"),
        plot.title = element_text(size = 11))

ggsave("wheat_biotype_DEG_chromosome_positions.pdf", p, width = 5, height = 6.5)
cat("wrote wheat_biotype_DEG_chromosome_positions.pdf\n")
