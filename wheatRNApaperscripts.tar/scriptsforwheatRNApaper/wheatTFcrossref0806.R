options(stringsAsFactors = FALSE)

padj_cut <- 0.05
lfc_cut  <- 2

# ---- Method 1: GO-term filter -- only true sequence-specific DNA-binding
# regulatory-TF terms, deliberately excluding basal transcription machinery
# (TFIIH/TFIID/TFIIA complexes etc., which are not the WRKY/MYB/bHLH-style
# regulatory TFs this search is after) ----
tfGO <- c("GO:0003700",  # DNA-binding transcription factor activity
          "GO:0000981",  # ...RNA polymerase II-specific
          "GO:0001228",  # DNA-binding transcription activator activity, RNA pol II-specific
          "GO:0000977",  # RNA pol II transcription regulatory region sequence-specific DNA binding
          "GO:1990837")  # sequence-specific double-stranded DNA binding

go <- read.delim("go_annotation/wheat_gene2go.tsv", stringsAsFactors = FALSE,
                  check.names = FALSE, comment.char = "")
goTFgenes <- unique(go$GeneID[go$GO_ID %in% tfGO])
cat(sprintf("GO-based TF gene set: %d wheat GeneIDs (any of %d TF-specific GO terms)\n",
            length(goTFgenes), length(tfGO)))

# ---- Method 2: narrow, TF-family-specific keyword search on Description --
# family-name terms (specific, low false-positive risk), plus a scoped
# "transcription factor" catch-all that explicitly excludes basal machinery
# (TFII*, general/elongation/initiation factors) so it doesn't just
# reproduce the GO set's own false-positive risks in reverse. ----
family_kw <- c("\\bMYB\\b", "MYB-related", "\\bWRKY\\b", "NAC domain",
               "\\bAP2\\b", "\\bERF\\b", "ethylene.responsive transcription factor",
               "ethylene.response factor", "\\bbZIP\\b", "\\bbHLH\\b", "MADS.box",
               "homeobox.leucine zipper", "homeodomain.leucine zipper", "\\bHD.Zip\\b",
               "Dof zinc finger", "\\bGRAS\\b", "\\bTCP\\b transcription", "trihelix",
               "GATA transcription factor", "zinc finger protein GATA",
               "B3 domain.*transcription factor", "squamosa promoter.binding",
               "auxin response factor", "heat stress transcription factor",
               "heat shock transcription factor", "BTB.{0,5}POZ",
               "NF.Y.*transcription", "CCAAT.binding transcription factor",
               "type.B response regulator", "two.component response regulator",
               # added after reviewing GO-only hits this search's keywords missed:
               "dehydration.responsive element.binding", "\\bDREB\\b", "\\bCBF\\b",
               "ocs element.binding", "ETHYLENE INSENSITIVE", "\\bEIN3\\b", "\\bEIL\\b",
               "homeobox protein knotted", "RADIALIS", "AT.hook motif nuclear.localized",
               "RNA polymerase sigma factor")

# Two genes carry a curated GO:0003700-family term (GO_TF = TRUE) that,
# on manual review of their Description, are clearly NOT transcription
# factors -- COPII vesicle coat assembly and a biosynthetic monooxygenase.
# Likely a mis-transferred automated (IEA-evidence) GO annotation. Excluded
# explicitly rather than silently, so the correction is visible/auditable.
knownGOfalsePositives <- c("123060659",  # COPII coat assembly protein sec16-like
                            "123121204")  # tyrosine N-monooxygenase-like

is_family_match <- function(desc) {
  if (is.na(desc) || !nzchar(desc)) return(FALSE)
  any(vapply(family_kw, function(k) grepl(k, desc, ignore.case = TRUE), logical(1)))
}
is_scoped_catchall <- function(desc) {
  if (is.na(desc) || !nzchar(desc)) return(FALSE)
  grepl("transcription factor", desc, ignore.case = TRUE) &&
    !grepl("TFII|general transcription factor|elongation factor|initiation factor|transcription factor complex|RNA polymerase", desc, ignore.case = TRUE)
}

analyze_condition <- function(resFile, label) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig <- sig[!duplicated(sig$gene_id), ]

  sig$GO_TF   <- sig$NCBI.GeneID %in% goTFgenes & !(sig$NCBI.GeneID %in% knownGOfalsePositives)
  sig$KW_TF   <- vapply(sig$Description, is_family_match, logical(1)) |
                 vapply(sig$Description, is_scoped_catchall, logical(1))
  sig$Any_TF  <- sig$GO_TF | sig$KW_TF

  nGO   <- sum(sig$GO_TF)
  nKW   <- sum(sig$KW_TF)
  nBoth <- sum(sig$GO_TF & sig$KW_TF)
  nGOonly <- sum(sig$GO_TF & !sig$KW_TF)
  nKWonly <- sum(sig$KW_TF & !sig$GO_TF)
  nUnion  <- sum(sig$Any_TF)

  cat(sprintf(
    "\n%-8s: %d significant DEGs; %d TFs (union) = %.1f%%  [GO-only %d, keyword-only %d, both %d]\n",
    label, nrow(sig), nUnion, 100 * nUnion / nrow(sig), nGOonly, nKWonly, nBoth))

  out <- sig[sig$Any_TF, c("gene_id", "NCBI.GeneID", "Description", "log2FoldChange",
                            "padj", "GO_TF", "KW_TF")]
  out <- out[order(out$padj), ]
  outfile <- paste0("wheat_", tolower(label), "_TF_DEGs.tsv")
  write.table(out, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("  wrote", outfile, "\n")

  data.frame(Condition = label, n_sig_DEGs = nrow(sig), n_TF_union = nUnion,
             pct_TF = round(100 * nUnion / nrow(sig), 1),
             n_GO_only = nGOonly, n_keyword_only = nKWonly, n_both = nBoth)
}

summaryTab <- do.call(rbind, list(
  analyze_condition("biotype_results.txt", "Biotype"),
  analyze_condition("virus_results.txt",   "Virus"),
  analyze_condition("time_results.txt",    "Time")
))

write.table(summaryTab, "wheat_TF_crossref_summary.tsv", sep = "\t", quote = FALSE, row.names = FALSE)
cat("\n==== Summary ====\n")
print(summaryTab, row.names = FALSE)
cat("\nwrote wheat_TF_crossref_summary.tsv\n")
