#!/usr/bin/perl
# Probability that two independent samples (sizes n and m, drawn with replacement
# from t objects) share at least k distinct objects.
# Usage: perl overlapprob.pl <t> <n> <m> <k>
use strict;
use warnings;

die "Usage: perl $0 <t> <n> <m> <k>\n" unless @ARGV == 4;
my ($t, $n, $m, $k) = @ARGV;
die "Require n < t, m < t, k < n, k < m\n"
    unless $n < $t && $m < $t && $k < $n && $k < $m;

# log factorials for stable binomials
my @lf = (0);
$lf[$_] = $lf[$_ - 1] + log($_) for 1 .. $t;
sub lchoose { my ($a, $b) = @_; return -1e300 if $b < 0 || $b > $a; $lf[$a] - $lf[$b] - $lf[$a - $b] }

# distribution of the number of distinct objects seen in d draws
sub distinct_dist {
    my ($d) = @_;
    my @p = (1);    # p[i] = P(i distinct); zero draws -> 0 distinct
    for (1 .. $d) {
        my @q = (0) x (@p + 1);
        for my $i (0 .. $#p) {
            next unless $p[$i];
            $q[$i]     += $p[$i] * $i / $t;
            $q[$i + 1] += $p[$i] * ($t - $i) / $t;
        }
        @p = @q;
    }
    return @p;
}

my @pa = distinct_dist($n);
my @pb = distinct_dist($m);

# Given A has i distinct and B has j distinct (sets uniform), overlap is hypergeometric
my $prob = 0;
for my $i (0 .. $#pa) {
    next unless $pa[$i];
    for my $j (0 .. $#pb) {
        next unless $pb[$j];
        my $hi = $i < $j ? $i : $j;
        my $lo = $k > $i + $j - $t ? $k : $i + $j - $t;
        my $h = 0;
        for my $s ($lo .. $hi) {
            $h += exp(lchoose($i, $s) + lchoose($t - $i, $j - $s) - lchoose($t, $j));
        }
        $prob += $pa[$i] * $pb[$j] * $h;
    }
}
printf "P(at least %d shared distinct objects) = %.10g\n", $k, $prob;
