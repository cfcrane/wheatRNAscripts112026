suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network_15k.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

outfile <- "wheat_geneDendro_15k.pdf"
pdf(outfile, width = 10, height = 6)  # landscape, matching wheat_geneDendro_block1.pdf
plotDendroAndColors(net$dendrograms[[1]], moduleColors,
                     groupLabels = "Module colors",
                     dendroLabels = FALSE, hang = 0.03,
                     addGuide = TRUE, guideHang = 0.05,
                     main = sprintf("Gene dendrogram (%d genes)", length(moduleColors)))
dev.off()
cat("wrote", outfile, "-", length(moduleColors), "genes\n")
