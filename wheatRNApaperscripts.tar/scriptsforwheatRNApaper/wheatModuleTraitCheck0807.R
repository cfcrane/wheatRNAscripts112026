suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)
load("wheat_wgcna_network_15k.RData")

nSamples <- nrow(datExpr)
traitCols <- coldata[, c("biotype", "virus", "day", "replicate")]
traitCols[] <- lapply(traitCols, as.factor)
datTraits <- binarizeCategoricalColumns(traitCols, considerColumns = colnames(traitCols),
                                         includePairwise = FALSE, includeLevelVsAll = TRUE,
                                         dropFirstLevelVsAll = FALSE)
rownames(datTraits) <- rownames(coldata)

moduleTraitCor <- cor(MEs, datTraits, use = "p")
moduleTraitP <- corPvalueStudent(moduleTraitCor, nSamples)
moduleTraitQ <- matrix(p.adjust(moduleTraitP, method = "BH"), nrow = nrow(moduleTraitP),
                        dimnames = dimnames(moduleTraitP))

keep <- grep("^biotype[.]|^virus[.]|^day[.]", colnames(datTraits))
qSub <- moduleTraitQ[, keep]
rSub <- moduleTraitCor[, keep]

cat("Module-trait pairs significant at q <= 0.05:\n\n")
for (i in seq_len(nrow(qSub))) {
  hits <- which(qSub[i, ] <= 0.05)
  if (length(hits) > 0) {
    modColor <- unique(moduleColors[moduleLabels == as.numeric(sub("ME", "", rownames(qSub)[i]))])
    for (h in hits) {
      cat(sprintf("%-5s (%-11s) vs %-20s  r=%6.3f  q=%.2e\n",
                   rownames(qSub)[i], modColor, colnames(qSub)[h], rSub[i, h], qSub[i, h]))
    }
  }
}
