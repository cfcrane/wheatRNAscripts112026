suppressPackageStartupMessages(library(dplyr))

padj_cut <- 0.05
lfc_cut  <- 2

go <- read.delim("go_annotation/wheat_gene2go.tsv", stringsAsFactors = FALSE,
                  check.names = FALSE, comment.char = "")
names(go)[names(go) == "#tax_id"] <- "tax_id"

# Collapse to one row per GeneID: pipe-joined GO IDs/terms/categories, so a
# gene with N GO annotations becomes one line instead of N. Evidence codes are
# dropped from the flat file but the raw per-annotation table is kept too, in
# case a downstream enrichment tool wants one-row-per-GO-term instead.
goByGene <- go %>%
  group_by(GeneID) %>%
  summarise(
    GO_ID       = paste(unique(GO_ID), collapse = "; "),
    GO_term     = paste(unique(GO_term), collapse = "; "),
    GO_category = paste(unique(Category), collapse = "; "),
    n_GO_terms  = n_distinct(GO_ID),
    .groups = "drop"
  )

annotate_sig <- function(resFile, label, outPrefix) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig$direction <- ifelse(sig$log2FoldChange >= lfc_cut, "Upregulated", "Downregulated")

  merged <- merge(sig, goByGene, by.x = "NCBI.GeneID", by.y = "GeneID", all.x = TRUE)
  merged <- merged[order(merged$padj), ]

  nWithGO <- sum(!is.na(merged$GO_ID))
  cat(sprintf("%-8s: %d significant DEGs; %d have >=1 GO term (%d without)\n",
              label, nrow(sig), nWithGO, nrow(sig) - nWithGO))

  outfile <- paste0(outPrefix, "_sig_with_GO.tsv")
  write.table(merged, outfile, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
  cat("  wrote", outfile, "\n")

  # One-row-per-GO-term long format, for enrichment tools (e.g. topGO, clusterProfiler)
  # that expect a simple gene<TAB>GO_ID mapping.
  long <- merge(sig[, c("gene_id", "NCBI.GeneID", "direction")], go[, c("GeneID", "GO_ID")],
                by.x = "NCBI.GeneID", by.y = "GeneID")
  longOut <- paste0(outPrefix, "_sig_GO_long.tsv")
  write.table(unique(long), longOut, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("  wrote", longOut, "\n")
}

annotate_sig("biotype_results.txt", "Biotype", "wheat_biotype")
annotate_sig("virus_results.txt",   "Virus",   "wheat_virus")
annotate_sig("time_results.txt",    "Time",    "wheat_time")
