options(stringsAsFactors = FALSE)

# ============================================================
# Full per-gene roster for each of the 14 named WGCNA modules (module 0 =
# grey/unassigned genes, excluded here). Uses the canonical 14-module
# clustering in wheat_wgcna_network_15k.RData (the file all module
# network/heatmap figures are built from), NOT wheat_wgcna_network.RData,
# which is an earlier 4-block run with a different (18-module) clustering
# over the same 15,000 genes.
# ============================================================
load("wheat_wgcna_network_15k.RData")  # datExpr, moduleLabels, moduleColors, MEs, coldata, net

geneIDs <- colnames(datExpr)

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[!duplicated(ann$gene_id), ]

# IWGSC CS RefSeq v2.1 (GCF_018294505.1) chromosome accessions, in the
# standard 1A..7D order -- confirmed by coordinate cross-check against
# iwgsc_refseqv2.1_annotation_200916_HC.gff3 (e.g. NC_057806.1:10147-18369
# matches Chr5A:10126-18461). NC_036024.1 carries mitochondrial genes
# (locus_tag CRD53_mgp*); NW_* are unplaced scaffolds.
chrOrder <- c("1A","1B","1D","2A","2B","2D","3A","3B","3D","4A","4B","4D",
              "5A","5B","5D","6A","6B","6D","7A","7B","7D")
chrAccessions <- sprintf("NC_%06d.1", 57794:57814)
chrMap <- setNames(chrOrder, chrAccessions)
chrMap["NC_036024.1"] <- "Mt"

chromosomeFor <- function(acc) {
  ifelse(is.na(acc), NA,
         ifelse(acc %in% names(chrMap), chrMap[acc],
                ifelse(grepl("^NW_", acc), "Un", acc)))
}

for (moduleNum in 1:14) {
  modGenes <- geneIDs[moduleLabels == moduleNum]
  modColor <- unique(moduleColors[moduleLabels == moduleNum])

  meCol <- paste0("ME", moduleNum)
  kME <- sapply(modGenes, function(g) cor(datExpr[, g], MEs[, meCol], use = "p"))

  annMod <- ann[match(modGenes, ann$gene_id), ]

  out <- data.frame(
    gene_id     = modGenes,
    kME         = round(kME, 4),
    chromosome  = chromosomeFor(annMod$accession),
    gene_name   = annMod$gene_name,
    description = annMod$description,
    start       = annMod$start,
    end         = annMod$end,
    stringsAsFactors = FALSE
  )
  out <- out[order(-out$kME), ]

  outFile <- sprintf("wheat_module%d_gene_roster.txt", moduleNum)
  write.table(out, outFile, sep = "\t", quote = FALSE, row.names = FALSE)
  cat(sprintf("Module %2d (%s): %d genes -> %s\n", moduleNum, modColor, nrow(out), outFile))
}
cat("done\n")
