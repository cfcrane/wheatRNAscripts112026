suppressPackageStartupMessages({
  library(ComplexHeatmap)
  library(circlize)
})
options(stringsAsFactors = FALSE)

# ============================================================
# Reproduce the exact node set (hub genes + top target genes, with
# Hub/Regulatory/Structural roles) from wheatModule8Network0805.R -- this
# part of that script is fully deterministic (only the ggraph layout uses a
# random seed), so re-running it here yields the identical 4 hubs + up-to-20
# targets shown in wheat_module8_coexpression_network.pdf.
# ============================================================
padj_cut     <- 0.05
lfc_cut      <- 2
nHub         <- 4
nTargetMax   <- 20
nearMaxFrac  <- 0.8
moduleNum    <- 8
nchar        <- 40   # max row-label length (chars) guaranteed not to be truncated

load("wheat_wgcna_network_15k.RData")   # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata
load("wheatTOM_15k-block.1.RData")      # TOM

geneIDs   <- colnames(datExpr)
mod8genes <- geneIDs[moduleLabels == moduleNum]
modColor  <- unique(moduleColors[moduleLabels == moduleNum])

meCol <- paste0("ME", moduleNum)
kME <- sapply(mod8genes, function(g) cor(datExpr[, g], MEs[, meCol], use = "p"))
kME <- sort(kME, decreasing = TRUE)
hubGenes <- names(head(kME, nHub))

idx <- match(mod8genes, geneIDs)
TOMmat <- as.matrix(TOM)[idx, idx]
dimnames(TOMmat) <- list(mod8genes, mod8genes)
rm(TOM); gc()

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[ann$gene_id %in% mod8genes, c("gene_id", "gene_name", "description")]
ann <- ann[!duplicated(ann$gene_id), ]

load_sig <- function(f) {
  r <- read.delim(f, stringsAsFactors = FALSE)
  r <- r[!is.na(r$padj) & r$padj <= padj_cut & abs(r$log2FoldChange) >= lfc_cut, ]
  unique(r$gene_id)
}
sigLOC <- unique(c(load_sig("biotype_results.txt"),
                    load_sig("virus_results.txt"),
                    load_sig("time_results.txt")))

ann$is_sig_DEG <- ann$gene_name %in% sigLOC
targetCandidates <- setdiff(ann$gene_id[ann$is_sig_DEG], hubGenes)

wMat <- sapply(hubGenes, function(h) TOMmat[h, targetCandidates])
targetMax <- apply(wMat, 1, max)
keepTargets <- names(sort(targetMax, decreasing = TRUE))[seq_len(min(nTargetMax, length(targetMax)))]

regulatory_kw <- c("transcription factor", "zinc.finger", "ethylene.responsive",
                    "\\bERF\\b", "WRKY", "\\bMYB\\b", "bZIP", "bHLH", "NAC domain",
                    "BTB", "POZ", "homeobox", "MADS.box", "\\bAP2\\b", "response regulator")
is_regulatory <- function(desc) {
  if (is.na(desc)) return(FALSE)
  any(vapply(regulatory_kw, function(k) grepl(k, desc, ignore.case = TRUE), logical(1)))
}

nodeIDs <- unique(c(hubGenes, keepTargets))
nodeAnn <- ann[match(nodeIDs, ann$gene_id), ]
nodeAnn$role <- ifelse(nodeAnn$gene_id %in% hubGenes, "Hub",
                        ifelse(vapply(nodeAnn$description, is_regulatory, logical(1)),
                               "Regulatory", "Structural"))
nodeAnn$label <- ifelse(!is.na(nodeAnn$gene_name) & nzchar(nodeAnn$gene_name),
                         nodeAnn$gene_name, nodeAnn$gene_id)
# "uncharacterized" descriptions are just "uncharacterized <gene_id>", which
# repeats the locus name already shown in the row label -- drop the repeat.
isUnchar <- !is.na(nodeAnn$description) & grepl("^uncharacterized\\b", nodeAnn$description, ignore.case = TRUE)
nodeAnn$descShort <- ifelse(isUnchar, "uncharacterized",
                      ifelse(!is.na(nodeAnn$description) & nzchar(nodeAnn$description),
                             substr(nodeAnn$description, 1, 40), "unannotated"))
cat(sprintf("Heatmap node set: %d genes (%d hub, %d target)\n",
            nrow(nodeAnn), length(hubGenes), length(keepTargets)))
print(table(nodeAnn$role))

# ============================================================
# Row-scaled (z-score) VST expression, one row per network gene, columns =
# all 86 samples grouped by day (as an ordinal factor, matching Chen et al.
# Figure 7's 0/1/6/24/48 h groups) rather than clustered.
# ============================================================
dayLevels <- c("0", "1", "2", "3", "5", "10", "15", "20")
coldata$day <- factor(coldata$day, levels = dayLevels, ordered = TRUE)
sampleOrder <- order(coldata$day, coldata$biotype, coldata$virus, coldata$replicate)
samplesOrdered <- rownames(datExpr)[sampleOrder]

mat <- t(datExpr[samplesOrdered, nodeAnn$gene_id, drop = FALSE])  # genes x samples
matZ <- t(scale(t(mat)))  # z-score each gene (row) across samples

rowLabel <- paste0(nodeAnn$label, " (", nodeAnn$descShort, ")")
# Labels shorter than `nchar` are guaranteed to display in full (see width
# calculation below); longer ones are truncated to exactly `nchar` characters.
rowLabel <- ifelse(base::nchar(rowLabel) > nchar,
                    paste0(substr(rowLabel, 1, nchar - 3), "..."),
                    rowLabel)
rownames(matZ) <- rowLabel

roleColors <- c(Hub = "#E34948", Regulatory = "#1baf7a", Structural = "#2a78d6")
rowTextCol <- roleColors[nodeAnn$role]

dayCol     <- setNames(viridisLite::turbo(length(dayLevels)), dayLevels)
biotypeCol <- c(B = "#1b9e77", H = "#d95f02", not_infested = "#999999")
virusCol   <- c(virus_free = "#7570b3", carrier = "#e7298a")

topAnn <- HeatmapAnnotation(
  day     = coldata[samplesOrdered, "day"],
  biotype = coldata[samplesOrdered, "biotype"],
  virus   = coldata[samplesOrdered, "virus"],
  col = list(day = dayCol, biotype = biotypeCol, virus = virusCol),
  annotation_name_side = "left",
  simple_anno_size = unit(3, "mm"),
  annotation_legend_param = list(
    day     = list(direction = "horizontal", nrow = 1),
    biotype = list(direction = "horizontal", nrow = 1),
    virus   = list(direction = "horizontal", nrow = 1)
  )
)

col_fun <- colorRamp2(c(-2, 0, 2), c("#2166ac", "white", "#b2182b"))

# Fixed per-gene row height and fixed vertical overhead (title + annotation
# bars + legends), so all wheat_module{N}_coexpression_heatmap.pdf files use
# the same physical row height regardless of gene count (see
# wheatModuleHeatmapAll0818.R, which applies this to the other modules).
ROW_H_MM    <- 5.2294
OVERHEAD_IN <- 1.3588
nGenes <- nrow(matZ)

# Everything to the left of the row-name column (heatmap body + annotation +
# legends) previously got whatever was left of the fixed 11in page width
# after ComplexHeatmap's default 6cm row-name column -- keep that same
# left-hand width, and instead size the row-name column to fit the longest
# label (up to `nchar` characters) so labels under `nchar` are never clipped.
BODY_AND_REST_IN   <- 11 - 2.362205  # 11in page - default 6cm row_names_max_width
ROW_NAME_PAD_IN    <- 0.15           # margin so text isn't flush with the page edge
pdf(NULL)
rowNameWidthIn <- max(sapply(rowLabel, function(s)
  grid::convertWidth(grid::grobWidth(grid::textGrob(s, gp = gpar(fontsize = 8))),
                      "inches", valueOnly = TRUE)))
dev.off()
rowNameWidthIn <- rowNameWidthIn + ROW_NAME_PAD_IN

ht <- Heatmap(
  matZ,
  name = "z-score",
  col = col_fun,
  top_annotation = topAnn,
  height = unit(nGenes * ROW_H_MM, "mm"),
  cluster_columns = FALSE,
  cluster_rows = TRUE,
  clustering_distance_rows = "euclidean",
  clustering_method_rows = "complete",
  show_column_names = FALSE,
  row_names_side = "right",
  row_names_gp = gpar(col = rowTextCol, fontsize = 8),
  row_names_max_width = unit(rowNameWidthIn, "inches"),
  column_title = sprintf("Module %d (%s module) co-expression network genes: expression by day", moduleNum, modColor),
  column_title_gp = gpar(fontsize = 12, fontface = "bold"),
  heatmap_legend_param = list(title = "row z-score", direction = "horizontal")
)

pdfWidth <- BODY_AND_REST_IN + rowNameWidthIn
pdf("wheat_module8_coexpression_heatmap.pdf", width = pdfWidth, height = OVERHEAD_IN + nGenes * ROW_H_MM / 25.4)
draw(ht, heatmap_legend_side = "bottom", annotation_legend_side = "bottom", merge_legends = TRUE)
dev.off()
cat("wrote wheat_module8_coexpression_heatmap.pdf\n")
