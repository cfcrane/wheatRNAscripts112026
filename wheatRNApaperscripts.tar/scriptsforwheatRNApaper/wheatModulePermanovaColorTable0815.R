suppressPackageStartupMessages({
  library(officer)
  library(flextable)
})

padj_cut <- 0.05

# ============================================================
# 1. Module gene membership (MSTRG ids) -> LOC/ref gene ids used in the
#    univariate DESeq2 result files, via the mstrg_annotated.tsv crosswalk.
# ============================================================
load("wheat_wgcna_network_15k.RData")  # datExpr, moduleLabels, moduleColors

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
xwalk <- setNames(ann$gene_name, ann$gene_id)

modGeneIds <- lapply(1:14, function(i) colnames(datExpr)[moduleLabels == i])
modGeneNames <- lapply(modGeneIds, function(g) {
  nm <- xwalk[g]
  nm <- nm[!is.na(nm) & nm != ""]
  unique(unname(nm))
})
names(modGeneNames) <- 1:14

# ============================================================
# 2. Univariate DESeq2 result files and confirmed sign conventions
#    (verified empirically against the raw HTSeq count matrix in the prior
#    session: biotype_results.txt numerator is B, NOT H -- positive
#    log2FoldChange means higher expression in biotype B, so "up-regulated
#    with biotype H" corresponds to a NEGATIVE log2FoldChange in that file.
#    virus_results.txt numerator is carrier, so positive = up with virus.
#    time20vs0.txt numerator is day 20, so positive = up at day 20.)
# ============================================================
biotype_res <- read.delim("biotype_results.txt", stringsAsFactors = FALSE)
virus_res   <- read.delim("virus_results.txt",   stringsAsFactors = FALSE)
day_res     <- read.delim("time20vs0.txt",       stringsAsFactors = FALSE)

tests <- list(
  biotype = list(res = biotype_res, upIsPositive = FALSE, upLabel = "up with biotype H",   downLabel = "up with biotype B"),
  virus   = list(res = virus_res,   upIsPositive = TRUE,  upLabel = "up with virus",        downLabel = "up with no virus"),
  day     = list(res = day_res,     upIsPositive = TRUE,  upLabel = "up at day 20",         downLabel = "up at day 0")
)

# For each module x test: count significant genes (padj <= 0.05) up vs down,
# per the sign convention for that test's "up" direction, and record which
# direction is the majority.
moduleDirection <- data.frame()
for (modNum in 1:14) {
  genes <- modGeneNames[[as.character(modNum)]]
  for (testName in names(tests)) {
    t <- tests[[testName]]
    r <- t$res[t$res$gene_id %in% genes & !is.na(t$res$padj) & t$res$padj <= padj_cut, ]
    if (!t$upIsPositive) {
      nUp   <- sum(r$log2FoldChange < 0)
      nDown <- sum(r$log2FoldChange > 0)
    } else {
      nUp   <- sum(r$log2FoldChange > 0)
      nDown <- sum(r$log2FoldChange < 0)
    }
    majority <- if (nUp > nDown) "up" else "down"
    moduleDirection <- rbind(moduleDirection, data.frame(
      module = modNum, test = testName,
      n_significant = nrow(r), n_up = nUp, n_down = nDown,
      majority = majority,
      majority_label = if (majority == "up") t$upLabel else t$downLabel,
      stringsAsFactors = FALSE
    ))
  }
}

write.table(moduleDirection, "wheat_module_updown_counts.txt", sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("wrote wheat_module_updown_counts.txt\n")

# ============================================================
# 3. Master PERMANOVA table -> Word doc, with biotype/virus/day cells
#    colored red (majority up, per the labels above) or blue (majority not
#    up) whenever that cell's adjusted p-value is significant (<= 0.05).
# ============================================================
master <- read.delim("wheatmodulepermanovamastertable.txt", stringsAsFactors = FALSE,
                      check.names = FALSE, row.names = NULL)
# header has 9 names but rows have 10 fields (module number, color, gene
# count, then the 7 named test columns): row.names=NULL keeps the leading
# module-number field as a real column instead of silently consuming it as
# row names and shifting every other column over by one.
names(master) <- c("module_num", "module", "n_genes", "biotype", "virus", "day",
                    "biotype:virus", "biotype:day", "virus:day", "biotype:virus:day")
master$module_num <- as.integer(master$module_num)

get_padj <- function(cell) {
  m <- regmatches(cell, regexpr("\\(([^)]+)\\)", cell))
  as.numeric(gsub("[()]", "", m))
}

majorityFor <- function(modNum, testName) {
  row <- moduleDirection[moduleDirection$module == modNum & moduleDirection$test == testName, ]
  row$majority
}

ft <- flextable(master)
ft <- set_header_labels(ft, module_num = "module", module = "color", n_genes = "n genes")
ft <- theme_booktabs(ft)
ft <- fontsize(ft, size = 9, part = "all")
ft <- fontsize(ft, size = 9, part = "header")
ft <- align(ft, align = "center", part = "all")
ft <- align(ft, j = 1:2, align = "left", part = "all")

for (i in seq_len(nrow(master))) {
  modNum <- master$module_num[i]
  for (testName in c("biotype", "virus", "day")) {
    cellVal <- master[[testName]][i]
    padj <- get_padj(cellVal)
    if (!is.na(padj) && padj <= padj_cut) {
      dir <- majorityFor(modNum, testName)
      col <- if (dir == "up") "red" else "blue"
      ft <- color(ft, i = i, j = testName, color = col, part = "body")
    }
  }
}

ft <- fontsize(ft, size = 8, part = "all")
ft <- padding(ft, padding.left = 2, padding.right = 2, part = "all")
ft <- width(ft, j = "module_num", width = 0.5)
ft <- width(ft, j = "module", width = 0.7)
ft <- width(ft, j = "n_genes", width = 0.5)
ft <- width(ft, j = c("biotype", "virus", "day"), width = 0.85)
ft <- width(ft, j = c("biotype:virus", "biotype:day", "virus:day", "biotype:virus:day"), width = 0.95)

doc <- read_docx()
doc <- body_add_par(doc, "Wheat WGCNA module PERMANOVA results", style = "heading 1")
doc <- body_add_par(doc,
  paste0("Red = adjusted p ≤ 0.05 and the majority of significant genes in that module ",
         "are up-regulated with biotype H (biotype column), with virus vs. no virus (virus column), ",
         "or at day 20 vs. day 0 (day column). Blue = adjusted p ≤ 0.05 but the majority go the ",
         "other direction. Other cells/columns are reproduced unchanged."),
  style = "Normal")
doc <- body_add_flextable(doc, ft)
doc <- body_end_section_landscape(doc, w = 15.85, h = 12.2)
print(doc, target = "wheat_module_permanova_master_table.docx")
cat("wrote wheat_module_permanova_master_table.docx\n")
