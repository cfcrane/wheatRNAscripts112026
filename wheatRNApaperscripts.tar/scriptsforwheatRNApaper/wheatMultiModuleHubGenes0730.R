suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

targetMEs <- c("ME9", "ME14", "ME0")

kME <- signedKME(datExpr, MEs, outputColumnName = "kME")
top_hub_all <- chooseTopHubInEachModule(datExpr, moduleColors, power = 6, type = "unsigned")

for (targetME in targetMEs) {
  targetLabel <- as.numeric(sub("ME", "", targetME))
  targetColor <- unique(moduleColors[moduleLabels == targetLabel])
  stopifnot(length(targetColor) == 1)
  inModule <- moduleColors == targetColor
  kMEcol <- paste0("kME", targetLabel)

  hub_table <- data.frame(gene = colnames(datExpr)[inModule],
                           kME = kME[inModule, kMEcol])
  hub_table <- hub_table[order(-hub_table$kME), ]

  outfile <- paste0("wheat_", targetME, "_hub_genes.tsv")
  write.table(hub_table, outfile, sep = "\t", quote = FALSE, row.names = FALSE)

  cat("\n====", targetME, "= module color '", targetColor, "', ", sum(inModule),
      " genes ====\n", sep = "")
  cat("top 20 by module membership (kME), written in full to", outfile, ":\n")
  print(head(hub_table, 20), row.names = FALSE)
  cat("top hub by intramodular connectivity:", top_hub_all[targetColor], "\n")
}
