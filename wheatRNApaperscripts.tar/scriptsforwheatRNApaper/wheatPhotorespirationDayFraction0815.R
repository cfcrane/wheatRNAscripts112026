x <- readRDS("wheat_gene_counts_and_coldata.rds")
counts <- x$counts
coldata <- x$coldata

pr <- read.delim("wheat_top100_photorespiration.txt", stringsAsFactors = FALSE)
prGenes <- unique(pr$gene_id)
stopifnot(all(prGenes %in% rownames(counts)))
cat("photorespiration gene set:", length(prGenes), "genes\n")

summarize_day <- function(dayLevel) {
  samples <- coldata$sampleName[coldata$day == dayLevel]
  sub <- counts[, samples, drop = FALSE]
  totalMRNA <- sum(sub)
  geneSum <- sum(sub[prGenes, ])
  data.frame(day = dayLevel, n_samples = length(samples),
             photorespiration_gene_count = geneSum,
             total_mRNA_count = totalMRNA,
             fraction = geneSum / totalMRNA)
}

days <- c("1", "2", "3", "5", "10", "15", "20")
res <- do.call(rbind, lapply(days, summarize_day))
write.table(res, "wheat_photorespiration_day1_day20_fraction.txt", sep = "\t",
            quote = FALSE, row.names = FALSE)
print(res, row.names = FALSE)
