#!/usr/bin/env perl
use warnings;
#This script is probably redundant.  It counts significantly regulated genes.
open (INP, "< $ARGV[0]"); #WheatRNA/result_files/biotype_results.txt
$cutoff = $ARGV[1]; #0.05
$line = <INP>;
$nup = 0; $ndown = 0;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #tx_id   gene_id NCBI.GeneID     Description     baseMean        log2FoldChange  lfcSE   stat    pvalue  padj
  if ($vars[-1] ne "NA") {
    if ($vars[-1] <= $cutoff) {
      if ($vars[5] > 0) {$nup++;}
      else {$ndown++;}
    }
  }
}
print "up = $nup down = $ndown\n";
