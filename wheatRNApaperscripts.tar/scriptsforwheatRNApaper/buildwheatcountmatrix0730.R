coldata <- read.table("SRR32566columndata.txt", header = TRUE, sep = "\t",
                       stringsAsFactors = FALSE)
coldata$day <- factor(coldata$day)

read_htseq <- function(f) {
  d <- read.table(f, header = FALSE, sep = "\t",
                   col.names = c("gene_id", "count"),
                   stringsAsFactors = FALSE)
  d[!grepl("^__", d$gene_id), ]
}

counts_list <- lapply(coldata$file, read_htseq)
names(counts_list) <- coldata$sampleName

gene_ids <- counts_list[[1]]$gene_id
stopifnot(all(sapply(counts_list, function(d) identical(d$gene_id, gene_ids))))

count_matrix <- sapply(counts_list, function(d) d$count)
rownames(count_matrix) <- gene_ids
stopifnot(identical(colnames(count_matrix), coldata$sampleName))

out <- data.frame(gene_id = rownames(count_matrix), count_matrix, check.names = FALSE)
write.table(out, "wheat_gene_counts.tsv", sep = "\t", quote = FALSE, row.names = FALSE)

saveRDS(list(counts = count_matrix, coldata = coldata), "wheat_gene_counts_and_coldata.rds")

cat("genes:", nrow(count_matrix), "  samples:", ncol(count_matrix), "\n")
cat("day levels:", paste(levels(coldata$day), collapse = ", "), "\n")
