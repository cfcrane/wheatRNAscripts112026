#!/usr/bin/env perl
use warnings;
#This script takes an input file formatted like WheatRNA/result_files/virus_results.txt (a
#tab-delimited DESeq2 results table with a header row including Description, log2FoldChange
#and padj columns) and a keyword. It reports: the number of lines whose Description contains
#the keyword, how many of those have a positive log2FoldChange, how many have a negative
#log2FoldChange, how many have a positive log2FoldChange AND a significant padj (< threshold,
#default 0.05), and how many have a negative log2FoldChange AND a significant padj.
#Matching is a case-sensitive substring match against the whole line, as in
#searchtermsections1020.pl.
#Usage: perl countkeywordmatches1023.pl <input> <keyword> [threshold]
#e.g.:  perl countkeywordmatches1023.pl WheatRNA/result_files/virus_results.txt chlorophyll
die "Usage: perl $0 <input> <keyword> [threshold]\n" unless scalar(@ARGV) == 2 || scalar(@ARGV) == 3;
$infile = $ARGV[0];
$keyword = $ARGV[1];
$threshold = scalar(@ARGV) == 3 ? $ARGV[2] : 0.05;

open(IN, "<", $infile) or die "Could not open $infile: $!\n";

$headerline = <IN>;
chomp $headerline;
@hvars = split(/\t/, $headerline);
$lfccol = -1;
$padjcol = -1;
for ($i = 0; $i < scalar(@hvars); $i++) {
  $lfccol = $i if $hvars[$i] eq "log2FoldChange" || $hvars[$i] eq "LFC";
  $padjcol = $i if $hvars[$i] eq "padj";
}
die "Column 'log2FoldChange' not found in $infile\n" if $lfccol < 0;
die "Column 'padj' not found in $infile\n" if $padjcol < 0;

$total = 0;
$up = 0;
$down = 0;
$sigup = 0;
$sigdown = 0;
while ($line = <IN>) {
  next unless index($line, $keyword) >= 0;
  chomp $line;
  @vars = split(/\t/, $line);
  $lfc = $vars[$lfccol];
  $padj = $vars[$padjcol];
  next unless defined($lfc) && $lfc =~ m/^-?\d*\.?\d+(?:[eE][-+]?\d+)?$/;
  $total++;
  $issig = defined($padj) && $padj =~ m/^-?\d*\.?\d+(?:[eE][-+]?\d+)?$/ && $padj < $threshold;
  if ($lfc > 0) {
    $up++;
    $sigup++ if $issig;
  } elsif ($lfc < 0) {
    $down++;
    $sigdown++ if $issig;
  }
}
close(IN);

print "File: $infile\n";
print "Keyword: $keyword\n";
print "Significance threshold (padj): $threshold\n";
print "Total matching lines: $total\n";
print "Up-regulated (log2FoldChange > 0): $up\n";
print "Down-regulated (log2FoldChange < 0): $down\n";
print "Significant and up-regulated: $sigup\n";
print "Significant and down-regulated: $sigdown\n";
