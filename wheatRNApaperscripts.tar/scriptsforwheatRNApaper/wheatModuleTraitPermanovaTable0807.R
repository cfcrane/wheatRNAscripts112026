suppressPackageStartupMessages(library(vegan))
options(stringsAsFactors = FALSE)
set.seed(1)

load("wheat_wgcna_network_15k.RData")  # datExpr, coldata, MEs, moduleLabels, moduleColors

# ---- Common sample subset: same as wheatPERMANOVA0805.R / wheatModulePERMANOVA0807.R
# -- excludes the day-0/not_infested baseline (structurally confounded, can't
# participate in a biotype x virus x day factorial), leaving 83 samples in a
# clean 2 (biotype) x 2 (virus) x 7 (day) design. Both halves of this table
# use this SAME 83-sample subset so the two views are directly comparable
# (wheatModuleTraitCheck0807.R originally used the full 86-sample set with
# multi-level binarized traits; here biotype and virus are recoded as simple
# 0/1 binaries and day as continuous, to get one correlation per module per
# factor rather than one per trait level). ----
keep <- coldata$biotype %in% c("B", "H") & coldata$day != 0
cd <- droplevels(coldata[keep, ])
cd$biotypeNum <- as.numeric(factor(cd$biotype, levels = c("B", "H"))) - 1  # B=0, H=1
cd$virusNum   <- as.numeric(factor(cd$virus, levels = c("virus_free", "carrier"))) - 1  # virus_free=0, carrier=1
cd$dayNum     <- as.numeric(as.character(cd$day))
cd$biotype    <- factor(cd$biotype)
cd$virus      <- factor(cd$virus)
cd$day        <- factor(cd$day, levels = c("1", "2", "3", "5", "10", "15", "20"))

MEsub <- MEs[keep, , drop = FALSE]
stopifnot(identical(rownames(MEsub), rownames(cd)))

modNums <- sort(unique(moduleLabels))  # includes 0 (grey/unassigned -- not a
                                        # true co-expression module, kept for
                                        # completeness, flagged in the notes)

# ---- Part 1: eigengene correlation, one r/p per module per factor ----
corDF <- do.call(rbind, lapply(modNums, function(m) {
  meCol <- paste0("ME", m)
  ct_b <- cor.test(MEsub[, meCol], cd$biotypeNum)
  ct_v <- cor.test(MEsub[, meCol], cd$virusNum)
  ct_d <- cor.test(MEsub[, meCol], cd$dayNum)
  data.frame(module = m,
             eigenCor_biotype_r = ct_b$estimate, eigenCor_biotype_p = ct_b$p.value,
             eigenCor_virus_r   = ct_v$estimate, eigenCor_virus_p   = ct_v$p.value,
             eigenCor_day_r     = ct_d$estimate, eigenCor_day_p     = ct_d$p.value,
             eigenCor_df = ct_b$parameter)
}))
corDF$eigenCor_biotype_q <- p.adjust(corDF$eigenCor_biotype_p, method = "BH")
corDF$eigenCor_virus_q   <- p.adjust(corDF$eigenCor_virus_p,   method = "BH")
corDF$eigenCor_day_q     <- p.adjust(corDF$eigenCor_day_p,     method = "BH")

# ---- Part 2: per-module PERMANOVA, main-effect (biotype/virus/day) rows only
# -- same sequential model as wheatModulePERMANOVA0807.R ----
run_module_permanova <- function(moduleNum) {
  modGenes <- colnames(datExpr)[moduleLabels == moduleNum]
  expr <- datExpr[keep, modGenes, drop = FALSE]
  d <- dist(expr, method = "euclidean")
  fit <- adonis2(d ~ biotype * virus * day, data = cd, permutations = 999, by = "terms")
  res <- as.data.frame(fit)
  data.frame(module = moduleNum,
             permanova_biotype_R2 = res["biotype", "R2"], permanova_biotype_p = res["biotype", "Pr(>F)"],
             permanova_biotype_df = res["biotype", "Df"],
             permanova_virus_R2   = res["virus", "R2"],   permanova_virus_p   = res["virus", "Pr(>F)"],
             permanova_virus_df   = res["virus", "Df"],
             permanova_day_R2     = res["day", "R2"],     permanova_day_p     = res["day", "Pr(>F)"],
             permanova_day_df     = res["day", "Df"])
}

cat("Running per-module PERMANOVA for", length(modNums), "modules...\n")
permDF <- do.call(rbind, lapply(modNums, function(m) {
  cat("  module", m, "...\n")
  run_module_permanova(m)
}))
permDF$permanova_biotype_q <- p.adjust(permDF$permanova_biotype_p, method = "BH")
permDF$permanova_virus_q   <- p.adjust(permDF$permanova_virus_p,   method = "BH")
permDF$permanova_day_q     <- p.adjust(permDF$permanova_day_p,     method = "BH")

# ---- Merge, attach module color, round for readability ----
modColorOf <- sapply(modNums, function(m) unique(moduleColors[moduleLabels == m]))
merged <- merge(corDF, permDF, by = "module")
merged$moduleColor <- modColorOf[match(merged$module, modNums)]
merged <- merged[order(merged$module), ]
saveRDS(merged, "wheat_module_trait_PERMANOVA_merged.rds")  # full-precision, for reformatting later without rerunning PERMANOVA

r3 <- function(x) sprintf("%.3f", x)
# %.3f normally; fall back to scientific notation only when that would floor
# a genuinely nonzero value to "0.000" (i.e. |x| < 0.0005), so small q-values
# stay legible instead of reading as exactly zero.
sig <- function(x) ifelse(x != 0 & round(x, 3) == 0,
                           formatC(x, format = "e", digits = 2),
                           sprintf("%.3f", x))

# ---- Table 1: no degrees of freedom ----
tab1 <- data.frame(
  Module = merged$module, Color = merged$moduleColor,
  EigenCor_biotype_r = r3(merged$eigenCor_biotype_r), EigenCor_biotype_q = sig(merged$eigenCor_biotype_q),
  EigenCor_virus_r   = r3(merged$eigenCor_virus_r),   EigenCor_virus_q   = sig(merged$eigenCor_virus_q),
  EigenCor_day_r     = r3(merged$eigenCor_day_r),     EigenCor_day_q     = sig(merged$eigenCor_day_q),
  PERMANOVA_biotype_R2 = r3(merged$permanova_biotype_R2), PERMANOVA_biotype_q = sig(merged$permanova_biotype_q),
  PERMANOVA_virus_R2   = r3(merged$permanova_virus_R2),   PERMANOVA_virus_q   = sig(merged$permanova_virus_q),
  PERMANOVA_day_R2     = r3(merged$permanova_day_R2),     PERMANOVA_day_q     = sig(merged$permanova_day_q)
)
write.table(tab1, "wheat_module_trait_PERMANOVA_table.tsv", sep = "\t", quote = FALSE, row.names = FALSE)
cat("\nwrote wheat_module_trait_PERMANOVA_table.tsv\n")

# ---- Table 2: with degrees of freedom ----
tab2 <- data.frame(
  Module = merged$module, Color = merged$moduleColor,
  EigenCor_biotype_r = r3(merged$eigenCor_biotype_r), EigenCor_biotype_q = sig(merged$eigenCor_biotype_q),
  EigenCor_virus_r   = r3(merged$eigenCor_virus_r),   EigenCor_virus_q   = sig(merged$eigenCor_virus_q),
  EigenCor_day_r     = r3(merged$eigenCor_day_r),     EigenCor_day_q     = sig(merged$eigenCor_day_q),
  EigenCor_df = merged$eigenCor_df,
  PERMANOVA_biotype_R2 = r3(merged$permanova_biotype_R2), PERMANOVA_biotype_q = sig(merged$permanova_biotype_q),
  PERMANOVA_biotype_df = merged$permanova_biotype_df,
  PERMANOVA_virus_R2   = r3(merged$permanova_virus_R2),   PERMANOVA_virus_q   = sig(merged$permanova_virus_q),
  PERMANOVA_virus_df   = merged$permanova_virus_df,
  PERMANOVA_day_R2     = r3(merged$permanova_day_R2),     PERMANOVA_day_q     = sig(merged$permanova_day_q),
  PERMANOVA_day_df     = merged$permanova_day_df
)
write.table(tab2, "wheat_module_trait_PERMANOVA_table_withdf.tsv", sep = "\t", quote = FALSE, row.names = FALSE)
cat("wrote wheat_module_trait_PERMANOVA_table_withdf.tsv\n")

cat("\n==== Table 1 preview ====\n")
print(tab1, row.names = FALSE)
