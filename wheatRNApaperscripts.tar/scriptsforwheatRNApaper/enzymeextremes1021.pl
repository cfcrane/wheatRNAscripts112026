#!/usr/bin/env perl
use warnings;
#This script reads sigchlorophyllcomparisons1020.txt, a file made of repeated blocks each
#headed by "File: <source file>" followed by "Section 1: up-regulated..." and "Section 2:
#down-regulated..." lines (the output of selectbylastfield1020.pl concatenated across several
#result files). For each distinct enzyme name (the Description column), it finds the single
#most up-regulated log2FoldChange and the single most down-regulated log2FoldChange across
#every occurrence of that enzyme in the whole input, along with each value's qvalue (the final
#column) and the source file it came from. Enzyme names are listed in the order of the File
#block in which they first appear, i.e. sorted by the list/file they came from.
#Usage: perl enzymeextremes1021.pl <input> <output>
#e.g.:  perl enzymeextremes1021.pl sigchlorophyllcomparisons1020.txt enzymeextremes1021.txt
die "Usage: perl $0 <input> <output>\n" unless scalar(@ARGV) == 2;
$infile = $ARGV[0];
$outfile = $ARGV[1];

open(IN, "<", $infile) or die "Could not open $infile: $!\n";

$headerline = <IN>;
chomp $headerline;
@hvars = split(/\t/, $headerline);
$desccol = -1;
$lfccol = -1;
for ($i = 0; $i < scalar(@hvars); $i++) {
  $desccol = $i if $hvars[$i] eq "Description";
  $lfccol = $i if $hvars[$i] eq "log2FoldChange" || $hvars[$i] eq "LFC";
}
die "Column 'Description' not found in $infile\n" if $desccol < 0;
die "Column 'log2FoldChange' not found in $infile\n" if $lfccol < 0;

$currfile = "";
$order = 0;
while ($line = <IN>) {
  chomp $line;
  next unless length($line);
  if ($line =~ m/^File:\s*(.*)$/) {
    $currfile = $1;
    $fileorder{$currfile} = ++$order unless exists($fileorder{$currfile});
    next;
  }
  next if $line =~ m/^Section \d:/; #Section 1/2 header lines, not data

  @vars = split(/\t/, $line);
  next unless scalar(@vars) == scalar(@hvars); #skip malformed/short lines
  $desc = $vars[$desccol];
  $lfc = $vars[$lfccol];
  $q = $vars[-1];
  next unless $lfc =~ m/^-?\d*\.?\d+(?:[eE][-+]?\d+)?$/; #skip non-numeric log2FoldChange

  unless (exists($firstorder{$desc})) {$firstorder{$desc} = $fileorder{$currfile};}

  if (!exists($maxlfc{$desc}) || $lfc > $maxlfc{$desc}) {
    $maxlfc{$desc} = $lfc;
    $maxq{$desc} = $q;
    $maxfile{$desc} = $currfile;
  }
  if (!exists($minlfc{$desc}) || $lfc < $minlfc{$desc}) {
    $minlfc{$desc} = $lfc;
    $minq{$desc} = $q;
    $minfile{$desc} = $currfile;
  }
}
close(IN);

open(OUT, ">", $outfile) or die "Could not open $outfile: $!\n";
print OUT "Enzyme\tMost_up_log2FoldChange\tUp_qvalue\tUp_source_file\tMost_down_log2FoldChange\tDown_qvalue\tDown_source_file\n";
foreach $desc (sort {$firstorder{$a} <=> $firstorder{$b} || $a cmp $b} keys(%firstorder)) {
  $up = exists($maxlfc{$desc}) ? $maxlfc{$desc} : "NA";
  $upq = exists($maxq{$desc}) ? $maxq{$desc} : "NA";
  $upfile = exists($maxfile{$desc}) ? $maxfile{$desc} : "NA";
  $down = exists($minlfc{$desc}) ? $minlfc{$desc} : "NA";
  $downq = exists($minq{$desc}) ? $minq{$desc} : "NA";
  $downfile = exists($minfile{$desc}) ? $minfile{$desc} : "NA";
  print OUT "$desc\t$up\t$upq\t$upfile\t$down\t$downq\t$downfile\n";
}
close(OUT);
