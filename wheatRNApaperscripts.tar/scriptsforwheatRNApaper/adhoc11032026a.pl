#!/usr/bin/perl
use strict;
use warnings;

# Usage: perl adhoc11032026a.pl <deseq2_1> <deseq2_2> [<deseq2_3> ...]
# Only gene_ids whose summed baseMean (total counts) across their tx_ids is > 0
# are considered. All tx_ids of a retained gene_id are kept.
# Reports, per file, the number of gene_ids with counts > 0 and the distribution
# of tx_id counts per gene_id; and, per pair of files, the number of gene_ids
# with counts > 0 in both files and the number of those with >1 tx_id in both.

die "Usage: $0 <file1> <file2> [<file3> ...]\n" unless @ARGV >= 2;

my @files = @ARGV;
my @genes;    # one hash of arrays per file

for my $i (0 .. $#files) {
    my (%tx, %count);
    open(my $fh, '<', $files[$i]) or die "Cannot open $files[$i]: $!\n";
    my $header = <$fh>;
    chomp $header;
    my @cols = split /\t/, $header;
    my ($txcol, $genecol, $bmcol);
    for my $c (0 .. $#cols) {
        $txcol   = $c if $cols[$c] eq 'tx_id';
        $genecol = $c if $cols[$c] eq 'gene_id';
        $bmcol   = $c if $cols[$c] eq 'baseMean';
    }
    die "$files[$i]: header lacks tx_id, gene_id and/or baseMean\n"
        unless defined $txcol && defined $genecol && defined $bmcol;
    while (my $line = <$fh>) {
        chomp $line;
        next if $line =~ /^\s*$/;
        my @f = split /\t/, $line;
        push @{ $tx{ $f[$genecol] } }, $f[$txcol];
        $count{ $f[$genecol] } += $f[$bmcol] if $f[$bmcol] =~ /^[-+0-9.eE]+$/;
    }
    close $fh;
    delete $tx{$_} for grep { !($count{$_} && $count{$_} > 0) } keys %tx;
    $genes[$i] = \%tx;
}

for my $i (0 .. $#files) {
    my %tx   = %{ $genes[$i] };
    my @keys = keys %tx;
    my %dist;
    $dist{ scalar @{ $tx{$_} } }++ for @keys;
    my $multi = grep { @{ $tx{$_} } > 1 } @keys;

    print "File: $files[$i]\n";
    print "  gene_ids with counts > 0: ", scalar(@keys), "\n";
    print "  gene_ids with >1 tx_id: $multi\n";
    for my $n (sort { $a <=> $b } keys %dist) {
        print "  gene_ids with exactly $n tx_id: $dist{$n}\n";
    }
    print "\n";
}

for my $i (0 .. $#files - 1) {
    for my $j ($i + 1 .. $#files) {
        my @shared = grep { exists $genes[$j]{$_} } keys %{ $genes[$i] };
        my $both = grep { @{ $genes[$i]{$_} } > 1 && @{ $genes[$j]{$_} } > 1 } @shared;
        print "$files[$i] and $files[$j]:\n";
        print "  gene_ids with counts > 0 in both: ", scalar(@shared), "\n";
        print "  of these, with >1 tx_id in both: $both\n";
    }
}
