suppressPackageStartupMessages(library(dplyr))

padj_cut     <- 0.05
lfc_cut      <- 2
minTermSize  <- 3     # ignore GO terms annotated to fewer than this many universe genes
qval_cut     <- 0.05  # for the console summary only; full table always written

go <- read.delim("go_annotation/wheat_gene2go.tsv", stringsAsFactors = FALSE,
                  check.names = FALSE, comment.char = "")
names(go)[names(go) == "#tax_id"] <- "tax_id"
go <- distinct(go, GeneID, GO_ID, GO_term, Category)

# One-sided hypergeometric test (equivalent to a one-sided Fisher's exact test)
# for over-representation of each GO term among the significant genes, run
# separately per ontology (Function/Process/Component) against a per-file
# background of all genes DESeq2 actually tested (non-NA padj), not the whole
# genome -- the standard ORA background choice.
run_enrichment <- function(resFile, label, outfile) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  universeIDs <- unique(res$NCBI.GeneID)

  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sigIDs <- unique(sig$NCBI.GeneID)

  goUniverse <- go[go$GeneID %in% universeIDs, ]
  N <- length(universeIDs)
  k <- length(sigIDs)

  allRows <- lapply(c("Function", "Process", "Component"), function(cat) {
    sub <- goUniverse[goUniverse$Category == cat, ]
    geneSets <- split(sub$GeneID, sub$GO_ID)
    geneSets <- geneSets[lengths(geneSets) >= minTermSize]
    if (length(geneSets) == 0) return(NULL)

    termNames <- sub$GO_term[match(names(geneSets), sub$GO_ID)]

    m <- lengths(geneSets)
    a <- vapply(geneSets, function(g) length(intersect(g, sigIDs)), integer(1))
    expected <- m * k / N
    pval <- mapply(function(aa, mm) phyper(aa - 1, mm, N - mm, k, lower.tail = FALSE),
                    a, m)

    data.frame(ontology = cat, GO_ID = names(geneSets), term = termNames,
               n_universe_in_term = m, n_sig_in_term = a,
               n_sig_total = k, n_universe_total = N,
               expected_sig_in_term = round(expected, 3),
               fold_enrichment = round(a / expected, 3),
               pvalue = pval, stringsAsFactors = FALSE)
  })

  out <- do.call(rbind, allRows)
  out$qvalue <- ave(out$pvalue, out$ontology, FUN = function(p) p.adjust(p, method = "BH"))
  out <- out[order(out$pvalue), ]

  write.table(out, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  nSigTerms <- sum(out$qvalue <= qval_cut)
  cat(sprintf("%-8s: %d sig genes (of %d universe); %d GO terms tested; %d enriched at q <= %.2f\n",
              label, k, N, nrow(out), nSigTerms, qval_cut))
  if (nSigTerms > 0) {
    top <- head(out[out$qvalue <= qval_cut, c("ontology", "GO_ID", "term", "n_sig_in_term",
                                               "fold_enrichment", "qvalue")], 10)
    print(top, row.names = FALSE)
  }
  cat("  wrote", outfile, "\n\n")
}

run_enrichment("biotype_results.txt", "Biotype", "wheat_biotype_GO_enrichment.tsv")
run_enrichment("virus_results.txt",   "Virus",   "wheat_virus_GO_enrichment.tsv")
run_enrichment("time_results.txt",    "Time",    "wheat_time_GO_enrichment.tsv")
