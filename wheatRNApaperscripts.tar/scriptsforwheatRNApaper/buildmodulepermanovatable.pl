#!/usr/bin/env perl
use warnings;
#This script assembled a table of PERMANOVA results for the listed files.
open (LIS, "< $ARGV[0]"); #wheatmodulepermanovafiles.txt
open (OUT, "> $ARGV[1]");
@types = ("biotype", "virus", "day", "biotype:virus", "biotype:day", "virus:day", "biotype:virus:day");
print OUT "module\tcolor";
for ($i = 0; $i < scalar(@types); $i++) {print OUT "\t$types[$i]";}
print OUT "\n";
while ($file = <LIS>) {
  chomp $file;
  open (INP, "< $file");
  #Df      SumOfSqs        R2      F       Pr(>F)  term    module  moduleColor     nGenes
  #6       84513.5707854319        0.161775013839636       2.95114552957391        0.008   day     1       turquoise       4390
  $line = <INP>;
  chomp $line;
  @vars = split(/\t/, $line);
  for ($i = 0; $i < scalar(@vars); $i++) {
    if ($vars[$i] eq "F") {$Fcolumn = $i;}
    elsif ($vars[$i] =~ m/Pr/) {$probcolumn = $i;}
    elsif ($vars[$i] eq "module") {$modulecolumn = $i;}
    elsif ($vars[$i] =~ m/Color/) {$colorcolumn = $i;}
    elsif ($vars[$i] eq "nGenes") {$ngenescolumn = $i;}
    elsif ($vars[$i] eq "term") {$termcolumn = $i;}
  }
  while ($line = <INP>) {
    chomp $line;
    @vars = split(/\t/, $line);
    $module = $vars[$modulecolumn];
    $ngenes = $vars[$ngenescolumn];
    $term = $vars[$termcolumn];
    $color = $vars[$colorcolumn];
    $F{$term} = sprintf("%.3f", $vars[$Fcolumn]);
    $pval{$term} = $vars[$probcolumn];
  }
  print OUT "$module\t$color\t$ngenes";
  for ($i = 0; $i < scalar(@types); $i++) {print OUT "\t$F{$types[$i]}($pval{$types[$i]})";}
  print OUT "\n";
}
