suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(data.table)
})

padj_cut <- 0.05
lfc_cut  <- 2
gapBp    <- 3e6  # small fixed gap between chromosomes, purely to show the boundary

# ============================================================
# Shared reference data, loaded once
# ============================================================
annRaw <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)

chrLenBase <- read.delim("wheatgenecounts/chromosome_lengths.tsv", stringsAsFactors = FALSE)
chrLenBase$subgenome <- substr(chrLenBase$chr_name, nchar(chrLenBase$chr_name), nchar(chrLenBase$chr_name))
chrLenBase$chrNum <- as.integer(substr(chrLenBase$chr_name, 1, nchar(chrLenBase$chr_name) - 1))
chrLenBase$subgenome <- factor(chrLenBase$subgenome, levels = c("A", "B", "D"))
chrLenBase <- chrLenBase[order(chrLenBase$subgenome, chrLenBase$chrNum), ]

# cumStart/chrMid/chrEnd: real-bp cumulative position *within* each subgenome
# row, reset to ~0 at the start of each row (used as-is by the free_x
# standalone panels; used with a centering offset added for the combined panels).
chrLenBase$cumStart <- unlist(lapply(split(chrLenBase, chrLenBase$subgenome), function(d) {
  cumsum(c(0, d$length[-nrow(d)])) + seq_len(nrow(d)) * gapBp
}))
chrLenBase$chrMid <- chrLenBase$cumStart + chrLenBase$length / 2
chrLenBase$chrEnd <- chrLenBase$cumStart + chrLenBase$length

# Centering offset so each subgenome row -- which differ in total bp -- is
# horizontally centered against the longest row (subgenome B) when all three
# rows share one fixed, proportional bp scale.
rowExtent  <- tapply(chrLenBase$chrEnd, chrLenBase$subgenome, max)
maxExtent  <- max(rowExtent)
rowOffset  <- (maxExtent - rowExtent) / 2
chrLenBase$rowOffset <- rowOffset[as.character(chrLenBase$subgenome)]
chrLenBase$cumStartC <- chrLenBase$cumStart + chrLenBase$rowOffset
chrLenBase$chrMidC   <- chrLenBase$chrMid   + chrLenBase$rowOffset
chrLenBase$chrEndC   <- chrLenBase$chrEnd   + chrLenBase$rowOffset

# All HC gene positions from the IWGSC RefSeq v2.1 annotation (same
# coordinate system / chromosome accessions as chromosome_lengths.tsv --
# verified max gene end per chromosome falls within its bp length).
genesRaw <- fread(
  cmd  = "awk -F'\\t' '$3==\"gene\" && $1!=\"ChrUnknown\"' iwgsc_refseqv2.1_gene_annotation_200916/iwgsc_refseqv2.1_annotation_200916_HC.gff3",
  header = FALSE, sep = "\t",
  col.names = c("seqid", "source", "type", "start", "end", "score", "strand", "phase", "attr")
)
genesRaw$chrNum <- as.integer(sub("^Chr([0-9]+)[ABD]$", "\\1", genesRaw$seqid))
genesRaw$subgenome <- factor(sub("^Chr[0-9]+([ABD])$", "\\1", genesRaw$seqid), levels = c("A", "B", "D"))
genesRaw$pos <- (genesRaw$start + genesRaw$end) / 2
genesRaw <- as.data.frame(genesRaw)

# ============================================================
# Standalone panels (facet free_x, matches the style of the existing
# wheat_time_DEG_chromosome_positions.pdf / wheatGeneChromPlotAll0804.R)
# ============================================================
build_chrom_plot <- function(resFile, label, showXTitle = TRUE, showLegend = TRUE,
                              labelSize = 2.6, tickSize = 0.6, baseSize = 10,
                              panelSpacing = 0.45, boxHalfHeight = 0.1) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig$direction <- ifelse(sig$log2FoldChange >= lfc_cut, "Upregulated", "Downregulated")
  sig$direction <- factor(sig$direction, levels = c("Upregulated", "Downregulated"))
  sig <- unique(sig[, c("gene_id", "log2FoldChange", "direction")])
  names(sig)[names(sig) == "gene_id"] <- "gene_name"

  ann <- annRaw[annRaw$gene_name %in% sig$gene_name, ]
  ann <- do.call(rbind, by(ann, ann$gene_name, function(d) {
    data.frame(gene_name = d$gene_name[1], accession = d$accession[1],
               start = min(d$start), end = max(d$end))
  }))

  m <- merge(sig, ann, by = "gene_name")
  m <- merge(m, chrLenBase, by = "accession")
  nMapped <- length(unique(m$gene_name))
  cat(sprintf("%s: %d significant DEGs; %d map to a true chromosome (%d unmapped)\n",
              label, nrow(sig), nMapped, nrow(sig) - nMapped))

  m$pos <- (m$start + m$end) / 2
  m$genomePos <- m$cumStart + m$pos

  ggplot() +
    geom_rect(data = chrLenBase, aes(xmin = cumStart, xmax = chrEnd,
                                      ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
              fill = "grey92", color = "grey60", linewidth = 0.2) +
    geom_segment(data = m, aes(x = genomePos, xend = genomePos,
                                y = 1 - boxHalfHeight, yend = 1 + boxHalfHeight,
                                color = direction),
                 linewidth = tickSize, alpha = 0.8) +
    geom_text(data = chrLenBase, aes(x = chrMid, y = 1 - boxHalfHeight - 0.1,
                                      label = paste0(chrNum, subgenome)),
              size = labelSize, color = "grey30") +
    scale_color_manual(values = c(Upregulated = "#E85B5B", Downregulated = "#3B8FC4"), drop = FALSE) +
    scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
    facet_wrap(~ subgenome, ncol = 1, scales = "free_x") +
    labs(x = if (showXTitle) "Chromosome" else NULL, y = NULL, color = NULL,
         title = sprintf("%s     padj <= %.2f, |log2FC| >= %d; n = %d genes",
                          label, padj_cut, lfc_cut, nMapped)) +
    theme_minimal(base_size = baseSize) +
    theme(panel.grid = element_blank(),
          axis.text.x = element_blank(),
          strip.text = element_blank(),
          panel.spacing = unit(panelSpacing, "lines"),
          plot.title = element_text(size = baseSize),
          plot.margin = margin(2, 4, 2, 4),
          legend.position = if (showLegend) "top" else "none")
}

build_allgenes_plot <- function(label, showXTitle = TRUE,
                                 labelSize = 2.6, tickSize = 0.15, baseSize = 10,
                                 panelSpacing = 0.45, boxHalfHeight = 0.1) {
  m <- merge(genesRaw, chrLenBase[, c("chrNum", "subgenome", "cumStart")], by = c("chrNum", "subgenome"))
  m$genomePos <- m$cumStart + m$pos
  cat(sprintf("%s: %d HC genes plotted\n", label, nrow(m)))

  ggplot() +
    geom_rect(data = chrLenBase, aes(xmin = cumStart, xmax = chrEnd,
                                      ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
              fill = "grey92", color = "grey60", linewidth = 0.2) +
    geom_segment(data = m, aes(x = genomePos, xend = genomePos,
                                y = 1 - boxHalfHeight, yend = 1 + boxHalfHeight),
                 linewidth = tickSize, alpha = 0.15, color = "grey20") +
    geom_text(data = chrLenBase, aes(x = chrMid, y = 1 - boxHalfHeight - 0.1,
                                      label = paste0(chrNum, subgenome)),
              size = labelSize, color = "grey30") +
    scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
    facet_wrap(~ subgenome, ncol = 1, scales = "free_x") +
    labs(x = if (showXTitle) "Chromosome" else NULL, y = NULL,
         title = sprintf("%s     all HC genes (IWGSC RefSeq v2.1); n = %d genes", label, nrow(m))) +
    theme_minimal(base_size = baseSize) +
    theme(panel.grid = element_blank(),
          axis.text.x = element_blank(),
          strip.text = element_blank(),
          panel.spacing = unit(panelSpacing, "lines"),
          plot.title = element_text(size = baseSize),
          plot.margin = margin(2, 4, 2, 4),
          legend.position = "none")
}

# ---- New standalone counterparts ----
pTime20vs0 <- build_chrom_plot("time20vs0.txt", "Day 20 vs 0", showXTitle = TRUE, showLegend = TRUE)
ggsave("wheat_time20vs0_DEG_chromosome_positions.pdf", pTime20vs0, width = 5, height = 6.5)

pAllGenes <- build_allgenes_plot("All genes")
ggsave("wheat_allgenes_chromosome_positions.pdf", pAllGenes, width = 5, height = 6.5)

# ============================================================
# Combined 4-panel figure: chromosome length proportional to bp on a single
# shared scale across subgenomes (facet scales = fixed, not free_x), each
# subgenome row centered against the longest row (B). Landscape page.
# ============================================================
build_chrom_plot_c <- function(resFile, label, showXTitle = TRUE, showLegend = TRUE,
                                labelSize = 2.3, tickSize = 0.4, baseSize = 7,
                                panelSpacing = 0.15, boxHalfHeight = 0.2,
                                boundaryExtend = 0.08) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig$direction <- ifelse(sig$log2FoldChange >= lfc_cut, "Upregulated", "Downregulated")
  sig$direction <- factor(sig$direction, levels = c("Upregulated", "Downregulated"))
  sig <- unique(sig[, c("gene_id", "log2FoldChange", "direction")])
  names(sig)[names(sig) == "gene_id"] <- "gene_name"

  ann <- annRaw[annRaw$gene_name %in% sig$gene_name, ]
  ann <- do.call(rbind, by(ann, ann$gene_name, function(d) {
    data.frame(gene_name = d$gene_name[1], accession = d$accession[1],
               start = min(d$start), end = max(d$end))
  }))

  m <- merge(sig, ann, by = "gene_name")
  m <- merge(m, chrLenBase, by = "accession")
  nMapped <- length(unique(m$gene_name))
  cat(sprintf("[combined] %s: %d significant DEGs; %d map to a true chromosome (%d unmapped)\n",
              label, nrow(sig), nMapped, nrow(sig) - nMapped))

  m$pos <- (m$start + m$end) / 2
  m$genomePos <- m$cumStartC + m$pos

  boundaries <- data.frame(x = c(chrLenBase$cumStartC, chrLenBase$chrEndC),
                            subgenome = c(chrLenBase$subgenome, chrLenBase$subgenome))

  ggplot() +
    geom_rect(data = chrLenBase, aes(xmin = cumStartC, xmax = chrEndC,
                                      ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
              fill = "grey92", color = "grey60", linewidth = 0.2) +
    geom_segment(data = m, aes(x = genomePos, xend = genomePos,
                                y = 1 - boxHalfHeight, yend = 1 + boxHalfHeight,
                                color = direction),
                 linewidth = tickSize, alpha = 0.8) +
    geom_segment(data = boundaries, aes(x = x, xend = x,
                                         y = 1 - boxHalfHeight - boundaryExtend,
                                         yend = 1 - boxHalfHeight),
                 color = "grey40", linewidth = 0.3) +
    geom_segment(data = boundaries, aes(x = x, xend = x,
                                         y = 1 + boxHalfHeight,
                                         yend = 1 + boxHalfHeight + boundaryExtend),
                 color = "grey40", linewidth = 0.3) +
    geom_text(data = chrLenBase, aes(x = chrMidC, y = 1 - boxHalfHeight - 0.1,
                                      label = paste0(chrNum, subgenome)),
              size = labelSize, color = "grey30") +
    scale_color_manual(values = c(Upregulated = "#E85B5B", Downregulated = "#3B8FC4"), drop = FALSE) +
    scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
    coord_cartesian(xlim = c(0, maxExtent)) +
    facet_wrap(~ subgenome, ncol = 1) +
    labs(x = if (showXTitle) "Chromosome (position proportional to bp, subgenomes centered)" else NULL,
         y = NULL, color = NULL,
         title = sprintf("%s     padj <= %.2f, |log2FC| >= %d; n = %d genes",
                          label, padj_cut, lfc_cut, nMapped)) +
    theme_minimal(base_size = baseSize) +
    theme(panel.grid = element_blank(),
          axis.text.x = element_blank(),
          strip.text = element_blank(),
          panel.spacing = unit(panelSpacing, "lines"),
          plot.title = element_text(size = baseSize),
          plot.margin = margin(2, 4, 2, 4),
          legend.position = if (showLegend) "top" else "none")
}

build_allgenes_plot_c <- function(label, showXTitle = TRUE,
                                   labelSize = 2.3, tickSize = 0.12, baseSize = 7,
                                   panelSpacing = 0.15, boxHalfHeight = 0.2,
                                   boundaryExtend = 0.08) {
  m <- merge(genesRaw, chrLenBase[, c("chrNum", "subgenome", "cumStartC")], by = c("chrNum", "subgenome"))
  m$genomePos <- m$cumStartC + m$pos
  cat(sprintf("[combined] %s: %d HC genes plotted\n", label, nrow(m)))

  boundaries <- data.frame(x = c(chrLenBase$cumStartC, chrLenBase$chrEndC),
                            subgenome = c(chrLenBase$subgenome, chrLenBase$subgenome))

  ggplot() +
    geom_rect(data = chrLenBase, aes(xmin = cumStartC, xmax = chrEndC,
                                      ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
              fill = "grey92", color = "grey60", linewidth = 0.2) +
    geom_segment(data = m, aes(x = genomePos, xend = genomePos,
                                y = 1 - boxHalfHeight, yend = 1 + boxHalfHeight),
                 linewidth = tickSize, alpha = 0.12, color = "grey20") +
    geom_segment(data = boundaries, aes(x = x, xend = x,
                                         y = 1 - boxHalfHeight - boundaryExtend,
                                         yend = 1 - boxHalfHeight),
                 color = "grey40", linewidth = 0.3) +
    geom_segment(data = boundaries, aes(x = x, xend = x,
                                         y = 1 + boxHalfHeight,
                                         yend = 1 + boxHalfHeight + boundaryExtend),
                 color = "grey40", linewidth = 0.3) +
    geom_text(data = chrLenBase, aes(x = chrMidC, y = 1 - boxHalfHeight - 0.1,
                                      label = paste0(chrNum, subgenome)),
              size = labelSize, color = "grey30") +
    scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
    coord_cartesian(xlim = c(0, maxExtent)) +
    facet_wrap(~ subgenome, ncol = 1) +
    labs(x = if (showXTitle) "Chromosome (position proportional to bp, subgenomes centered)" else NULL,
         y = NULL,
         title = sprintf("%s     all HC genes (IWGSC RefSeq v2.1); n = %d genes", label, nrow(m))) +
    theme_minimal(base_size = baseSize) +
    theme(panel.grid = element_blank(),
          axis.text.x = element_blank(),
          strip.text = element_blank(),
          panel.spacing = unit(panelSpacing, "lines"),
          plot.title = element_text(size = baseSize),
          plot.margin = margin(2, 4, 2, 4),
          legend.position = "none")
}

cBiotype   <- build_chrom_plot_c("biotype_results.txt", "Biotype",     showXTitle = FALSE, showLegend = TRUE)
cVirus     <- build_chrom_plot_c("virus_results.txt",   "Virus",       showXTitle = FALSE, showLegend = FALSE)
cTime20vs0 <- build_chrom_plot_c("time20vs0.txt",        "Day 20 vs 0", showXTitle = FALSE, showLegend = FALSE)
cAllGenes  <- build_allgenes_plot_c("All genes",          showXTitle = TRUE)

combined <- cBiotype / cVirus / cTime20vs0 / cAllGenes

ggsave("wheat_DEG_chromosome_positions_combined.pdf", combined, width = 11, height = 8)

cat("wrote wheat_time20vs0_DEG_chromosome_positions.pdf, wheat_allgenes_chromosome_positions.pdf,",
    "wheat_DEG_chromosome_positions_combined.pdf (revised, 4 panels, landscape)\n")
