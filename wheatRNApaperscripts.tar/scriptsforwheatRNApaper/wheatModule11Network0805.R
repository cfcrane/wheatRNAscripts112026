suppressPackageStartupMessages({
  library(igraph)
  library(ggraph)
  library(ggplot2)
})
options(stringsAsFactors = FALSE)

padj_cut     <- 0.05
lfc_cut      <- 2
# Module 11 has zero genes meeting the usual padj<=0.05 & |log2FC|>=2 bar (10
# meet padj alone) -- relax to padj-only for this module's target pool, per
# explicit direction, rather than silently forcing the usual |log2FC|>=2 cut.
lfc_cut_targets <- 0
nHub         <- 4
nTargetMax   <- 20
nearMaxFrac  <- 0.8    # keep a hub->target edge if its weight is within 80% of that
                        # target's own strongest hub connection (lets a target keep
                        # multiple near-tied incoming edges, as in Chen et al. Fig 6)
moduleNum    <- 11

load("wheat_wgcna_network_15k.RData")   # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata
load("wheatTOM_15k-block.1.RData")      # TOM (dist, WGCNA topological overlap for the 15k network)

geneIDs   <- colnames(datExpr)
mod8genes <- geneIDs[moduleLabels == moduleNum]
modColor  <- unique(moduleColors[moduleLabels == moduleNum])
cat(sprintf("Module %d = %s module, %d genes\n", moduleNum, modColor, length(mod8genes)))

# ---- Hub genes = highest intramodular connectivity (kME), standing in for
# Chen et al.'s phenotype-GWAS-derived hub genes, which relied on external
# germplasm/SNP data we don't have here. ----
meCol <- paste0("ME", moduleNum)
kME <- sapply(mod8genes, function(g) cor(datExpr[, g], MEs[, meCol], use = "p"))
kME <- sort(kME, decreasing = TRUE)
hubGenes <- names(head(kME, nHub))
cat("Hub genes (top kME to module eigengene):\n")
print(round(head(kME, nHub), 3))

# ---- TOM edge weights among module-8 genes only (subset before densifying,
# so we never materialize the full 15000x15000 matrix) ----
idx <- match(mod8genes, geneIDs)
TOMmat <- as.matrix(TOM)[idx, idx]
dimnames(TOMmat) <- list(mod8genes, mod8genes)
rm(TOM); gc()

# ---- Map network gene ids (MSTRG.*) to reference LOC ids / descriptions.
# mstrg_annotated.tsv's own gene_id column is a mix of LOC and MSTRG ids, but
# every row here is keyed by our network's MSTRG-style gene_id, so this join
# is direct (no gene_name detour needed -- that trick was only for the
# reverse direction, LOC -> MSTRG). ----
ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[ann$gene_id %in% mod8genes, c("gene_id", "gene_name", "description")]
ann <- ann[!duplicated(ann$gene_id), ]

# ---- Significant-DEG status (any of biotype/virus/time), keyed by the
# reference LOC id (gene_name here == DESeq2's own gene_id column). ----
load_sig <- function(f) {
  r <- read.delim(f, stringsAsFactors = FALSE)
  r <- r[!is.na(r$padj) & r$padj <= padj_cut & abs(r$log2FoldChange) >= lfc_cut_targets, ]
  unique(r$gene_id)
}
sigLOC <- unique(c(load_sig("biotype_results.txt"),
                    load_sig("virus_results.txt"),
                    load_sig("time_results.txt")))

ann$is_sig_DEG <- ann$gene_name %in% sigLOC
targetCandidates <- setdiff(ann$gene_id[ann$is_sig_DEG], hubGenes)
cat(length(targetCandidates), "module-8 DEGs available as network targets\n")

# ---- hub -> target edges, TOM weight > cutoff (same threshold Chen et al. used) ----
# TOM magnitude depends on the network's own soft-power/normalization and
# isn't comparable across studies, so Chen et al.'s absolute 0.6 cutoff
# doesn't transfer here (this network's hub-target TOM weights top out
# around 0.25). Use a relative rule instead: rank targets by their single
# strongest hub connection, keep the top nTargetMax, and for each of those
# targets keep any hub edge within nearMaxFrac of its own best edge (so a
# target tied between two hubs keeps both incoming edges, as in Fig 6).
wMat <- sapply(hubGenes, function(h) TOMmat[h, targetCandidates])  # targets x hubs
targetMax <- apply(wMat, 1, max)
cat("hub-target TOM weight (per-target max) distribution:\n"); print(summary(targetMax))

keepTargets <- names(sort(targetMax, decreasing = TRUE))[seq_len(min(nTargetMax, length(targetMax)))]

edges <- do.call(rbind, lapply(keepTargets, function(tg) {
  w <- wMat[tg, ]
  keep <- names(w)[w >= nearMaxFrac * max(w)]
  data.frame(from = keep, to = tg, weight = unname(w[keep]))
}))
cat(sprintf("%d target genes retained, %d edges\n", length(keepTargets), nrow(edges)))

# ---- Regulatory (TF/regulatory-domain) vs structural, by keyword match on
# description -- same heuristic split Chen et al. describe (BTB/POZ, ERF ->
# regulatory; kinase, glycosyltransferase, detox protein -> structural). ----
regulatory_kw <- c("transcription factor", "zinc.finger", "ethylene.responsive",
                    "\\bERF\\b", "WRKY", "\\bMYB\\b", "bZIP", "bHLH", "NAC domain",
                    "BTB", "POZ", "homeobox", "MADS.box", "\\bAP2\\b", "response regulator")
is_regulatory <- function(desc) {
  if (is.na(desc)) return(FALSE)
  any(vapply(regulatory_kw, function(k) grepl(k, desc, ignore.case = TRUE), logical(1)))
}

nodeIDs <- unique(c(hubGenes, keepTargets))
nodeAnn <- ann[match(nodeIDs, ann$gene_id), ]
nodeAnn$role <- ifelse(nodeAnn$gene_id %in% hubGenes, "Hub",
                        ifelse(vapply(nodeAnn$description, is_regulatory, logical(1)),
                               "Regulatory", "Structural"))
nodeAnn$label <- ifelse(!is.na(nodeAnn$gene_name) & nzchar(nodeAnn$gene_name),
                         nodeAnn$gene_name, nodeAnn$gene_id)
nodeAnn$descShort <- ifelse(!is.na(nodeAnn$description) & nzchar(nodeAnn$description),
                             substr(nodeAnn$description, 1, 34), "unannotated")

cat("\nNode roles:\n"); print(table(nodeAnn$role))

g <- graph_from_data_frame(edges[, c("from", "to", "weight")],
                            vertices = nodeAnn[, c("gene_id", "label", "descShort", "role")],
                            directed = TRUE)

set.seed(1)
layoutG <- create_layout(g, layout = "fr")

p <- ggraph(layoutG) +
  geom_edge_link(aes(edge_width = weight), arrow = arrow(length = unit(2.5, "mm"), type = "closed"),
                 end_cap = circle(5, "mm"), edge_alpha = 0.55, color = "grey45") +
  scale_edge_width(range = c(0.3, 1.3), guide = "none") +
  geom_node_point(aes(color = role), size = 9) +
  geom_node_text(aes(label = paste0(label, "\n(", descShort, ")")),
                 size = 2.3, repel = TRUE, max.overlaps = 30, lineheight = 0.85,
                 point.size = 9, box.padding = 0.5, force = 3, seed = 1) +
  scale_color_manual(values = c(Hub = "#E34948", Regulatory = "#1baf7a", Structural = "#2a78d6"),
                      name = NULL) +
  labs(title = sprintf("Module %d (%s module) co-expression network", moduleNum, modColor),
       subtitle = sprintf(
         "%d hub genes (top intramodular connectivity) and top %d DEGs (padj <= 0.05 only, no fold-change cut -- module 11 had none at |log2FC| >= 2) by TOM edge weight.",
         length(hubGenes), length(keepTargets))) +
  theme_void(base_size = 11) +
  theme(legend.position = "bottom",
        plot.title = element_text(face = "bold", size = 13),
        plot.subtitle = element_text(size = 8.5, color = "grey30"),
        plot.margin = margin(10, 10, 10, 10))

ggsave("wheat_module11_coexpression_network.pdf", p, width = 10, height = 9.5)
cat("\nwrote wheat_module11_coexpression_network.pdf\n")
