#!/usr/bin/env perl
use warnings;
#This script retains the lines in its input file where a specified field is not blank.
open (INP, "< $ARGV[0]"); #wheat_module1_gene_roster.txt
open (OUT, "> $ARGV[1]");
$searchedfield = $ARGV[2]; #gene_name
$line = <INP>; print OUT $line; #There is a header line.
chomp $line;
@vars = split(/\t/, $line);
$savedfield = "NULL";
for ($i = 0; $i < scalar(@vars); $i++) {
  if ($vars[$i] eq $searchedfield) {$savedfield = $i;}
}
if ($savedfield eq "NULL") {die "$searchedfield was not in the header line.\n";}
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  if ($vars[$savedfield] =~ m/\w+/) {print OUT $line, "\n";}
}
