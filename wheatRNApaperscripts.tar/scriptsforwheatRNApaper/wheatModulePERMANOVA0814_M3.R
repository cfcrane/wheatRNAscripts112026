suppressPackageStartupMessages(library(vegan))
options(stringsAsFactors = FALSE)
set.seed(1)

load("wheat_wgcna_network_15k.RData")  # datExpr, coldata, moduleLabels, moduleColors

# ---- Same sample subset/design as the whole-transcriptome PERMANOVA
# (wheatPERMANOVA0805.R): exclude the day-0/not_infested baseline (structurally
# confounded, can't participate in a biotype x virus x day factorial), leaving
# 83 samples in a clean 2 (biotype) x 2 (virus) x 7 (day) design. ----
keep <- coldata$biotype %in% c("B", "H") & coldata$day != 0
cd <- droplevels(coldata[keep, ])
cd$biotype <- factor(cd$biotype)
cd$virus <- factor(cd$virus)
cd$day <- factor(cd$day, levels = c("1", "2", "3", "5", "10", "15", "20"))

run_module_permanova <- function(moduleNum) {
  modGenes <- colnames(datExpr)[moduleLabels == moduleNum]
  modColor <- unique(moduleColors[moduleLabels == moduleNum])
  expr <- datExpr[keep, modGenes]
  cat(sprintf("\n==== Module %d (%s), %d genes ====\n", moduleNum, modColor, length(modGenes)))

  d <- dist(expr, method = "euclidean")

  fit <- adonis2(d ~ biotype * virus * day, data = cd, permutations = 999, by = "terms")
  res <- as.data.frame(fit)
  res <- res[!(rownames(res) %in% c("Residual", "Total")), ]
  res$term <- rownames(res)
  res <- res[order(-res$R2), ]
  print(res[, c("term", "Df", "SumOfSqs", "R2", "F", "Pr(>F)")], row.names = FALSE)

  cat("\n-- betadisper homogeneity checks --\n")
  for (fac in c("biotype", "virus", "day")) {
    bd <- betadisper(d, cd[[fac]])
    pt <- permutest(bd, permutations = 999)
    pval <- pt$tab$`Pr(>F)`[1]
    cat(sprintf("  %-8s: dispersion-homogeneity p = %.3f %s\n", fac, pval,
                ifelse(pval <= 0.05, "(WARNING: unequal dispersion)", "(OK)")))
  }

  res$module <- moduleNum
  res$moduleColor <- modColor
  res$nGenes <- length(modGenes)
  res
}

allResults <- do.call(rbind, lapply(3, run_module_permanova))
write.table(allResults, "wheat_module_M3_PERMANOVA_results.tsv", sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("\nwrote wheat_module_M3_PERMANOVA_results.tsv\n")
