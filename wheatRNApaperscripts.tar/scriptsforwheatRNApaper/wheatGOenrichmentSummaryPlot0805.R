suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

qval_cut <- 0.05
topN     <- 15

# Categorical slots 1-3 (blue/orange/aqua) -- validated as mutually
# distinguishable (CVD + normal-vision) as a set of three, fixed order.
ontology_colors <- c(Function = "#2a78d6", Process = "#eb6834", Component = "#1baf7a")

wrap_term <- function(x, width = 38) {
  vapply(x, function(s) paste(strwrap(s, width = width), collapse = "\n"), character(1))
}

load_top <- function(file) {
  d <- read.delim(file, stringsAsFactors = FALSE)
  sig <- d[d$qvalue <= qval_cut, ]
  sig <- sig[order(sig$qvalue), ]
  list(top = head(sig, topN), nTotal = nrow(sig))
}

build_dotplot <- function(res, label) {
  d <- res$top
  d$termWrapped <- wrap_term(d$term)
  # Most-significant term at the top of the panel.
  d <- d[order(-d$qvalue), ]
  d$termWrapped <- factor(d$termWrapped, levels = unique(d$termWrapped))

  ggplot(d, aes(x = fold_enrichment, y = termWrapped, size = n_sig_in_term, color = ontology)) +
    geom_point(alpha = 0.85) +
    scale_x_log10() +
    scale_color_manual(values = ontology_colors, drop = FALSE, name = "Ontology") +
    scale_size_continuous(name = "Genes", range = c(2, 7), limits = c(1, NA)) +
    labs(x = "Fold enrichment (log scale)", y = NULL,
         title = sprintf("%s -- %d GO terms enriched at q <= %.2f (top %d shown)",
                          label, res$nTotal, qval_cut, nrow(d))) +
    theme_minimal(base_size = 9) +
    theme(panel.grid.minor = element_blank(),
          plot.title = element_text(face = "bold", size = 10),
          axis.text.y = element_text(size = 7.2),
          plot.margin = margin(4, 8, 4, 4))
}

build_empty_panel <- function(res, label) {
  ggplot() +
    theme_void(base_size = 9) +
    labs(title = sprintf("%s -- %d GO terms enriched at q <= %.2f",
                          label, res$nTotal, qval_cut)) +
    annotate("text", x = 0, y = 0, label = "No GO terms reached significance",
             size = 3.2, color = "grey40") +
    theme(plot.title = element_text(face = "bold", size = 10),
          plot.margin = margin(4, 8, 4, 4))
}

biotype <- load_top("wheat_biotype_GO_enrichment.tsv")
virus   <- load_top("wheat_virus_GO_enrichment.tsv")
time    <- load_top("wheat_time_GO_enrichment.tsv")

pBiotype <- build_dotplot(biotype, "Biotype")
pVirus   <- build_dotplot(virus,   "Virus")
pTime    <- build_empty_panel(time, "Time")

hBiotype <- nrow(biotype$top)
hVirus   <- nrow(virus$top)

combined <- (pBiotype / pVirus / pTime) +
  plot_layout(heights = c(hBiotype, hVirus, 3), guides = "collect") +
  plot_annotation(
    title = "GO term enrichment among significant DEGs",
    subtitle = "One-sided hypergeometric test per ontology, BH-adjusted within ontology; dot size = number of significant genes in term",
    theme = theme(plot.title = element_text(face = "bold", size = 13),
                  plot.subtitle = element_text(size = 9, color = "grey30"))
  ) &
  theme(legend.position = "right")

ggsave("wheat_GO_enrichment_summary.pdf", combined, width = 8.5,
       height = 3 + 0.42 * (hBiotype + hVirus), limitsize = FALSE)
cat("wrote wheat_GO_enrichment_summary.pdf\n")
