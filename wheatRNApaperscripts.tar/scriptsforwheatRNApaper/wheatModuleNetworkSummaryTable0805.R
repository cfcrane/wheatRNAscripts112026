options(stringsAsFactors = FALSE)

padj_cut    <- 0.05
lfc_cut     <- 2
nHub        <- 4
nTargetMax  <- 20
nearMaxFrac <- 0.8
# Modules where the standard padj<=0.05 & |log2FC|>=2 bar left too few (<=2)
# targets to build a meaningful network -- relaxed to padj-only there, same
# policy applied when those modules were run individually.
relaxedModules <- c(11, 12)

load("wheat_wgcna_network_15k.RData")
load("wheatTOM_15k-block.1.RData")
geneIDs <- colnames(datExpr)
TOMfull <- as.matrix(TOM); rm(TOM); gc()

ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[, c("gene_id", "gene_name", "description")]
ann <- ann[!duplicated(ann$gene_id), ]

load_sig <- function(f, lfc) {
  r <- read.delim(f, stringsAsFactors = FALSE)
  r <- r[!is.na(r$padj) & r$padj <= padj_cut & abs(r$log2FoldChange) >= lfc, ]
  unique(r$gene_id)
}
sigLOC_std <- unique(c(load_sig("biotype_results.txt", lfc_cut),
                        load_sig("virus_results.txt", lfc_cut),
                        load_sig("time_results.txt", lfc_cut)))
sigLOC_relaxed <- unique(c(load_sig("biotype_results.txt", 0),
                            load_sig("virus_results.txt", 0),
                            load_sig("time_results.txt", 0)))

regulatory_kw <- c("transcription factor", "zinc.finger", "ethylene.responsive",
                    "\\bERF\\b", "WRKY", "\\bMYB\\b", "bZIP", "bHLH", "NAC domain",
                    "BTB", "POZ", "homeobox", "MADS.box", "\\bAP2\\b", "response regulator")
is_regulatory <- function(desc) {
  if (is.na(desc) || !nzchar(desc)) return(FALSE)
  any(vapply(regulatory_kw, function(k) grepl(k, desc, ignore.case = TRUE), logical(1)))
}

moduleTable <- table(moduleLabels)
moduleNums <- as.integer(names(moduleTable))
moduleNums <- moduleNums[moduleNums != 0]  # skip grey/unassigned
moduleNums <- sort(moduleNums)

rows <- lapply(moduleNums, function(m) {
  modGenes <- geneIDs[moduleLabels == m]
  modColor <- unique(moduleColors[moduleLabels == m])
  meCol <- paste0("ME", m)

  kME <- sapply(modGenes, function(g) cor(datExpr[, g], MEs[, meCol], use = "p"))
  kME <- sort(kME, decreasing = TRUE)
  hubGenes <- names(head(kME, nHub))

  idx <- match(modGenes, geneIDs)
  TOMmat <- TOMfull[idx, idx]
  dimnames(TOMmat) <- list(modGenes, modGenes)

  sigLOC <- if (m %in% relaxedModules) sigLOC_relaxed else sigLOC_std
  thresholdUsed <- if (m %in% relaxedModules) "padj only" else "padj & |log2FC|>=2"

  modAnn <- ann[ann$gene_id %in% modGenes, ]
  modAnn$is_sig <- modAnn$gene_name %in% sigLOC
  targetCandidates <- setdiff(modAnn$gene_id[modAnn$is_sig], hubGenes)

  nDEGpool <- length(targetCandidates)
  if (nDEGpool == 0) {
    return(data.frame(Module = m, Color = modColor, N_genes = length(modGenes),
                       kME_range = sprintf("%.3f-%.3f", min(kME[1:nHub]), max(kME[1:nHub])),
                       Threshold = thresholdUsed, N_DEG_pool = 0, N_targets = 0,
                       Edge_weight_range = NA, N_regulatory = 0, N_structural = 0))
  }

  wMat <- sapply(hubGenes, function(h) TOMmat[h, targetCandidates])
  if (is.null(dim(wMat))) wMat <- matrix(wMat, nrow = 1, dimnames = list(targetCandidates, hubGenes))
  targetMax <- apply(wMat, 1, max)
  keepTargets <- names(sort(targetMax, decreasing = TRUE))[seq_len(min(nTargetMax, length(targetMax)))]

  edges <- do.call(rbind, lapply(keepTargets, function(tg) {
    w <- wMat[tg, ]
    keep <- names(w)[w >= nearMaxFrac * max(w)]
    data.frame(from = keep, to = tg, weight = unname(w[keep]))
  }))

  targetAnn <- modAnn[match(keepTargets, modAnn$gene_id), ]
  nReg <- sum(vapply(targetAnn$description, is_regulatory, logical(1)))
  nStruct <- length(keepTargets) - nReg

  data.frame(Module = m, Color = modColor, N_genes = length(modGenes),
             kME_range = sprintf("%.3f-%.3f", min(kME[1:nHub]), max(kME[1:nHub])),
             Threshold = thresholdUsed, N_DEG_pool = nDEGpool, N_targets = length(keepTargets),
             Edge_weight_range = sprintf("%.3f-%.3f", min(edges$weight), max(edges$weight)),
             N_regulatory = nReg, N_structural = nStruct)
})

summaryTab <- do.call(rbind, rows)
write.table(summaryTab, "wheat_module_network_summary_table.txt", sep = "\t", quote = FALSE, row.names = FALSE)
cat("wrote wheat_module_network_summary_table.txt\n\n")
print(summaryTab, row.names = FALSE)
