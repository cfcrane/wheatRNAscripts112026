suppressPackageStartupMessages(library(ontologyIndex))
options(stringsAsFactors = FALSE)

padj_cut <- 0.05
lfc_cut  <- 2

cat("Loading GO ontology (go-basic.obo, release date embedded in file header)...\n")
go_core <- get_ontology("go-basic.obo", extract_tags = "everything",
                         propagate_relationships = c("is_a", "part_of"))
go_full <- get_ontology("go-basic.obo", extract_tags = "everything",
                         propagate_relationships = c("is_a", "part_of", "regulates"))

go <- read.delim("go_annotation/wheat_gene2go.tsv", stringsAsFactors = FALSE,
                  check.names = FALSE, comment.char = "")

# Expand a root GO term to its full descendant set, split into:
#  - "core": true is_a/part_of descendants (the process itself and its parts)
#  - "regulatory": terms connected via "regulates" (regulators of the process,
#    not participants in it -- biologically relevant but a distinct category,
#    so kept separately rather than silently merged)
expand_go_term <- function(rootID) {
  core <- get_descendants(go_core, rootID)
  full <- get_descendants(go_full, rootID)
  list(core = core, regulatory = setdiff(full, core))
}

analyze_condition_go <- function(resFile, label, geneSet, categoryLabel) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig <- sig[!duplicated(sig$gene_id), ]

  sig$in_category <- sig$NCBI.GeneID %in% geneSet
  n <- sum(sig$in_category)
  cat(sprintf("%-8s: %d significant DEGs; %d in \"%s\" (%.1f%%)\n",
              label, nrow(sig), n, categoryLabel, 100 * n / nrow(sig)))

  sig[sig$in_category, c("gene_id", "NCBI.GeneID", "Description", "log2FoldChange", "padj")]
}

run_go_category <- function(rootID, categoryLabel, outPrefix) {
  terms <- expand_go_term(rootID)
  cat(sprintf("\n==== %s (%s) ====\n", categoryLabel, rootID))
  cat(sprintf("Core (is_a/part_of) terms: %d -- %s\n", length(terms$core),
              paste(terms$core, collapse = ", ")))
  cat(sprintf("Regulatory (\"regulates\") terms: %d -- %s\n", length(terms$regulatory),
              paste(terms$regulatory, collapse = ", ")))

  coreGenes <- unique(go$GeneID[go$GO_ID %in% terms$core])
  regGenes  <- unique(go$GeneID[go$GO_ID %in% terms$regulatory])
  allGenes  <- union(coreGenes, regGenes)
  cat(sprintf("Wheat genes annotated: %d core, %d regulatory-only, %d union\n",
              length(coreGenes), length(setdiff(regGenes, coreGenes)), length(allGenes)))

  cat("\n-- Core process genes --\n")
  hitsCore <- lapply(list(c("biotype_results.txt", "Biotype"),
                           c("virus_results.txt", "Virus"),
                           c("time_results.txt", "Time")),
                      function(x) analyze_condition_go(x[1], x[2], coreGenes, categoryLabel))
  names(hitsCore) <- c("Biotype", "Virus", "Time")

  cat("\n-- Regulatory genes (\"regulates\" the process, e.g. NPR1-like regulators) --\n")
  hitsReg <- lapply(list(c("biotype_results.txt", "Biotype"),
                          c("virus_results.txt", "Virus"),
                          c("time_results.txt", "Time")),
                     function(x) analyze_condition_go(x[1], x[2], setdiff(regGenes, coreGenes),
                                                       paste(categoryLabel, "regulation")))
  names(hitsReg) <- c("Biotype", "Virus", "Time")

  for (cond in names(hitsCore)) {
    core_i <- hitsCore[[cond]]; core_i$role <- rep("core", nrow(core_i))
    reg_i  <- hitsReg[[cond]];  reg_i$role  <- rep("regulatory", nrow(reg_i))
    combined <- rbind(core_i, reg_i)
    combined <- combined[order(combined$padj), ]
    outfile <- sprintf("wheat_%s_%s.tsv", tolower(cond), outPrefix)
    write.table(combined, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  }
  cat(sprintf("\nwrote wheat_{biotype,virus,time}_%s.tsv\n", outPrefix))
}

run_go_category("GO:0009627", "systemic acquired resistance", "SAR")
run_go_category("GO:0006952", "defense response", "defense_response")
