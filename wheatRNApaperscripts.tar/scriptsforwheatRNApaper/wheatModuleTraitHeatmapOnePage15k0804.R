suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network_15k.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

nSamples <- nrow(datExpr)
stopifnot(identical(rownames(MEs), rownames(coldata)))

# ---- Build the full binarized trait matrix (same as wheatmoduletraitcor0730.R) ----
traitCols <- coldata[, c("biotype", "virus", "day", "replicate")]
traitCols[] <- lapply(traitCols, as.factor)

datTraitsFull <- binarizeCategoricalColumns(traitCols,
                                             considerColumns = colnames(traitCols),
                                             includePairwise = FALSE,
                                             includeLevelVsAll = TRUE,
                                             dropFirstLevelVsAll = FALSE)
rownames(datTraitsFull) <- rownames(coldata)

# replicate is a technical/batch column, not biological -- its three
# level-vs-all columns are always the last three (biotype, virus, day,
# replicate order was preserved by binarizeCategoricalColumns).
repCols <- grep("^replicate\\.", colnames(datTraitsFull))
stopifnot(length(repCols) == 3)
datTraitsNoRep <- datTraitsFull[, -repCols, drop = FALSE]

plotModuleTraitHeatmap <- function(datTraits, outfile) {
  moduleTraitCor <- cor(MEs, datTraits, use = "p")
  moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nSamples)
  moduleTraitQvalue <- matrix(p.adjust(moduleTraitPvalue, method = "BH"),
                              nrow = nrow(moduleTraitPvalue),
                              dimnames = dimnames(moduleTraitPvalue))

  textMatrix <- paste0(signif(moduleTraitCor, 2), "\n(", signif(moduleTraitQvalue, 2), ")")
  dim(textMatrix) <- dim(moduleTraitCor)

  # Portrait, one page, matching wheat_module_trait_heatmap_onepage*.pdf.
  pdf(outfile, width = 8.5, height = 11)
  par(mar = c(8, 8, 3, 3))
  labeledHeatmap(Matrix = moduleTraitCor,
                 xLabels = colnames(datTraits),
                 yLabels = rownames(moduleTraitCor),
                 ySymbols = rownames(moduleTraitCor),
                 colorLabels = FALSE,
                 colors = blueWhiteRed(50),
                 textMatrix = textMatrix,
                 setStdMargins = FALSE,
                 cex.text = 0.35,
                 cex.lab.x = 0.6,
                 cex.lab.y = 0.6,
                 zlim = c(-1, 1),
                 main = "Module-trait relationships, 15k network (BH q-value in parentheses)")
  dev.off()
  cat("wrote", outfile, "-", nrow(moduleTraitCor), "modules x", ncol(moduleTraitCor), "traits\n")
}

plotModuleTraitHeatmap(datTraitsFull,  "wheat_module_trait_heatmap_15k_onepage.pdf")
plotModuleTraitHeatmap(datTraitsNoRep, "wheat_module_trait_heatmap_15k_onepage_norep.pdf")
