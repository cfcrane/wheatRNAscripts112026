#!/usr/bin/env perl
use warnings;
#This script made a special version of SRR32566columndata.txt to separate early and late days.
open (INP, "< $ARGV[0]"); #SRR32566columndata.txt
open (OUT, "> $ARGV[1]");
$line = <INP>; #sampleName      file    biotype virus   day     replicate
print OUT "sampleName\tfile\tbiotype\tvirus\tday\treltime\treplicate\n";
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  print OUT "$vars[0]\t$vars[1]\t$vars[2]\t$vars[3]\t$vars[4]\t";
  if ($vars[4] < 10) {print OUT "early\t$vars[5]\n";}
  else {print OUT "late\t$vars[5]\n";}
}
