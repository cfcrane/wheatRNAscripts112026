suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

padj_cut <- 0.05
lfc_cut  <- 2
gapBp    <- 3e6  # small fixed gap between chromosomes, purely to show the boundary

# ---- Shared reference data, loaded once ----
annRaw <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)

chrLenBase <- read.delim("wheatgenecounts/chromosome_lengths.tsv", stringsAsFactors = FALSE)
chrLenBase$subgenome <- substr(chrLenBase$chr_name, nchar(chrLenBase$chr_name), nchar(chrLenBase$chr_name))
chrLenBase$chrNum <- as.integer(substr(chrLenBase$chr_name, 1, nchar(chrLenBase$chr_name) - 1))
chrLenBase$subgenome <- factor(chrLenBase$subgenome, levels = c("A", "B", "D"))
chrLenBase <- chrLenBase[order(chrLenBase$subgenome, chrLenBase$chrNum), ]
chrLenBase$cumStart <- unlist(lapply(split(chrLenBase, chrLenBase$subgenome), function(d) {
  cumsum(c(0, d$length[-nrow(d)])) + seq_len(nrow(d)) * gapBp
}))
chrLenBase$chrMid <- chrLenBase$cumStart + chrLenBase$length / 2
chrLenBase$chrEnd <- chrLenBase$cumStart + chrLenBase$length

# ---- Build one condition's chromosome-position plot ----
build_chrom_plot <- function(resFile, label, showXTitle = TRUE, showLegend = TRUE,
                              labelSize = 2.6, tickSize = 0.6, baseSize = 10,
                              panelSpacing = 0.45, boxHalfHeight = 0.1) {
  res <- read.delim(resFile, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  sig <- res[res$padj <= padj_cut & abs(res$log2FoldChange) >= lfc_cut, ]
  sig$direction <- ifelse(sig$log2FoldChange >= lfc_cut, "Upregulated", "Downregulated")
  sig$direction <- factor(sig$direction, levels = c("Upregulated", "Downregulated"))
  sig <- unique(sig[, c("gene_id", "log2FoldChange", "direction")])
  names(sig)[names(sig) == "gene_id"] <- "gene_name"

  # mstrg_annotated.tsv's gene_id column mixes LOC ids and MSTRG ids; the
  # reference LOC id is always in gene_name, so join on gene_name (see
  # wheatGeneChromPlot0804.R for the fuller explanation). A few ref genes are
  # split across two adjacent MSTRG loci sharing one gene_name -- collapse to
  # one min-start/max-end span per gene_name.
  ann <- annRaw[annRaw$gene_name %in% sig$gene_name, ]
  ann <- do.call(rbind, by(ann, ann$gene_name, function(d) {
    data.frame(gene_name = d$gene_name[1], accession = d$accession[1],
               start = min(d$start), end = max(d$end))
  }))

  m <- merge(sig, ann, by = "gene_name")
  m <- merge(m, chrLenBase, by = "accession")
  nMapped <- length(unique(m$gene_name))
  cat(sprintf("%s: %d significant DEGs; %d map to a true chromosome (%d unmapped)\n",
              label, nrow(sig), nMapped, nrow(sig) - nMapped))

  m$pos <- (m$start + m$end) / 2
  m$genomePos <- m$cumStart + m$pos

  ggplot() +
    geom_rect(data = chrLenBase, aes(xmin = cumStart, xmax = chrEnd,
                                      ymin = 1 - boxHalfHeight, ymax = 1 + boxHalfHeight),
              fill = "grey92", color = "grey60", linewidth = 0.2) +
    geom_segment(data = m, aes(x = genomePos, xend = genomePos,
                                y = 1 - boxHalfHeight, yend = 1 + boxHalfHeight,
                                color = direction),
                 linewidth = tickSize, alpha = 0.8) +
    geom_text(data = chrLenBase, aes(x = chrMid, y = 1 - boxHalfHeight - 0.1,
                                      label = paste0(chrNum, subgenome)),
              size = labelSize, color = "grey30") +
    scale_color_manual(values = c(Upregulated = "#E85B5B", Downregulated = "#3B8FC4"), drop = FALSE) +
    scale_y_continuous(limits = c(0.5, 1.5), breaks = NULL) +
    facet_wrap(~ subgenome, ncol = 1, scales = "free_x") +
    labs(x = if (showXTitle) "Chromosome" else NULL, y = NULL, color = NULL,
         title = sprintf("%s     padj <= %.2f, |log2FC| >= %d; n = %d genes",
                          label, padj_cut, lfc_cut, nMapped)) +
    theme_minimal(base_size = baseSize) +
    theme(panel.grid = element_blank(),
          axis.text.x = element_blank(),
          strip.text = element_blank(),
          panel.spacing = unit(panelSpacing, "lines"),
          plot.title = element_text(size = baseSize),
          plot.margin = margin(2, 4, 2, 4),
          legend.position = if (showLegend) "top" else "none")
}

# Standalone versions -- each keeps its own top legend.
pBiotype <- build_chrom_plot("biotype_results.txt", "Biotype", showXTitle = TRUE, showLegend = TRUE)
pVirus   <- build_chrom_plot("virus_results.txt",   "Virus",   showXTitle = TRUE, showLegend = TRUE)
pTime    <- build_chrom_plot("time_results.txt",    "Time",    showXTitle = TRUE, showLegend = TRUE)

ggsave("wheat_biotype_DEG_chromosome_positions.pdf", pBiotype, width = 5, height = 6.5)
ggsave("wheat_virus_DEG_chromosome_positions.pdf",   pVirus,   width = 5, height = 6.5)
ggsave("wheat_time_DEG_chromosome_positions.pdf",    pTime,    width = 5, height = 6.5)

# Combined page -- built with smaller text/ticks/spacing than the standalone
# versions so labels don't overlap the (much shorter) panels at this page
# size; only the top panel keeps a legend, since all three use the same
# color mapping (a single collected legend produced duplicate keys, so this
# is more robust than relying on plot_layout(guides = "collect")).
cBiotype <- build_chrom_plot("biotype_results.txt", "Biotype", showXTitle = FALSE, showLegend = TRUE,
                              labelSize = 2.3, tickSize = 0.4, baseSize = 7, panelSpacing = 0.15,
                              boxHalfHeight = 0.2)
cVirus   <- build_chrom_plot("virus_results.txt",   "Virus",   showXTitle = FALSE, showLegend = FALSE,
                              labelSize = 2.3, tickSize = 0.4, baseSize = 7, panelSpacing = 0.15,
                              boxHalfHeight = 0.2)
cTime    <- build_chrom_plot("time_results.txt",    "Time",    showXTitle = TRUE,  showLegend = FALSE,
                              labelSize = 2.3, tickSize = 0.4, baseSize = 7, panelSpacing = 0.15,
                              boxHalfHeight = 0.2)

combined <- cBiotype / cVirus / cTime

ggsave("wheat_DEG_chromosome_positions_combined.pdf", combined, width = 6.5, height = 4.5)
cat("wrote wheat_biotype_DEG_chromosome_positions.pdf, wheat_virus_DEG_chromosome_positions.pdf,",
    "wheat_time_DEG_chromosome_positions.pdf, wheat_DEG_chromosome_positions_combined.pdf\n")
