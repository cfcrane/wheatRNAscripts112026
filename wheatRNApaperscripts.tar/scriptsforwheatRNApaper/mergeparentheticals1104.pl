#!/usr/bin/env perl
## Merge two parenthetical-citation lists.
##
## The base file (e.g. wheatRNAparentheticals1104.txt) has one citation per line,
## optionally already followed by " = value". The lookup file (e.g.
## wheatRNAparentheticals.txt) has lines of the form "citation = value". For each
## base line, the string to the right of the equals sign in the lookup file is
## filled in to the right of the matching citation:  "citation = value".
##
## - A group such as "(A, 2020; B, 2021)" or "(A, 2019a, 2019b)" with no
##   whole-line match is split on semicolons and on comma-separated years
##   ("A, 2019a, 2019b" -> "A, 2019a" and "A, 2019b"); each part is looked up as "(part)" and the values are joined
##   with "; " in the same order: "(A, 2020; B, 2021) = valueA; valueB". A part
##   with no match contributes "NOMATCH" and is reported on STDERR.
## - Lines already carrying a value keep it (a differing lookup value is
##   reported on STDERR).
## - Lines with no match in the lookup file are passed through unchanged and
##   listed on STDERR.
## - If the lookup file gives conflicting values for one citation, the first
##   is used and a warning is printed.
##
## Usage: perl mergeparentheticals1104.pl <base> <lookup> [output_file]
##   Output goes to STDOUT if no output_file is given.

use strict;
use warnings;
use utf8;
use open ':std', ':encoding(UTF-8)';

my ($basefile, $lookupfile, $outfile) = @ARGV;
die "Usage: perl mergeparentheticals1104.pl <base> <lookup> [output_file]\n"
    unless defined $basefile && defined $lookupfile;

sub split_line {
    my ($l) = @_;
    $l =~ s/\r?\n\z//;
    return ($1, $2) if $l =~ /^(.*?)\s*=\s*(.*?)\s*$/;
    $l =~ s/\s+$//;
    return ($l, '');
}

my %val;
{
    my @a = stat $basefile;
    my @b = stat $lookupfile;
    die "Base and lookup are the same file ($basefile); give the file with the "
      . "\"citation = value\" lines as the second argument.\n"
        if @a && @b && $a[0] == $b[0] && $a[1] == $b[1];
}
open(my $lf, '<:encoding(UTF-8)', $lookupfile) or die "Cannot read $lookupfile: $!\n";
while (my $line = <$lf>) {
    my ($k, $v) = split_line($line);
    next unless length $k && length $v;
    if (exists $val{$k} && $val{$k} ne $v) {
        warn "Conflicting values for \"$k\": keeping \"$val{$k}\", ignoring \"$v\"\n";
        next;
    }
    $val{$k} = $v;
}
close $lf;
die "No \"citation = value\" lines found in $lookupfile\n" unless %val;

## Split the inside of a group on semicolons, then expand comma-separated
## years: "A et al., 2019a, 2019b" -> ("A et al., 2019a", "A et al., 2019b").
sub expand_group {
    my ($inner) = @_;
    my @out;
    for my $part (split /;/, $inner) {
        $part =~ s/^\s+|\s+$//g;
        if ($part =~ /^(.*?,)\s*(\d{4}[a-z]?(?:\s*,\s*\d{4}[a-z]?)+)$/) {
            my $author = $1;
            push @out, "$author $_" for split /\s*,\s*/, $2;
        } else {
            push @out, $part;
        }
    }
    return @out;
}

my $ofh = \*STDOUT;
if (defined $outfile) {
    open($ofh, '>:encoding(UTF-8)', $outfile) or die "Cannot write $outfile: $!\n";
}

open(my $bf, '<:encoding(UTF-8)', $basefile) or die "Cannot read $basefile: $!\n";
my $n = 0;
while (my $line = <$bf>) {
    $n++;
    my ($k, $v) = split_line($line);
    if (!length $k) { print $ofh "\n"; next; }
    if (length $v) {
        warn "Line $n: \"$k\" already has \"$v\"; lookup says \"$val{$k}\"\n"
            if exists $val{$k} && $val{$k} ne $v;
        print $ofh "$k = $v\n";
    } elsif (exists $val{$k}) {
        print $ofh "$k = $val{$k}\n";
    } elsif ($k =~ /^\((.*)\)$/ && (my @cites = expand_group($1)) > 1) {
        my @vals;
        my $found = 0;
        for my $c (@cites) {
            if (exists $val{"($c)"}) { push @vals, $val{"($c)"}; $found++; }
            else { push @vals, 'NOMATCH'; warn "Line $n: no match for part \"($c)\"\n"; }
        }
        if ($found) { print $ofh "$k = ", join('; ', @vals), "\n"; }
        else        { print $ofh "$k\n"; }
    } else {
        warn "Line $n: no match for \"$k\"\n";
        print $ofh "$k\n";
    }
}
close $bf;
close $ofh if defined $outfile;
