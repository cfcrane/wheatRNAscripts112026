#!/usr/bin/env perl
use warnings;
#This script confirmed the direction of positive log2 fold-change in DESeq2 output against the locus counts.
open (KEY, "< $ARGV[0]"); #SRR32566columndata.txt
open (RES, "< $ARGV[1]"); #WheatRNA/result_files/biotype_results.txt, a DESeq2 output
open (TRN, "< $ARGV[2]"); #wheatgenecounts/mstrg_to_accession.tsv
open (DAT, "< $ARGV[3]"); #wheat_gene_counts.tsv
$searchterm = $ARGV[4]; #biotype, virus, or day
$ntotake = $ARGV[5]; #5
$line = <KEY>;
chomp $line; #sampleName      file    biotype virus   day     replicate
@headings = split(/\t/, $line);
$catcolumn = "NULL";
for ($i = 0; $i < scalar(@headings); $i++) {
  if ($headings[$i] eq $searchterm) {$catcolumn = $i;}
}
if ($catcolumn ne "NULL") {
  while ($line = <KEY>) {
    chomp $line;
    @vars = split(/\t/, $line);
    $category{$vars[0]} = $vars[$catcolumn];
  }
}
for $key (sort {$category{$a} cmp $category{$b}} (keys(%category))) {
  print "$key\t$category{$key}\n";
}
$line = <RES>;
chomp $line; #tx_id   gene_id NCBI.GeneID     Description     baseMean        log2FoldChange  lfcSE   stat    pvalue  padj
while ($line = <RES>) {
  chomp $line;
  @vars = split(/\t/, $line);
  $lfcs{$vars[1]} = $vars[5];
}
$k = 0;
for $key (sort {$lfcs{$b} <=> $lfcs{$a}} (keys(%lfcs))) {
  $usedkeys{$key} = $lfcs{$key};
  $k++;
  if ($k > $ntotake) {last;}
}
for $key (keys(%usedkeys)) {print "$key\t$usedkeys{$key}\n";}
$line = <TRN>; #MSTRG.100011    NC_057799.1     131473297       131475210       LOC123049027    LOC123049027    XM_044472029.1
while ($line = <TRN>) {
  chomp $line;
  @vars = split(/\t/, $line);
  if (exists($usedkeys{$vars[5]})) {
    if (defined($vars[5])) {$transhash{$vars[0]} = $vars[5];}
  }
}
for $key (keys(%transhash)) {print "$key\t$transhash{$key}\n";}
$line = <DAT>; #gene_id WB31    WHRPV73 WHRPV72 WHRPV71 WHRPV63 WHRPV62 WHRPV61 WHRPV53
chomp $line;
@samples = split(/\t/, $line);
for ($i = 0; $i < scalar(@samples); $i++) {
  if (exists($category{$samples[$i]})) {push(@{$usedcolumns{$category{$samples[$i]}}}, $i);}
}
for $key (sort(keys(%usedcolumns))) {
  $ncolumns{$key} = 0;
  print $key;
  for $i (0 .. $#{$usedcolumns{$key}}) {print " $usedcolumns{$key}[$i]"; $ncolumns{$key}++;}
  print "\n";
}
while ($line = <DAT>) {
  chomp $line; #LOC100037548	0	0	0	0	0
  @vars = split(/\t/, $line);
  if (exists($transhash{$vars[0]})) {
    print $line, "\n";
    for $key (keys(%usedcolumns)) {
      $totals{$key} = 0;
      for $i (0 .. $#{$usedcolumns{$key}}) {$totals{$key} += $vars[$usedcolumns{$key}[$i]];}
      $means{$key} = $totals{$key} / $ncolumns{$key};
      print "$key\t$means{$key}\n";
    }
  }
}
