suppressPackageStartupMessages(library(vegan))
options(stringsAsFactors = FALSE)
set.seed(1)

load("wheat_wgcna_network_15k.RData")  # datExpr (86 x 15000, VST-scale), coldata

# ---- Design check: "not_infested" only exists at day 0 (3 samples, all
# virus_free) -- it cannot participate in a biotype x virus x day factorial
# and would make the model rank-deficient. Excluded here; remaining 83
# samples form a (near-)complete 2 (biotype: B/H) x 2 (virus) x 7 (day)
# design, 3 reps/cell except one cell (biotype B, carrier, day 15) with 2. ----
keep <- coldata$biotype %in% c("B", "H") & coldata$day != 0
cd <- droplevels(coldata[keep, ])
cd$biotype <- factor(cd$biotype)
cd$virus <- factor(cd$virus)
cd$day <- factor(cd$day, levels = c("1", "2", "3", "5", "10", "15", "20"))
expr <- datExpr[keep, ]
stopifnot(identical(rownames(expr), rownames(cd)))
cat(sprintf("Using %d samples (excluded %d day-0/not_infested baseline samples)\n",
            nrow(cd), sum(!keep)))

# ---- Euclidean distance on VST-scale expression (the WGCNA network's own
# 15,000-gene variance-filtered matrix, not the full transcriptome -- the
# standard distance choice for RNA-seq PERMANOVA, analogous to DESeq2's own
# vst()+dist() sample-distance convention) ----
d <- dist(expr, method = "euclidean")

# ---- Marginal (type-III-like) PERMANOVA: each term's effect adjusted for
# all others, the fair way to rank relative importance across biotype,
# virus, day, and their interactions ----
fit_marginal <- adonis2(d ~ biotype * virus * day, data = cd,
                         permutations = 999, by = "margin")
cat("\n==== PERMANOVA (marginal / type-III-like terms) ====\n")
print(fit_marginal)

# ---- Sequential (type-I) decomposition, for reference -- shows how R^2
# apportions when terms are fit in order; useful cross-check but not the
# basis for ranking (order-dependent) ----
fit_sequential <- adonis2(d ~ biotype * virus * day, data = cd,
                           permutations = 999, by = "terms")
cat("\n==== PERMANOVA (sequential / type-I terms, order = biotype, virus, day) ====\n")
print(fit_sequential)

# ---- adonis2's by="margin" only tests terms that are marginal to the model
# under the principle of marginality -- with the 3-way interaction retained,
# main effects nested inside it aren't independently testable, so only the
# 3-way term appears above. Since that 3-way interaction is not significant
# (p = 0.26), drop it and refit with all main effects + two-way interactions;
# THIS reduced model's marginal test is the proper basis for ranking each
# term's independent contribution. ----
fit_reduced_marginal <- adonis2(d ~ biotype * virus + biotype * day + virus * day,
                                 data = cd, permutations = 999, by = "margin")
cat("\n==== PERMANOVA (reduced model, no 3-way interaction; marginal terms -- USE THIS FOR RANKING) ====\n")
print(fit_reduced_marginal)

# ---- Homogeneity of multivariate dispersion check (betadisper) for each
# main factor -- PERMANOVA can confound location and dispersion differences,
# so a significant adonis term paired with a significant betadisper result
# for the same factor should be interpreted cautiously ----
cat("\n==== Multivariate dispersion homogeneity checks (betadisper) ====\n")
for (fac in c("biotype", "virus", "day")) {
  bd <- betadisper(d, cd[[fac]])
  pt <- permutest(bd, permutations = 999)
  cat(sprintf("\n-- %s --\n", fac))
  print(pt)
}

sink("wheat_PERMANOVA_results.txt")
cat("PERMANOVA of RNA-seq expression (Euclidean distance, VST-scale, 15,000-gene WGCNA matrix)\n")
cat(sprintf("n = %d samples; excluded %d day-0/not_infested baseline samples (structurally unconfounded with biotype/virus factorial)\n\n",
            nrow(cd), sum(!keep)))
cat("==== Marginal (type-III-like) terms -- use this for ranking relative effect sizes ====\n")
print(fit_marginal)
cat("\n==== Sequential (type-I) terms, order = biotype, virus, day ====\n")
print(fit_sequential)
cat("\n==== Reduced model (no 3-way interaction), marginal terms -- USE THIS FOR RANKING ====\n")
print(fit_reduced_marginal)
cat("\n==== betadisper homogeneity checks ====\n")
for (fac in c("biotype", "virus", "day")) {
  bd <- betadisper(d, cd[[fac]])
  pt <- permutest(bd, permutations = 999)
  cat(sprintf("\n-- %s --\n", fac))
  print(pt)
}
sink()
cat("\nwrote wheat_PERMANOVA_results.txt\n")
