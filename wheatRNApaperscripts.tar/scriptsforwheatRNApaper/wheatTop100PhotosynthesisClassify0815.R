x <- read.delim("wheat_wgcna_top100_expressed_genes.txt", stringsAsFactors = FALSE)

desc <- x$description
desc[is.na(desc)] <- ""

# Light harvesting: antenna chlorophyll a/b-binding (LHCI/LHCII) proteins.
is_light_harvesting <- grepl("chlorophyll a-b binding protein", desc, ignore.case = TRUE)

# Carbon fixation: RuBisCO (+activase), Calvin-cycle aldolase/GAPDH, and the
# chloroplastic carbonic anhydrase that supplies RuBisCO with CO2.
is_carbon_fixation <- grepl(
  "ribulose bisphosphate carboxylase|fructose-bisphosphate aldolase, chloroplastic|glyceraldehyde-3-phosphate dehydrogenase A, chloroplastic|carbonic anhydrase, chloroplastic",
  desc, ignore.case = TRUE)

# Other photosynthesis machinery: photophosphorylation (ATP synthase),
# PSII/PSI reaction-center core subunits, and the PSII oxygen-evolving
# (water-splitting) complex -- i.e. the light reactions minus the antenna.
is_other_photosynthesis <- grepl(
  "ATP synthase subunit .*chloroplastic|photosystem|oxygen-evolving enhancer protein",
  desc, ignore.case = TRUE)

lightCarbon <- x[is_light_harvesting | is_carbon_fixation, ]
lightCarbon$category <- ifelse(is_light_harvesting[is_light_harvesting | is_carbon_fixation],
                                "light_harvesting", "carbon_fixation")
lightCarbon <- lightCarbon[order(-lightCarbon$total_count), ]

otherPhoto <- x[is_other_photosynthesis, ]
otherPhoto <- otherPhoto[order(-otherPhoto$total_count), ]

cols <- c("gene_id", "gene_name", "description", "total_count", "mean_count",
          "module", "module_color", "accession", "start", "end")

write.table(lightCarbon[, c(cols, "category")], "wheat_top100_light_harvesting_carbon_fixation.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(otherPhoto[, cols], "wheat_top100_other_photosynthesis.txt",
            sep = "\t", quote = FALSE, row.names = FALSE)

cat(sprintf("light harvesting: %d genes\n", sum(is_light_harvesting)))
cat(sprintf("carbon fixation:  %d genes\n", sum(is_carbon_fixation)))
cat(sprintf("other photosynthesis machinery: %d genes\n", sum(is_other_photosynthesis)))
cat(sprintf("neither (excluded from both files): %d genes\n",
            sum(!(is_light_harvesting | is_carbon_fixation | is_other_photosynthesis))))
cat("\nexcluded gene descriptions (for reference):\n")
print(sort(table(desc[!(is_light_harvesting | is_carbon_fixation | is_other_photosynthesis)])))
