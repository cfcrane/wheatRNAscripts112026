#!/usr/bin/env perl
use warnings;
#This script takes a list of files (one filename per line, as in searchtermsections1020.pl)
#and selects every line whose final tab-delimited field is a number less than a threshold
#that defaults to 0.05. The header line (first line) of the first listed file is printed once
#at the top of the output; a file-name section header is then printed before each listed
#file's selected lines, including files after the first. Within each file, selected lines are
#further split by the sign of that file's log2FoldChange column into Section 1 (up-regulated)
#and Section 2 (down-regulated), as elsewhere in this project (see CLAUDE.md and
#enrichKEGG.R). Both section headers are printed verbatim even when a section has no lines.
#Usage: perl selectbylastfield1020.pl <file_list> <output_file> [threshold]
#e.g.:  perl selectbylastfield1020.pl filestosearch.txt selected.txt 0.05
die "Usage: perl $0 <file_list> <output_file> [threshold]\n" unless scalar(@ARGV) == 2 || scalar(@ARGV) == 3;
$filelistfile = $ARGV[0];
$outfile = $ARGV[1];
$threshold = scalar(@ARGV) == 3 ? $ARGV[2] : 0.05;

sub readlist {
  my ($f) = @_;
  my @list = ();
  open(LIST, "<", $f) or die "Could not open $f: $!\n";
  while ($l = <LIST>) {
    chomp $l;
    $l =~ s/^\s+|\s+$//g;
    $l =~ s/^"(.*)"$/$1/; #so a filename quoted in the list file (e.g. "my file.txt") is read without the quote marks
    push @list, $l if length($l);
  }
  close(LIST);
  return @list;
}

@files = readlist($filelistfile);

open(OUT, ">", $outfile) or die "Could not open $outfile: $!\n";

$firstfile = 1;
foreach $file (@files) {
  open(IN, "<", $file) or die "Could not open $file: $!\n";
  @lines = <IN>;
  close(IN);
  $headerline = shift(@lines);
  while (defined($headerline) && $headerline !~ m/\t/) {$headerline = shift(@lines);} #skip a leading caption/title line (no tabs) that precedes the real tab-delimited header, as in some DESeq2resultsfromyanreport061925_table*.txt files

  if ($firstfile) {
    print OUT $headerline if defined($headerline);
    $firstfile = 0;
  }

  $lfccol = -1;
  if (defined($headerline)) {
    $h = $headerline;
    chomp $h;
    @hvars = split(/\t/, $h);
    for ($i = 0; $i < scalar(@hvars); $i++) {$lfccol = $i if $hvars[$i] eq "log2FoldChange" || $hvars[$i] eq "LFC";} #some files (e.g. DESeq2resultsfromyanreport061925_table*.txt) use "LFC" instead
  }
  die "Column 'log2FoldChange' not found in $file\n" if $lfccol < 0;

  @up = ();
  @down = ();
  foreach $line (@lines) {
    chomp $line;
    @vars = split(/\t/, $line);
    $lastfield = $vars[-1];
    next unless defined($lastfield) && $lastfield =~ m/^-?\d*\.?\d+(?:[eE][-+]?\d+)?$/; #skip rows whose final field isn't numeric, e.g. "NA"
    next unless $lastfield < $threshold;
    $lfc = $vars[$lfccol];
    if ($lfc > 0) {push @up, $line;}
    elsif ($lfc < 0) {push @down, $line;}
  }

  print OUT "\nFile: $file\n";
  print OUT "Section 1: up-regulated lines from $file with final field < $threshold\n";
  foreach $line (@up) {print OUT "$line\n";}
  print OUT "Section 2: down-regulated lines from $file with final field < $threshold\n";
  foreach $line (@down) {print OUT "$line\n";}
}
close(OUT);
