suppressPackageStartupMessages({
  library(DESeq2)
  library(WGCNA)
})

options(stringsAsFactors = FALSE)

# ---- 1. Load counts and sample metadata ----
counts <- read.table("wheat_gene_counts.tsv", header = TRUE, sep = "\t",
                      row.names = 1, check.names = FALSE)
counts <- as.matrix(counts)

coldata <- read.table("SRR32566columndata.txt", header = TRUE, sep = "\t",
                       stringsAsFactors = FALSE)
coldata$day <- factor(coldata$day)
rownames(coldata) <- coldata$sampleName
coldata <- coldata[colnames(counts), ]
stopifnot(identical(rownames(coldata), colnames(counts)))

# ---- 1b. Drop known outlier sample ----
# WBRPV61 (B/carrier/day15/rep1) is a technical outlier: lowest fraction of
# reads assigned to genes (30.6%) and by far the highest __no_feature rate
# (51.4% vs <25% typical) of all 87 samples, and it splits off from all other
# 86 samples in a hierarchical clustering of vst expression. Consistent with
# gDNA contamination or a degraded/off-target library rather than biology.
outlier_samples <- "WBRPV61"
counts <- counts[, !(colnames(counts) %in% outlier_samples)]
coldata <- coldata[!(rownames(coldata) %in% outlier_samples), ]
stopifnot(identical(rownames(coldata), colnames(counts)))
cat("samples after outlier removal:", ncol(counts), "\n")

# ---- 2. Pre-filter: drop genes with essentially no signal ----
# 456k+ raw features (incl. low-confidence models/TEs/viral features) is not
# a workable input for DESeq2's dispersion fit or WGCNA's pairwise-correlation
# step. Require a real count in at least as many samples as the smallest
# replicate group (3).
keep <- rowSums(counts >= 10) >= 3
counts <- counts[keep, ]
cat("genes retained after expression filter:", nrow(counts), "\n")

# ---- 3. DESeq2 vst ----
# design = ~1 because this transform is for an unsupervised step (WGCNA), not
# per-gene DE testing; blind = TRUE ignores design during dispersion estimation.
dds <- DESeqDataSetFromMatrix(countData = counts, colData = coldata, design = ~1)
vsd <- vst(dds, blind = TRUE)
saveRDS(vsd, "wheat_vst.rds")

# ---- 4. WGCNA input: samples as rows, genes as columns ----
datExpr <- t(assay(vsd))

# WGCNA does not scale to tens/hundreds of thousands of genes. Restrict
# network construction to the most variable genes post-vst (standard WGCNA
# practice) -- adjust TOP_N_VAR_GENES if you want more/fewer.
TOP_N_VAR_GENES <- 15000
if (ncol(datExpr) > TOP_N_VAR_GENES) {
  gene_var <- apply(datExpr, 2, var)
  keep_genes <- names(sort(gene_var, decreasing = TRUE))[1:TOP_N_VAR_GENES]
  datExpr <- datExpr[, keep_genes]
}
cat("genes entering WGCNA:", ncol(datExpr), "\n")

# ---- 5. Quality check for bad samples/genes ----
gsg <- goodSamplesGenes(datExpr, verbose = 3)
if (!gsg$allOK) {
  datExpr <- datExpr[gsg$goodSamples, gsg$goodGenes]
}
cat("dimensions after goodSamplesGenes:", paste(dim(datExpr), collapse = " x "), "\n")

# ---- 6. Soft-thresholding power ----
enableWGCNAThreads()
powers <- c(1:10, seq(12, 20, 2))
sft <- pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)

pdf("wheat_wgcna_soft_threshold.pdf")
par(mfrow = c(1, 2))
plot(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     xlab = "Soft Threshold (power)",
     ylab = "Scale Free Topology Model Fit, signed R^2",
     type = "n", main = "Scale independence")
text(sft$fitIndices[, 1], -sign(sft$fitIndices[, 3]) * sft$fitIndices[, 2],
     labels = powers, col = "red")
abline(h = 0.8, col = "red")
plot(sft$fitIndices[, 1], sft$fitIndices[, 5],
     xlab = "Soft Threshold (power)", ylab = "Mean Connectivity", type = "n",
     main = "Mean connectivity")
text(sft$fitIndices[, 1], sft$fitIndices[, 5], labels = powers, col = "red")
dev.off()

# Fixed at 6 rather than sft$powerEstimate: with the WBRPV61 outlier removed
# this is the standard WGCNA default for unsigned networks at n>40 samples,
# and is more trustworthy here than chasing an R^2>0.8 crossing (which
# previously fired at power=1 -- see wheat_wgcna_soft_threshold.pdf for the
# full curve if you want to sanity-check this choice).
softPower <- 6
cat("soft power chosen (fixed):", softPower, "\n")
cat("for reference, sft$powerEstimate was:", sft$powerEstimate, "\n")

# ---- 7. Network construction / module detection ----
net <- blockwiseModules(datExpr, power = softPower,
                         TOMType = "unsigned", minModuleSize = 30,
                         reassignThreshold = 0, mergeCutHeight = 0.25,
                         numericLabels = TRUE, pamRespectsDendro = FALSE,
                         saveTOMs = TRUE, saveTOMFileBase = "wheatTOM",
                         verbose = 3)

moduleLabels <- net$colors
moduleColors <- labels2colors(net$colors)
MEs <- net$MEs
geneTree <- net$dendrograms[[1]]

save(net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata,
     file = "wheat_wgcna_network.RData")

cat("modules found:", length(unique(moduleColors)), "\n")
