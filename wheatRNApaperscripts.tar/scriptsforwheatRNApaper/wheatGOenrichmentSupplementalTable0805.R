qval_cut <- 0.05
topN     <- 15

load_top <- function(file, condition) {
  d <- read.delim(file, stringsAsFactors = FALSE)
  sig <- d[d$qvalue <= qval_cut, ]
  sig <- sig[order(sig$qvalue), ]
  sig <- head(sig, topN)
  if (nrow(sig) == 0) return(NULL)
  data.frame(Condition = condition,
             Ontology = sig$ontology,
             GO_ID = sig$GO_ID,
             Term = sig$term,
             N_sig_genes = sig$n_sig_in_term,
             N_sig_total = sig$n_sig_total,
             N_universe_in_term = sig$n_universe_in_term,
             N_universe_total = sig$n_universe_total,
             Fold_enrichment = sig$fold_enrichment,
             P_value = formatC(sig$pvalue, format = "e", digits = 2),
             Q_value = formatC(sig$qvalue, format = "e", digits = 2),
             stringsAsFactors = FALSE)
}

tab <- do.call(rbind, list(
  load_top("wheat_biotype_GO_enrichment.tsv", "Biotype"),
  load_top("wheat_virus_GO_enrichment.tsv",   "Virus"),
  load_top("wheat_time_GO_enrichment.tsv",    "Time")
))

outfile <- "wheat_GO_enrichment_top_terms_supplemental.txt"
write.table(tab, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("wrote %s -- %d rows (top %d terms per condition at q <= %.2f; Time had none)\n",
            outfile, nrow(tab), topN, qval_cut))
