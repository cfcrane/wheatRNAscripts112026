#!/usr/bin/env perl
use warnings;
use Scalar::Util qw(looks_like_number);
use POSIX qw(floor);
#This script rounds numbers in a tab-delimited table according to:
# - scientific notation (e.g. 1.578991e-06): round the mantissa (part before the e) to
#   two digits after the decimal point; leave the exponent (part after the e) alone.
# - otherwise, if abs(value) >= 0.1: round to two digits after the decimal point.
# - otherwise (abs(value) < 0.1): round to the first two digits after the first
#   non-zero digit (i.e. keep three significant figures).
open (INP, "< $ARGV[0]");
open (OUT, "> $ARGV[1]");
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  @nars = ();
  for ($i = 0; $i < scalar(@vars); $i++) {
    $nars[$i] = roundfield($vars[$i]);
  }
  print OUT $nars[0];
  for ($i = 1; $i < scalar(@nars); $i++) {print OUT "\t$nars[$i]";}
  print OUT "\n";
}

sub roundfield {
  my ($val) = @_;
  if ($val =~ /^(-?\d+(?:\.\d+)?)([eE][+-]?\d+)$/) {
    my ($mantissa, $exponent) = ($1, $2);
    return sprintf("%.2f", $mantissa) . $exponent;
  }
  elsif (looks_like_number($val)) {
    if (abs($val) >= 0.1) {
      return sprintf("%.2f", $val);
    }
    elsif ($val == 0) {
      return sprintf("%.2f", $val);
    }
    else {
      my $decimals = -floor(log(abs($val)) / log(10)) + 2;
      return sprintf("%.*f", $decimals, $val);
    }
  }
  else {
    return $val;
  }
}
