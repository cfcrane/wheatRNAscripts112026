suppressPackageStartupMessages(library(VennDiagram))
suppressPackageStartupMessages(library(grid))

padj_cut <- 0.05
lfc_cut  <- 2

sig_genes <- function(file) {
  d <- read.delim(file, stringsAsFactors = FALSE)
  d <- d[!is.na(d$padj), ]
  sig <- d[d$padj <= padj_cut & abs(d$log2FoldChange) >= lfc_cut, ]
  unique(sig$gene_id)
}

sets <- list(Biotype = sig_genes("biotype_results.txt"),
             Virus   = sig_genes("virus_results.txt"),
             Time    = sig_genes("time_results.txt"))

n1 <- length(sets$Biotype); n2 <- length(sets$Virus); n3 <- length(sets$Time)
n12  <- length(intersect(sets$Biotype, sets$Virus))
n13  <- length(intersect(sets$Biotype, sets$Time))
n23  <- length(intersect(sets$Virus, sets$Time))
n123 <- length(Reduce(intersect, sets))

grob <- draw.triple.venn(
  area1 = n1, area2 = n2, area3 = n3,
  n12 = n12, n23 = n23, n13 = n13, n123 = n123,
  category = c("Biotype", "Virus", "Time"),
  fill = c("#2E9E4F", "#3B8FC4", "#E8B93B"),
  alpha = 0.55,
  col = "black", lwd = 1,
  cex = 1.1, fontface = "bold",
  cat.cex = 1.1, cat.fontface = "bold",
  cat.dist = c(0.06, 0.06, 0.06),
  euler.d = FALSE, scaled = FALSE,
  ind = FALSE
)

pdf("wheat_DEG_venn.pdf", width = 6, height = 6.6)
grid.newpage()
grid.text("DEGs by comparison (padj <= 0.05, |log2FC| >= 2)",
          y = unit(0.985, "npc"), gp = gpar(fontsize = 12, fontface = "bold"))
pushViewport(viewport(y = 0, height = 0.93, just = "bottom"))
grid.draw(grob)
popViewport()
dev.off()

cat("wrote wheat_DEG_venn.pdf -", paste(names(sets), lengths(sets), sep = "=", collapse = ", "),
    "| pairwise:", n12, n13, n23, "| triple:", n123, "\n")
