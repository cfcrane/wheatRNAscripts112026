#!/usr/bin/env perl
use warnings;
#This script counts significantly expressed genes from an augmented DESeq2 output.
open (INP, "< $ARGV[0]"); #time_results.txt, virus_results.txt, biotype_results.txt
$minlfc = $ARGV[1]; #2
$maxpadj = $ARGV[2]; #0.05
$line = <INP>;
chomp $line;
@vars = split(/\t/, $line);
for ($i = 0; $i < scalar(@vars); $i++) {
  if ($vars[$i] eq "log2FoldChange") {$lfccolumn = $i;}
  elsif ($vars[$i] eq "padj") {$padjcolumn = $i;}
}
$postotalsig = 0;
$negtotalsig = 0;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  #XM_044462101.1  LOC123038208    123038208       F-box/kelch-repeat protein At5g15710-like       34.3362970179743        0.0548655146230993      0.0147592376615213      3.71736778560986        0.000201309278216472    0.00105652946764986
  if ($vars[$lfccolumn] >= $minlfc) {
    if ($vars[$padjcolumn] ne "NA" && $vars[$padjcolumn] <= $maxpadj) {$postotalsig++;}
  }
  elsif ($vars[$lfccolumn] <= -$minlfc) {
    if ($vars[$padjcolumn] ne "NA" && $vars[$padjcolumn] <= $maxpadj) {$negtotalsig++;}
  }
}
print "Total significant genes with lfc >= $minlfc and padj <= $maxpadj is $postotalsig\n";
print "Total significant genes with lfc <= -$minlfc and padj <= $maxpadj is $negtotalsig\n";
