tab <- read.delim("wheat_module_network_summary_table.txt", stringsAsFactors = FALSE)

theme <- c(
  "1"  = "Plant immune / disease resistance (R-genes, receptor kinase, peroxidase)",
  "2"  = "Chloroplast / photosynthesis machinery (ribosomal proteins, Rubisco, PSII D1)",
  "3"  = "Secondary metabolism / defense (zingiberene synthase, anthocyanidin reductase, PR protein)",
  "4"  = "Cell-wall remodeling / carbohydrate metabolism (pectinesterase, glycosidases, XTHs)",
  "5"  = "Photosynthesis / osmotic regulation (aquaporins, phosphatases, PEP carboxylase)",
  "6"  = "Heat-shock / programmed cell death (HSPs, metacaspase, PCL1-like TFs)",
  "7"  = "TECHNICAL ARTIFACT: rRNA repeat loci (28S/18S rRNA), not a biological pathway",
  "8"  = "Protein turnover / sulfur metabolism (E3 ubiquitin ligases, thiosulfate sulfurtransferase)",
  "9"  = "Chromatin / DNA replication (histones, DNA replication licensing factor M, topoisomerase 2)",
  "10" = "Cold / dehydration stress (LEA-like embryonic protein, HSP, lipid-transfer protein)",
  "11" = "Likely tandem gene array (clustered MSTRG/LOC ids), mostly uncharacterized",
  "12" = "Translation / mitochondrial function (alanine-tRNA ligase, mito outer membrane protein)",
  "13" = "Glutaredoxin / redox regulon (3 of 4 hubs are glutaredoxin-C1 paralogs)",
  "14" = "Iron homeostasis regulon (IRO2-like bHLH TFs, nicotianamine synthase)"
)

caveat <- c(
  "1"  = "All 4 hub genes are unannotated (MSTRG-only); only the DEGs give a biological read",
  "2"  = "None -- most coherent/best-annotated large module",
  "3"  = "One hub gene unannotated",
  "4"  = "None notable",
  "5"  = "One hub gene (LOC123105752) weakly tied to the other 3 hubs/targets",
  "6"  = "Conclusions rest on only 6 total significant DEGs in the module",
  "7"  = "Exclude from biological narrative -- reflects rRNA-depletion variability across libraries, not regulated expression",
  "8"  = "None notable",
  "9"  = "None notable -- echoes module 8's cell-cycle/replication signature from a different angle",
  "10" = "Weak hub kME (~0.91) and weak edge weights (max 0.14) -- most diffuse of the standard-threshold modules",
  "11" = "0 genes met the standard |log2FC|>=2 cut (relaxed to padj-only); numeric-id clustering suggests tandem duplication rather than pathway co-regulation",
  "12" = "Only 1 gene met the standard cut (relaxed to padj-only); half of network unannotated",
  "13" = "Weakest edge weights of any module (max 0.13); one hub gene fully disconnected from both targets",
  "14" = "Smallest module (31 genes) but most internally coherent; connects to the Virus GO-enrichment nicotianamine finding"
)

tab$Dominant_theme <- theme[as.character(tab$Module)]
tab$Caveat <- caveat[as.character(tab$Module)]

write.table(tab, "wheat_module_network_summary_table.txt", sep = "\t", quote = FALSE, row.names = FALSE)
cat("done,", nrow(tab), "rows\n")
