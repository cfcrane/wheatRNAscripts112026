suppressMessages({
  library(DESeq2)
  library(splines)
  library(BiocParallel)
})

x <- readRDS("wheat_gene_counts_and_coldata.rds")
counts  <- x$counts
coldata <- x$coldata

coldata$day_num <- as.numeric(as.character(coldata$day))
coldata$biotype <- factor(coldata$biotype)
coldata$virus   <- factor(coldata$virus)
rownames(coldata) <- coldata$sampleName
stopifnot(identical(colnames(counts), coldata$sampleName))

# drop all-zero / near-zero genes before fitting
keep <- rowSums(counts) >= 10
cat("genes retained after filtering:", sum(keep), "of", length(keep), "\n")
counts <- counts[keep, ]

dds <- DESeqDataSetFromMatrix(
  countData = counts,
  colData   = coldata,
  design    = ~ biotype + virus + ns(day_num, df = 3)
)

dds <- DESeq(dds, test = "LRT", reduced = ~ biotype + virus,
             parallel = TRUE, BPPARAM = MulticoreParam(16))

res <- results(dds)
res <- res[order(res$padj), ]

out <- data.frame(gene_id = rownames(res), as.data.frame(res), check.names = FALSE)
write.table(out, "wheat_time_spline_results0812.txt", sep = "\t", quote = FALSE, row.names = FALSE)

saveRDS(dds, "wheat_time_spline_dds0812.rds")

cat("Total genes tested (non-NA padj):", sum(!is.na(res$padj)), "\n")
cat("Significant genes (padj < 0.05):", sum(res$padj < 0.05, na.rm = TRUE), "\n")
