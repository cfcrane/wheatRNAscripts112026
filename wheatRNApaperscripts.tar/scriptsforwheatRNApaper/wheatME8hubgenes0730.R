suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

targetME <- "ME8"
targetLabel <- as.numeric(sub("ME", "", targetME))
targetColor <- unique(moduleColors[moduleLabels == targetLabel])
stopifnot(length(targetColor) == 1)
inModule <- moduleColors == targetColor
cat(targetME, "= module color '", targetColor, "', ", sum(inModule), " genes\n", sep = "")

# ---- Module membership (kME): correlation of each gene with the ME8 eigengene ----
kME <- signedKME(datExpr, MEs, outputColumnName = "kME")
kMEcol <- paste0("kME", targetLabel)

hub_table <- data.frame(gene = colnames(datExpr)[inModule],
                         kME = kME[inModule, kMEcol])
hub_table <- hub_table[order(-hub_table$kME), ]
write.table(hub_table, "wheat_ME8_hub_genes.tsv", sep = "\t",
            quote = FALSE, row.names = FALSE)

cat("\ntop 20 ME8 genes by module membership (kME):\n")
print(head(hub_table, 20), row.names = FALSE)

# ---- Cross-check: single top hub by actual intramodular connectivity ----
# (adjacency computed within this module only, not just correlation with the
# eigengene -- a stricter definition of "hub" than kME alone)
top_hub <- chooseTopHubInEachModule(datExpr, moduleColors, power = 6, type = "unsigned")
cat("\ntop hub by intramodular connectivity for", targetColor, ":", top_hub[targetColor], "\n")
