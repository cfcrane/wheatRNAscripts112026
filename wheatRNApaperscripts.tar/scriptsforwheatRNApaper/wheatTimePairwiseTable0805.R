padj_cut <- 0.05
lfc_cut  <- 2
days <- c(0, 1, 2, 3, 5, 10, 15, 20)

count_sig <- function(file) {
  res <- read.delim(file, stringsAsFactors = FALSE)
  res <- res[!is.na(res$padj), ]
  up   <- sum(res$padj <= padj_cut & res$log2FoldChange >=  lfc_cut)
  down <- sum(res$padj <= padj_cut & res$log2FoldChange <= -lfc_cut)
  c(up = up, down = down)
}

# Every unordered pair has exactly one file, named "<larger day>_vs_<smaller
# day>.txt"; log2FoldChange there is log2(largerDay / smallerDay) (confirmed
# empirically for 1_vs_0: positive = higher at the first-named/larger day).
tab <- matrix("", nrow = length(days), ncol = length(days),
              dimnames = list(as.character(days), as.character(days)))

for (i in seq_along(days)) {
  for (j in seq_along(days)) {
    r <- days[i]; c <- days[j]
    if (r == c) { tab[i, j] <- "--"; next }
    big <- max(r, c); small <- min(r, c)
    file <- file.path("time_pairwise_results", sprintf("%d_vs_%d.txt", big, small))
    counts <- count_sig(file)
    if (r > c) {
      # row is the first-named (bigger) day -- file's own up/down apply as-is
      rowUp <- counts["up"]; rowDown <- counts["down"]
    } else {
      # row is the smaller day -- row/column are swapped relative to the file's
      # own big/small grouping, so up/down flip
      rowUp <- counts["down"]; rowDown <- counts["up"]
    }
    tab[i, j] <- sprintf("%d:%d", rowDown, rowUp)
  }
}

out <- data.frame(Day = rownames(tab), tab, check.names = FALSE, row.names = NULL)
outfile <- "wheat_time_pairwise_up_down_table.txt"
write.table(out, outfile, sep = "\t", quote = FALSE, row.names = FALSE)
cat("wrote", outfile, "\n")
cat("Each cell = Down:Up, count of genes down/up-regulated in the ROW day relative to the COLUMN day",
    "(padj <=", padj_cut, ", |log2FC| >=", lfc_cut, ")\n")
