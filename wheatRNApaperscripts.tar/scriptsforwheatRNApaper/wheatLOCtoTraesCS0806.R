suppressPackageStartupMessages({
  library(dplyr)
  library(IRanges)
})
options(stringsAsFactors = FALSE)

# ---- 1. TraesCS HC gene models (URGI IWGSC RefSeq Annotation v2.1) ----
# Pre-filtered to "gene" feature lines only via:
#   awk -F'\t' '$3=="gene"' iwgsc_refseqv2.1_annotation_200916_HC.gff3 > /tmp/hc_genes.gff3
hc <- read.delim("/tmp/hc_genes.gff3", header = FALSE, stringsAsFactors = FALSE,
                  col.names = c("chr", "source", "type", "start", "end", "score",
                                "strand", "phase", "attr"))
hc$TraesCS_ID   <- sub(".*ID=([^;]+).*", "\\1", hc$attr)
hc$previous_id  <- ifelse(grepl("previous_id=", hc$attr),
                           sub(".*previous_id=([^;]+).*", "\\1", hc$attr), NA)
hc$mapping_conf <- sub(".*mapping=([a-zA-Z]+).*", "\\1", hc$attr)
hc <- hc[, c("chr", "start", "end", "strand", "TraesCS_ID", "previous_id", "mapping_conf")]

# ---- 2. Chromosome name translation: URGI "Chr1A" <-> NCBI accession ----
chrLen <- read.delim("wheatgenecounts/chromosome_lengths.tsv", stringsAsFactors = FALSE)
chrLen$urgi_chr <- paste0("Chr", chrLen$chr_name)
hc <- merge(hc, chrLen[, c("urgi_chr", "accession", "length")],
            by.x = "chr", by.y = "urgi_chr")

# ---- Sanity check: same v2.1 assembly should mean near-identical chromosome
# lengths/max coordinates between the two independently-hosted copies ----
maxByChr <- aggregate(end ~ chr, hc, max)
maxByChr <- merge(maxByChr, chrLen[, c("chr_name", "length")],
                   by.x = "chr", by.y.x = NULL, by.y = "chr_name", all.x = FALSE)
cat("Coordinate-system sanity check (URGI max gene end vs NCBI chromosome length):\n")
print(head(data.frame(chr = maxByChr$chr, urgi_max_end = maxByChr$end,
                       ncbi_chr_length = maxByChr$length,
                       within_range = maxByChr$end <= maxByChr$length), 21))

# ---- 3. LOC genes, collapsed to one row per gene_name (same logic used
# earlier this session for the chromosome-ideogram plots) ----
annRaw <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
loc <- annRaw %>%
  filter(!is.na(gene_name), gene_name != "") %>%
  group_by(gene_name) %>%
  summarise(accession = dplyr::first(accession), start = min(start), end = max(end), .groups = "drop")
cat(sprintf("\n%d unique LOC/reference genes with coordinates\n", nrow(loc)))

# ---- 4. Interval-overlap join, per chromosome, via IRanges ----
map_chr <- function(accessionId) {
  locSub <- loc[loc$accession == accessionId, ]
  hcSub  <- hc[hc$accession == accessionId, ]
  if (nrow(locSub) == 0 || nrow(hcSub) == 0) return(NULL)

  locIR <- IRanges(start = locSub$start, end = locSub$end)
  hcIR  <- IRanges(start = hcSub$start, end = hcSub$end)
  hits  <- findOverlaps(locIR, hcIR)

  data.frame(gene_name = locSub$gene_name[queryHits(hits)],
             LOC_start = locSub$start[queryHits(hits)],
             LOC_end   = locSub$end[queryHits(hits)],
             TraesCS_ID = hcSub$TraesCS_ID[subjectHits(hits)],
             TraesCS_start = hcSub$start[subjectHits(hits)],
             TraesCS_end = hcSub$end[subjectHits(hits)],
             TraesCS_previous_id = hcSub$previous_id[subjectHits(hits)],
             mapping_conf = hcSub$mapping_conf[subjectHits(hits)],
             stringsAsFactors = FALSE)
}

allAcc <- intersect(unique(loc$accession), unique(hc$accession))
mapped <- do.call(rbind, lapply(allAcc, map_chr))

# ---- 5. Summarize match cardinality per LOC gene ----
matchCount <- table(mapped$gene_name)
nUnique <- sum(matchCount == 1)
nMulti  <- sum(matchCount > 1)
nNone   <- nrow(loc) - length(matchCount)
cat(sprintf("\nLOC genes with exactly 1 overlapping TraesCS gene: %d\n", nUnique))
cat(sprintf("LOC genes with >1 overlapping TraesCS gene (ambiguous): %d\n", nMulti))
cat(sprintf("LOC genes with 0 overlapping TraesCS gene (unmapped): %d\n", nNone))

mapped$n_matches <- as.integer(matchCount[mapped$gene_name])
write.table(mapped, "wheat_LOC_to_TraesCS_v2.1_mapping.tsv", sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("\nwrote wheat_LOC_to_TraesCS_v2.1_mapping.tsv (", nrow(mapped), "rows )\n")
