suppressPackageStartupMessages({
  library(vegan)
  library(ggplot2)
  library(patchwork)
})
options(stringsAsFactors = FALSE)
set.seed(1)

load("wheat_wgcna_network_15k.RData")  # datExpr, coldata

# ---- Same design/subset as wheatPERMANOVA0805.R ----
keep <- coldata$biotype %in% c("B", "H") & coldata$day != 0
cd <- droplevels(coldata[keep, ])
cd$biotype <- factor(cd$biotype)
cd$virus <- factor(cd$virus)
cd$day <- factor(cd$day, levels = c("1", "2", "3", "5", "10", "15", "20"))
expr <- datExpr[keep, ]
d <- dist(expr, method = "euclidean")

fit_sequential <- adonis2(d ~ biotype * virus * day, data = cd,
                           permutations = 999, by = "terms")

# ---- Panel A: ranked R^2 bar chart ----
res <- as.data.frame(fit_sequential)
res <- res[!(rownames(res) %in% c("Residual", "Total")), ]
res$term <- rownames(res)
res$term <- factor(res$term, levels = res$term[order(res$R2)])
res$Significant <- ifelse(res$`Pr(>F)` <= 0.05, "p <= 0.05", "n.s.")
res$label <- sprintf("df=%d, F=%.2f, R²=%.3f, p=%s", res$Df, res$F, res$R2,
                      ifelse(res$`Pr(>F)` < 0.001, "<0.001", sprintf("%.3f", res$`Pr(>F)`)))

pBar <- ggplot(res, aes(x = R2, y = term, fill = Significant)) +
  geom_col(width = 0.65) +
  geom_text(aes(label = label), hjust = -0.05, size = 3) +
  scale_fill_manual(values = c(`p <= 0.05` = "#0ca30c", `n.s.` = "#c3c2b7"), name = NULL) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.62))) +
  labs(x = expression(R^2~"(variance explained)"), y = NULL,
       title = "PERMANOVA term ranking",
       subtitle = "Sequential decomposition, biotype x virus x day (Euclidean, VST expression)") +
  theme_minimal(base_size = 11) +
  theme(panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        legend.position = "top",
        plot.title = element_text(face = "bold", size = 12),
        plot.subtitle = element_text(size = 8.5, color = "grey30"))

# ---- Panel B: PCoA ordination, colored by day, shaped by virus, faceted by
# biotype -- visualizes the significant virus:day and biotype:virus
# interactions directly, since day's main effect alone doesn't show WHY the
# other terms matter ----
pcoa <- cmdscale(d, k = 2, eig = TRUE)
varExp <- round(100 * pcoa$eig[1:2] / sum(pcoa$eig[pcoa$eig > 0]), 1)
ord <- data.frame(PCoA1 = pcoa$points[, 1], PCoA2 = pcoa$points[, 2], cd)

dayColors <- c(`1` = "#cde2fb", `2` = "#9ec5f4", `3` = "#6da7ec", `5` = "#3987e5",
                `10` = "#256abf", `15` = "#184f95", `20` = "#0d366b")

pOrd <- ggplot(ord, aes(x = PCoA1, y = PCoA2, color = day, shape = virus)) +
  geom_point(size = 2.6, alpha = 0.9, stroke = 0.8) +
  scale_color_manual(values = dayColors, name = "Day") +
  scale_shape_manual(values = c(carrier = 17, virus_free = 16), name = "Virus") +
  facet_wrap(~ biotype, labeller = labeller(biotype = c(B = "Biotype B", H = "Biotype H"))) +
  labs(x = sprintf("PCoA1 (%.1f%%)", varExp[1]), y = sprintf("PCoA2 (%.1f%%)", varExp[2]),
       title = "Sample ordination (PCoA)",
       subtitle = "Faceted by biotype -- shows the virus x day interaction driving separation") +
  theme_minimal(base_size = 11) +
  theme(panel.grid.minor = element_blank(),
        strip.text = element_text(face = "bold"),
        plot.title = element_text(face = "bold", size = 12),
        plot.subtitle = element_text(size = 8.5, color = "grey30"))

combined <- pBar / pOrd +
  plot_layout(heights = c(1, 1.3)) +
  plot_annotation(
    title = "PERMANOVA of wheat transcriptome: biotype x virus x day",
    theme = theme(plot.title = element_text(face = "bold", size = 14))
  )

ggsave("wheat_PERMANOVA_figure.pdf", combined, width = 9, height = 11)
cat("wrote wheat_PERMANOVA_figure.pdf\n")
