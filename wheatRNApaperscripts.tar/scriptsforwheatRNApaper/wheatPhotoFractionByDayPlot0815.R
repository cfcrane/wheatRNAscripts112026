suppressPackageStartupMessages(library(ggplot2))

photo <- read.delim("wheat_photosynthesis_day1_day20_fraction.txt", stringsAsFactors = FALSE)
resp  <- read.delim("wheat_photorespiration_day1_day20_fraction.txt", stringsAsFactors = FALSE)

photo$category <- "Photosynthesis (light harvesting + carbon fixation + other)"
resp$category  <- "Photorespiration"

dat <- rbind(photo[, c("day", "fraction", "category")],
             resp[, c("day", "fraction", "category")])

dayLevels <- c("1", "2", "3", "5", "10", "15", "20")
dat$day <- factor(dat$day, levels = dayLevels, ordered = TRUE)
dat$category <- factor(dat$category, levels = c(unique(photo$category), unique(resp$category)))

p <- ggplot(dat, aes(x = day, y = fraction * 100, group = category)) +
  geom_line(color = "steelblue") +
  geom_point(size = 2, color = "steelblue") +
  facet_wrap(~category, ncol = 1, scales = "free_y") +
  labs(x = "Day", y = "% of total mRNA counts",
       title = "Photosynthesis and photorespiration gene sets as a fraction of total mRNA, by day") +
  theme_bw() +
  theme(strip.text = element_text(face = "bold"))

ggsave("wheat_photosynthesis_photorespiration_fraction_by_day.pdf", p, width = 7, height = 6)
cat("wrote wheat_photosynthesis_photorespiration_fraction_by_day.pdf\n")
