options(stringsAsFactors = FALSE)

reformat_table <- function(inFile, outFile, dfCols) {
  tab <- read.delim(inFile, stringsAsFactors = FALSE)
  for (col in colnames(tab)) {
    if (col %in% c("Module", "Color") || col %in% dfCols) next
    tab[[col]] <- sprintf("%.3f", as.numeric(tab[[col]]))
  }
  write.table(tab, outFile, sep = "\t", quote = FALSE, row.names = FALSE)
  cat("wrote", outFile, "\n")
}

reformat_table("wheat_module_trait_PERMANOVA_table.tsv",
                "wheat_module_trait_PERMANOVA_table.tsv", dfCols = character(0))
reformat_table("wheat_module_trait_PERMANOVA_table_withdf.tsv",
                "wheat_module_trait_PERMANOVA_table_withdf.tsv",
                dfCols = c("EigenCor_df", "PERMANOVA_biotype_df", "PERMANOVA_virus_df", "PERMANOVA_day_df"))
