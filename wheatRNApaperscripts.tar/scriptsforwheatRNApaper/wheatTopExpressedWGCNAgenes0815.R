suppressPackageStartupMessages(library(WGCNA))

# Usage: Rscript wheatTopExpressedWGCNAgenes0815.R [N]
# Default N = 50 if not given on the command line.
args <- commandArgs(trailingOnly = TRUE)
N <- if (length(args) >= 1) as.integer(args[1]) else 50
stopifnot(!is.na(N), N > 0)

# ============================================================
# 1. Module membership for the 15,000 genes that went into WGCNA
#    (wheat_wgcna_network_15k.RData: datExpr columns are the same MSTRG/LOC
#    gene-id namespace as our own htseq counts -- see wheatvstwgcna0803.R,
#    which built datExpr by vst-transforming wheat_gene_counts.tsv, dropping
#    the WBRPV61 outlier sample, and keeping the 15k most-variable genes.
#    moduleLabels/moduleColors are positionally aligned with colnames(datExpr).)
# ============================================================
load("wheat_wgcna_network_15k.RData")  # datExpr, moduleLabels, moduleColors, coldata
wgcnaGenes <- colnames(datExpr)
moduleOf <- data.frame(gene_id = wgcnaGenes,
                        module = moduleLabels,
                        module_color = moduleColors,
                        stringsAsFactors = FALSE)

# ============================================================
# 2. Raw total counts for those same genes, across the same 86 samples used
#    in the WGCNA run (wheat_gene_counts_and_coldata.rds is the full,
#    un-transformed htseq matrix everything else here was built from).
# ============================================================
x <- readRDS("wheat_gene_counts_and_coldata.rds")
counts <- x$counts
stopifnot(all(wgcnaGenes %in% rownames(counts)))
wgcnaSamples <- rownames(datExpr)
stopifnot(all(wgcnaSamples %in% colnames(counts)))

geneCounts <- counts[wgcnaGenes, wgcnaSamples, drop = FALSE]
totalCount <- rowSums(geneCounts)
meanCount  <- totalCount / ncol(geneCounts)

# ============================================================
# 3. Annotation crosswalk (gene_name/description/coordinates for both
#    NCBI-annotated LOC genes and novel MSTRG-only gene models).
# ============================================================
ann <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
ann <- ann[match(wgcnaGenes, ann$gene_id), ]

out <- data.frame(
  gene_id       = wgcnaGenes,
  total_count   = totalCount,
  mean_count    = round(meanCount, 2),
  module        = moduleOf$module,
  module_color  = moduleOf$module_color,
  accession     = ann$accession,
  start         = ann$start,
  end           = ann$end,
  gene_name     = ann$gene_name,
  ncbi_geneid   = ann$ncbi_geneid,
  description   = ann$description,
  gene_biotype  = ann$gene_biotype,
  stringsAsFactors = FALSE
)

out <- out[order(-out$total_count), ]
top <- head(out, N)

outFile <- sprintf("wheat_wgcna_top%d_expressed_genes.txt", N)
write.table(top, outFile, sep = "\t", quote = FALSE, row.names = FALSE)

cat(sprintf("wrote %s: top %d of %d WGCNA genes by total raw count across %d samples\n",
            outFile, N, length(wgcnaGenes), ncol(geneCounts)))
