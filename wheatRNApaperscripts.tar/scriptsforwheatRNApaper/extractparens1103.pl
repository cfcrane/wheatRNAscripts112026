#!/usr/bin/env perl
## Extract strings bounded by balanced parentheses from a Word (.docx) file.
##
## The .docx is a zip archive; the body text lives in word/document.xml. This
## script reads that member with "unzip -p", converts it to plain text
## (one line per paragraph; w:tab -> tab, w:br -> space; XML entities decoded;
## text split across several runs is rejoined), then scans each paragraph with
## a depth counter so nested parentheses are handled correctly:
##
##   "(Smith et al., 2020; see also (Jones, 2019))"  -> one string, nested intact
##
## Default: print each outermost balanced group, parentheses included, one per
## line. With -n, also print every nested group inside it (inner groups are
## printed after their enclosing group).
##
## Filtering rule applied to each group:
##   1. If the text in the parentheses is a single word and the second word
##      before the "(" is "et" or "and", print the three words before the "("
##      followed by the group, e.g. "Smith et al. (2020)", "Smith and Jones (2020)".
##   2. Otherwise, if the parenthesized text contains "et" or "and" as a
##      separate word, print the group (parentheses included).
##   3. Otherwise, print nothing.
##
## A group never spans paragraphs. An unmatched "(" at the end of a paragraph or
## a stray ")" (e.g. a list marker like "1)") is not printed; it is reported on
## STDERR with its paragraph number so you can check the manuscript.
##
## Usage: perl extractparens1103.pl [-n] <input.docx> [output_file]
##   Output goes to STDOUT if no output_file is given.

use strict;
use warnings;
use utf8;
use open ':std', ':encoding(UTF-8)';

my $nested = 0;
if (@ARGV && $ARGV[0] eq '-n') { $nested = 1; shift @ARGV; }
my ($infile, $outfile) = @ARGV;
die "Usage: perl extractparens1103.pl [-n] <input.docx> [output_file]\n"
    unless defined $infile;
die "Cannot find $infile\n" unless -f $infile;

## List-form open avoids shell quoting problems with odd file names.
open(my $zfh, '-|:raw', 'unzip', '-p', $infile, 'word/document.xml')
    or die "Cannot run unzip on $infile: $!\n";
my $xml = do { local $/; <$zfh> };
close $zfh;
die "No word/document.xml in $infile (is it a .docx?)\n"
    unless defined $xml && length $xml;
utf8::decode($xml);

## ---- XML -> paragraphs of plain text ----
my @paras;
while ($xml =~ m{<w:p[ >/](.*?)</w:p>}gs) {
    my $p = $1;
    my $text = '';
    while ($p =~ m{<w:t(?:\s[^>]*)?>([^<]*)</w:t>|<w:tab\s*/>|<w:br\b[^>]*/>|<w:noBreakHyphen\s*/>}g) {
        if    (defined $1)           { $text .= $1; }
        elsif ($& =~ /^<w:tab/)      { $text .= "\t"; }
        elsif ($& =~ /^<w:noBreak/)  { $text .= '-'; }
        else                         { $text .= ' '; }
    }
    $text =~ s/&lt;/</g;
    $text =~ s/&gt;/>/g;
    $text =~ s/&quot;/"/g;
    $text =~ s/&apos;/'/g;
    $text =~ s/&#x([0-9A-Fa-f]+);/chr(hex $1)/ge;
    $text =~ s/&#(\d+);/chr($1)/ge;
    $text =~ s/&amp;/&/g;    # last, so "&amp;lt;" is not double-decoded
    push @paras, $text;
}

my $ofh = \*STDOUT;
if (defined $outfile) {
    open($ofh, '>:encoding(UTF-8)', $outfile) or die "Cannot write $outfile: $!\n";
}

## ---- Balanced-parenthesis scan, one paragraph at a time ----
my $pnum = 0;
for my $text (@paras) {
    $pnum++;
    my @stack;    # start offsets of currently open "("
    my @found;    # [start, end, depth] of each completed group
    my $len = length $text;
    for (my $i = 0; $i < $len; $i++) {
        my $c = substr($text, $i, 1);
        if ($c eq '(') {
            push @stack, $i;
        } elsif ($c eq ')') {
            if (@stack) {
                my $start = pop @stack;
                push @found, [$start, $i, scalar(@stack)];
            } else {
                warn "Paragraph $pnum: unmatched ')' near \""
                    . context($text, $i) . "\"\n";
            }
        }
    }
    warn "Paragraph $pnum: unmatched '(' near \"" . context($text, $_) . "\"\n"
        for @stack;

    ## Groups complete inside-out; sort by start so outer groups print first.
    for my $g (sort { $a->[0] <=> $b->[0] } @found) {
        next if $g->[2] > 0 && !$nested;
        my $group = substr($text, $g->[0], $g->[1] - $g->[0] + 1);
        my $inner = substr($text, $g->[0] + 1, $g->[1] - $g->[0] - 1);
        $inner =~ s/^\s+|\s+$//g;

        ## Rule 1: single enclosed word, and the 2nd word before "(" is
        ## "et" or "and" -> the three words before "(" plus the group.
        if ($inner =~ /^\S+$/) {
            my @before = split ' ', substr($text, 0, $g->[0]);
            if (@before >= 2 && $before[-2] =~ /^(?:et|and)$/) {
                my $from = @before >= 3 ? -3 : -scalar(@before);
                print $ofh join(' ', @before[$from .. -1]), " $group\n";
                next;
            }
        }
        ## Rule 2: "et" or "and" appears as a separate word inside the
        ## parentheses -> the parenthesized string.
        if ($inner =~ /(?<![\w])(?:et|and)(?![\w])/) {
            print $ofh "$group\n";
        }
        ## Otherwise: nothing.
    }
}
close $ofh if defined $outfile;

sub context {
    my ($t, $pos) = @_;
    my $s = $pos > 20 ? $pos - 20 : 0;
    return substr($t, $s, 40);
}
