suppressPackageStartupMessages({
  library(dplyr)
  library(IRanges)
})
options(stringsAsFactors = FALSE)

chrLen <- read.delim("wheatgenecounts/chromosome_lengths.tsv", stringsAsFactors = FALSE)
chrLen$urgi_chr <- paste0("Chr", chrLen$chr_name)

load_traescs <- function(gffPath) {
  g <- read.delim(gffPath, header = FALSE, stringsAsFactors = FALSE,
                   col.names = c("chr", "source", "type", "start", "end", "score",
                                 "strand", "phase", "attr"))
  g$TraesCS_ID   <- sub(".*ID=([^;]+).*", "\\1", g$attr)
  g$previous_id  <- ifelse(grepl("previous_id=", g$attr),
                            sub(".*previous_id=([^;]+).*", "\\1", g$attr), NA)
  g$mapping_conf <- sub(".*mapping=([a-zA-Z]+).*", "\\1", g$attr)
  g <- g[, c("chr", "start", "end", "strand", "TraesCS_ID", "previous_id", "mapping_conf")]
  merge(g, chrLen[, c("urgi_chr", "accession")], by.x = "chr", by.y = "urgi_chr")
}

overlap_join <- function(locTab, traesTab) {
  allAcc <- intersect(unique(locTab$accession), unique(traesTab$accession))
  do.call(rbind, lapply(allAcc, function(accessionId) {
    locSub   <- locTab[locTab$accession == accessionId, ]
    traesSub <- traesTab[traesTab$accession == accessionId, ]
    if (nrow(locSub) == 0 || nrow(traesSub) == 0) return(NULL)
    hits <- findOverlaps(IRanges(locSub$start, locSub$end),
                          IRanges(traesSub$start, traesSub$end))
    data.frame(gene_name = locSub$gene_name[queryHits(hits)],
               LOC_start = locSub$start[queryHits(hits)],
               LOC_end   = locSub$end[queryHits(hits)],
               TraesCS_ID = traesSub$TraesCS_ID[subjectHits(hits)],
               TraesCS_start = traesSub$start[subjectHits(hits)],
               TraesCS_end = traesSub$end[subjectHits(hits)],
               TraesCS_previous_id = traesSub$previous_id[subjectHits(hits)],
               mapping_conf = traesSub$mapping_conf[subjectHits(hits)],
               stringsAsFactors = FALSE)
  }))
}

# ---- Rebuild the LOC gene table and the set that HC left unmapped ----
annRaw <- read.delim("wheatgenecounts/mstrg_annotated.tsv", stringsAsFactors = FALSE)
loc <- annRaw %>%
  filter(!is.na(gene_name), gene_name != "") %>%
  group_by(gene_name) %>%
  summarise(accession = dplyr::first(accession), start = min(start), end = max(end), .groups = "drop")

hcMapped <- read.delim("wheat_LOC_to_TraesCS_v2.1_mapping.tsv", stringsAsFactors = FALSE)
unmappedGenes <- setdiff(loc$gene_name, hcMapped$gene_name)
cat(sprintf("%d genes had zero HC matches -- trying LC gene set for these only\n",
            length(unmappedGenes)))
locUnmapped <- loc[loc$gene_name %in% unmappedGenes, ]

# ---- LC gene models (same GFF3 structure as HC) ----
lc <- load_traescs("/tmp/lc_genes.gff3")

rescued <- overlap_join(locUnmapped, lc)

if (is.null(rescued) || nrow(rescued) == 0) {
  cat("No LC matches found for any previously-unmapped gene.\n")
} else {
  matchCount <- table(rescued$gene_name)
  nUnique <- sum(matchCount == 1)
  nMulti  <- sum(matchCount > 1)
  nStillNone <- length(unmappedGenes) - length(matchCount)
  cat(sprintf("Of the %d HC-unmapped genes:\n", length(unmappedGenes)))
  cat(sprintf("  %d now have exactly 1 LC match\n", nUnique))
  cat(sprintf("  %d have >1 LC match (ambiguous)\n", nMulti))
  cat(sprintf("  %d still have no match at all (HC or LC)\n", nStillNone))

  rescued$n_matches <- as.integer(matchCount[rescued$gene_name])
  rescued$confidence_class <- "LC"
  write.table(rescued, "wheat_LOC_to_TraesCS_v2.1_mapping_LC_rescue.tsv",
              sep = "\t", quote = FALSE, row.names = FALSE)
  cat("\nwrote wheat_LOC_to_TraesCS_v2.1_mapping_LC_rescue.tsv (", nrow(rescued), "rows )\n")
  cat("NOTE: kept separate from the HC mapping file -- LC gene models are lower\n")
  cat("confidence (more fragmentary/less validated), so these should be treated\n")
  cat("as tentative fills for genes HC couldn't place, not equal-confidence hits.\n")
}
