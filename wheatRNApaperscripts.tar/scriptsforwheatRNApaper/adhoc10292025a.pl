#!/usr/bin/env perl
use warnings;
#This script counts isoforms by sign of log2 fold-change.
open (INP, "< $ARGV[0]"); #WheatRNA/results_files/biotype_results.txt
$minbase = $ARGV[1]; #100
$maxq = $ARGV[2]; #0.05
$line = <INP>; #Skip the header.
$nup = 0;
$ndown = 0;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  if ($vars[4] >= $minbase) {
    if ($vars[9] ne "NA" && $vars[9] < $maxq) {
      if ($vars[5] ne "NA") {
        if ($vars[5] > 0) {$nup++;}
        else {$ndown++;}
      }
    }
  }
}
print "n up = $nup n down = $ndown\n";
