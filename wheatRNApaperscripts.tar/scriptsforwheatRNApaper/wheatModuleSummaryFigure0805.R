suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
})

tab <- read.delim("wheat_module_network_summary_table.txt", stringsAsFactors = FALSE)

# Evidence-quality status per module, from the Caveat column already written
# for the module-by-module report -- an ordinal severity (good -> critical)
# using the dataviz skill's fixed status palette (never reused for series color).
evidence <- c("1"="Minor note", "2"="Clean", "3"="Minor note", "4"="Clean",
              "5"="Minor note", "6"="Thin evidence", "7"="Artifact", "8"="Clean",
              "9"="Clean", "10"="Thin evidence", "11"="Thin evidence",
              "12"="Thin evidence", "13"="Thin evidence", "14"="Clean")
tab$Evidence <- factor(evidence[as.character(tab$Module)],
                        levels = c("Clean", "Minor note", "Thin evidence", "Artifact"))

ew <- do.call(rbind, strsplit(tab$Edge_weight_range, "-"))
tab$edgeMin <- as.numeric(ew[, 1])
tab$edgeMax <- as.numeric(ew[, 2])

tab$rowLabel <- sprintf("M%d  %s", tab$Module, tab$Color)
tab$rowLabel <- factor(tab$rowLabel, levels = rev(tab$rowLabel[order(tab$Module)]))

themeShort <- sub(" \\(.*", "", tab$Dominant_theme)  # drop the parenthetical examples for the compact label column
tab$themeShort <- themeShort

statusCol <- c(Clean = "#0ca30c", `Minor note` = "#fab219",
               `Thin evidence` = "#ec835a", Artifact = "#d03b3b")

commonTheme <- theme_minimal(base_size = 10) +
  theme(axis.title.y = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        plot.margin = margin(2, 6, 2, 2))

pSize <- ggplot(tab, aes(x = N_genes, y = rowLabel, fill = Color)) +
  geom_col(width = 0.65) +
  geom_text(aes(label = N_genes), hjust = -0.15, size = 2.6, color = "grey20") +
  scale_fill_identity() +
  scale_x_log10(expand = expansion(mult = c(0.02, 0.18))) +
  labs(x = "Module size (genes, log scale)", title = "Size") +
  commonTheme

roleLong <- rbind(
  data.frame(rowLabel = tab$rowLabel, role = "Regulatory", n = tab$N_regulatory),
  data.frame(rowLabel = tab$rowLabel, role = "Structural", n = tab$N_structural)
)
roleLong$role <- factor(roleLong$role, levels = c("Regulatory", "Structural"))

pTargets <- ggplot(roleLong, aes(x = n, y = rowLabel, fill = role)) +
  geom_col(width = 0.65) +
  scale_fill_manual(values = c(Regulatory = "#1baf7a", Structural = "#2a78d6"), name = NULL) +
  scale_x_continuous(expand = expansion(mult = c(0.02, 0.1))) +
  labs(x = "DEGs in network (role)", title = "Targets") +
  commonTheme +
  theme(legend.position = "top", legend.margin = margin(0, 0, -4, 0))

pEdge <- ggplot(tab, aes(y = rowLabel, x = edgeMin, xend = edgeMax, color = Evidence)) +
  geom_segment(aes(yend = rowLabel), linewidth = 2.2, lineend = "round") +
  scale_color_manual(values = statusCol, name = "Evidence quality", drop = FALSE) +
  scale_x_continuous(limits = c(0, max(tab$edgeMax) * 1.05), expand = c(0, 0)) +
  labs(x = "Hub-target TOM edge weight (range)", title = "Connectivity") +
  commonTheme +
  theme(legend.position = "top", legend.margin = margin(0, 0, -4, 0))

pText <- ggplot(tab, aes(y = rowLabel, x = 0)) +
  geom_text(aes(label = themeShort), hjust = 0, size = 2.7, lineheight = 0.9) +
  scale_x_continuous(limits = c(0, 1)) +
  labs(title = "Dominant theme") +
  theme_void(base_size = 10) +
  theme(plot.title = element_text(size = 10, hjust = 0, margin = margin(b = 4)),
        plot.margin = margin(2, 2, 2, 2))

combined <- pSize + pTargets + pEdge + pText +
  plot_layout(widths = c(1.05, 0.85, 0.95, 1.7)) +
  plot_annotation(
    title = "WGCNA module co-expression networks: summary across all 14 modules",
    subtitle = "Size = total genes in module (log scale). Targets = significant DEGs kept in each module's network, split regulatory/structural. Connectivity = min-max hub-target TOM edge weight, colored by evidence quality (module 7 = rRNA artifact; modules 10-13 = thin evidence).",
    theme = theme(plot.title = element_text(face = "bold", size = 13),
                  plot.subtitle = element_text(size = 8.3, color = "grey30"))
  )

ggsave("wheat_module_network_summary_figure.pdf", combined, width = 14, height = 8.5)
cat("wrote wheat_module_network_summary_figure.pdf\n")
