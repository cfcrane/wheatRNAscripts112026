#!/usr/bin/env perl
use warnings;
#This script calculated percentages of genes to total features and characterized to total genes for table WG.
open (INP, "< $ARGV[0]"); #currently hh.txt, see wheat_module_summary_merged0823.txt.
open (OUT, "> $ARGV[1]");
$line = <INP>;
$maxfracgenic = 0;
$minfracgenic = 1;
$maxfracchar = 0;
$minfracchar = 1;
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  if ($vars[2] > 0) {
    $fracgenic = ($vars[3] + $vars[4]) / $vars[2];
    $fracchar = $vars[4] / ($vars[3] + $vars[4]);
    print OUT $line, "\nFraction genic = $fracgenic fraction of genes characterized = $fracchar\n";
    if ($fracgenic < $minfracgenic) {$minfracgenic = $fracgenic; $minfracgenicmodule = $vars[0];}
    if ($fracgenic > $maxfracgenic) {$maxfracgenic = $fracgenic; $maxfracgenicmodule = $vars[0];}
    if ($fracchar < $minfracchar) {$minfracchar = $fracchar; $minfraccharmodule = $vars[0];}
    if ($fracchar > $maxfracchar) {$maxfracchar = $fracchar; $maxfraccharmodule = $vars[0];}
  }
  else {print OUT "No features were seen in $line\n";}
}
print OUT "Minimum fraction genic = $minfracgenic in module $minfracgenicmodule\n";
print OUT "Maximum fraction genic = $maxfracgenic in module $maxfracgenicmodule\n";
print OUT "Minimum fraction of genes characterized = $minfracchar in $minfraccharmodule\n";
print OUT "Maximum fraction of genes characterized = $maxfracchar in $maxfraccharmodule\n";
