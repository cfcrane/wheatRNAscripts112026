#!/usr/bin/env perl
use warnings;
#This script retains lines that have non-zero total length of the gene_name and description fields.
open (INP, "< $ARGV[0]"); #wheat_module1_gene_roster.txt
open (OUT, "> $ARGV[1]");
$searchstringa = $ARGV[2]; #gene_name
$searchstringb = $ARGV[3]; #description
$savedfielda = -1;
$savedfieldb = -1;
$line = <INP>;
chomp $line;
@vars = split(/\t/, $line);
for ($i = 0; $i < scalar(@vars); $i++) {
  if ($vars[$i] eq $searchstringa) {$savedfielda = $i;}
  elsif ($vars[$i] eq $searchstringb) {$savedfieldb = $i;}
}
$fieldsum = $savedfielda + $savedfieldb;
if ($fieldsum < 0) {die "At least one expected field was not found.\n";}
while ($line = <INP>) {
  chomp $line;
  @vars = split(/\t/, $line);
  if (length($vars[$savedfielda]) + length($vars[$savedfieldb]) > 0) {print OUT $line, "\n";}
}
