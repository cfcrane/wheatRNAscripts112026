#!/usr/bin/env perl
use warnings;
use Encode qw(decode);
@ARGV = map { decode('UTF-8', $_) } @ARGV; #so a keyword with a non-ASCII dash (en dash, em dash...) decodes to real characters, matching normalize()
#This script finds the gene IDs listed for a KEGG pathway (matched by keyword against the Description
#column) in an enrichKEGG.R results table, then tabulates how many of those genes are significantly
#up- and down-regulated in a corresponding DESeq2 results table, and writes the affected DESeq2 rows
#(every row whose NCBI.GeneID matched) to a second output file.
#Usage: perl keggpathwaygenecounts1016.pl <enrichKEGG_results.tsv> <keyword> <DESeq2_results.txt> <counts_output.txt> <rows_output.txt>
#e.g.:  perl keggpathwaygenecounts1016.pl WheatRNA/result_files/time_enrichKEGG_results.tsv "MAPK signaling pathway - plant" WheatRNA/result_files/time_results.txt mapk_time_counts.txt mapk_time_rows.txt
die "Usage: perl $0 <enrichKEGG_results.tsv> <keyword> <DESeq2_results.txt> <counts_output.txt> <rows_output.txt>\n" unless scalar(@ARGV) == 5;
$keggfile  = $ARGV[0];
$keyword   = $ARGV[1];
$degfile   = $ARGV[2];
$outfile   = $ARGV[3];
$rowsfile  = $ARGV[4];

sub normalize {
  my ($s) = @_;
  $s =~ tr/\x{2010}-\x{2015}/-/; #treat the various dash characters (hyphen, en dash, em dash...) as equivalent
  $s = lc($s);
  $s =~ s/\s+/ /g;
  $s =~ s/^\s+|\s+$//g;
  return $s;
}

$normkeyword = normalize($keyword);

#Extract the gene IDs for every KEGG results row whose Description matches the keyword.
open(KEGG, "< :encoding(UTF-8)", $keggfile) or die "Could not open $keggfile: $!\n";
$header = <KEGG>;
chomp $header;
@cols = split(/\t/, $header);
%colidx = ();
for ($i = 0; $i < scalar(@cols); $i++) {$colidx{$cols[$i]} = $i;}
foreach $need ("Description", "geneID") {
  die "Column '$need' not found in $keggfile\n" unless exists $colidx{$need};
}

%wantedIDs = ();
$nmatchedrows = 0;
@matcheddesc = ();
while ($line = <KEGG>) {
  chomp $line;
  next unless length($line);
  @vars = split(/\t/, $line);
  $desc = $vars[$colidx{"Description"}];
  if (index(normalize($desc), $normkeyword) >= 0) {
    $nmatchedrows++;
    $dirn = exists($colidx{"direction"}) ? $vars[$colidx{"direction"}] : "NA";
    push @matcheddesc, "$desc ($dirn)";
    @ids = split(m{/}, $vars[$colidx{"geneID"}]);
    foreach $id (@ids) {
      $id =~ s/^\s+|\s+$//g;
      $wantedIDs{$id} = 1 if length($id);
    }
  }
}
close(KEGG);

die "No rows in $keggfile matched keyword '$keyword'.\n" if $nmatchedrows == 0;
$nwanted = scalar(keys %wantedIDs);

#Tabulate significant up/down-regulation for those gene IDs in the DESeq2 results table.
open(DEG, "< :encoding(UTF-8)", $degfile) or die "Could not open $degfile: $!\n";
$header = <DEG>;
chomp $header;
@cols = split(/\t/, $header);
%degidx = ();
for ($i = 0; $i < scalar(@cols); $i++) {$degidx{$cols[$i]} = $i;}
foreach $need ("NCBI.GeneID", "log2FoldChange", "padj") {
  die "Column '$need' not found in $degfile\n" unless exists $degidx{$need};
}

open(ROWS, "> :encoding(UTF-8)", $rowsfile) or die "Could not open $rowsfile: $!\n";
print ROWS "$header\n";

#Rows are per-transcript, so a gene can appear more than once; de-duplicate by gene as
#CLAUDE.md and enrichKEGG.R do: a gene counts as significant if any of its rows has
#padj < 0.05, and its direction comes from the sign of log2FoldChange on that gene's
#most significant (lowest-padj) row.
%seen = ();
%bestpadj = ();
%bestlfc = ();
while ($line = <DEG>) {
  chomp $line;
  next unless length($line);
  @vars = split(/\t/, $line);
  $gid = $vars[$degidx{"NCBI.GeneID"}];
  next unless exists $wantedIDs{$gid};
  print ROWS "$line\n";
  $seen{$gid} = 1;
  $padj = $vars[$degidx{"padj"}];
  $lfc  = $vars[$degidx{"log2FoldChange"}];
  next if ($padj eq "NA" || $padj eq "" || $padj >= 0.05);
  if (!exists($bestpadj{$gid}) || $padj < $bestpadj{$gid}) {
    $bestpadj{$gid} = $padj;
    $bestlfc{$gid}  = $lfc;
  }
}
close(DEG);
close(ROWS);

$upcount = 0;
$downcount = 0;
foreach $gid (keys %bestlfc) {
  if ($bestlfc{$gid} > 0) {$upcount++;}
  elsif ($bestlfc{$gid} < 0) {$downcount++;}
}

$nfound = scalar(keys %seen);
$nnotfound = $nwanted - $nfound;
$notsig = $nfound - scalar(keys %bestlfc);

open(OUT, "> :encoding(UTF-8)", $outfile) or die "Could not open $outfile: $!\n";
print OUT "Keyword: $keyword\n";
print OUT "Matched pathway rows in $keggfile: $nmatchedrows\n";
foreach $d (@matcheddesc) {print OUT "  $d\n";}
print OUT "Unique gene IDs extracted: $nwanted\n";
print OUT "Gene IDs found in $degfile: $nfound\n";
print OUT "Gene IDs not found in $degfile: $nnotfound\n";
print OUT "Significantly up-regulated (padj<0.05, log2FC>0): $upcount\n";
print OUT "Significantly down-regulated (padj<0.05, log2FC<0): $downcount\n";
print OUT "Not significant (padj>=0.05): $notsig\n";
print OUT "Affected rows from $degfile written to $rowsfile\n";
close(OUT);
