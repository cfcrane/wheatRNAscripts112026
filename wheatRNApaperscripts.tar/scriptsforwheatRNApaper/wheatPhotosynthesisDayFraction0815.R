x <- readRDS("wheat_gene_counts_and_coldata.rds")
counts <- x$counts
coldata <- x$coldata

lc <- read.delim("wheat_top100_light_harvesting_carbon_fixation.txt", stringsAsFactors = FALSE)
op <- read.delim("wheat_top100_other_photosynthesis.txt", stringsAsFactors = FALSE)
combinedGenes <- unique(c(lc$gene_id, op$gene_id))
stopifnot(all(combinedGenes %in% rownames(counts)))
cat("combined gene set:", length(combinedGenes), "genes\n")

summarize_day <- function(dayLevel) {
  samples <- coldata$sampleName[coldata$day == dayLevel]
  sub <- counts[, samples, drop = FALSE]
  totalMRNA <- sum(sub)
  geneSum <- sum(sub[combinedGenes, ])
  data.frame(day = dayLevel, n_samples = length(samples),
             photosynthesis_gene_count = geneSum,
             total_mRNA_count = totalMRNA,
             fraction = geneSum / totalMRNA)
}

days <- c("1", "2", "3", "5", "10", "15", "20")
res <- do.call(rbind, lapply(days, summarize_day))
write.table(res, "wheat_photosynthesis_day1_day20_fraction.txt", sep = "\t",
            quote = FALSE, row.names = FALSE)
print(res, row.names = FALSE)
