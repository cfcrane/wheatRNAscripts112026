suppressPackageStartupMessages(library(WGCNA))
options(stringsAsFactors = FALSE)

load("wheat_wgcna_network.RData")  # net, moduleLabels, moduleColors, MEs, geneTree, datExpr, coldata

nBlocks <- length(net$dendrograms)

# Default plotDendroAndColors devotes ~20% of each panel's height to the
# color band (colorHeightBase = 0.2) for a single color row. Halving that
# to 0.08 (dendro 0.92 / color 0.08) compresses the band well over 50%
# relative to default, so the dendrogram keeps most of the vertical space.
dendroFrac <- 0.92
colorFrac  <- 0.08

pdf("wheat_geneDendro_allBlocks_onepage.pdf", width = 8.5, height = 11)
layout(matrix(seq_len(2 * nBlocks), ncol = 1),
       heights = rep(c(dendroFrac, colorFrac), times = nBlocks))

for (i in seq_len(nBlocks)) {
  blockIdx <- net$blockGenes[[i]]
  blockColors <- moduleColors[blockIdx]

  plotDendroAndColors(net$dendrograms[[i]], blockColors,
                       groupLabels = "Module colors",
                       setLayout = FALSE,
                       dendroLabels = FALSE, hang = 0.03,
                       addGuide = TRUE, guideHang = 0.05,
                       cex.colorLabels = 0.7, cex.dendroLabels = 0.8,
                       marAll = c(0.5, 4, 2, 1),
                       main = sprintf("Block %d gene dendrogram (%d genes)",
                                       i, length(blockIdx)))
}
dev.off()
cat("wrote wheat_geneDendro_allBlocks_onepage.pdf -", nBlocks, "blocks on one page\n")
